"""Hardware-free tests for official download, startup retry, and safe preflight."""
import io
import pathlib
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

ROOT = pathlib.Path(__file__).parent / 'app' / 'GS_WiFI_Pineapple_Pager_Companion_App'
sys.path.insert(0, str(ROOT))
import pager_backend as backend

GOOD_URL = 'https://storage.googleapis.com/hak5-dl.appspot.com/wifipineapplepager/firmwares/2.0.0-stable/pineapplepager-firmware-2.0.0-signed.bin'

class FakeResponse:
    def __init__(self, payload, url=GOOD_URL, headers=None):
        self.stream = io.BytesIO(payload)
        self.url = url
        self.headers = headers if headers is not None else {'Content-Length':str(len(payload)), 'Content-Type':'application/octet-stream'}
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,n):return self.stream.read(n)
    def geturl(self):return self.url

class Download(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = pathlib.Path(self.tmp.name)
    def run_download(self, response):
        return backend.download_official_firmware(str(self.folder), open_url=lambda *a, **k:response)
    def test_official_redirect_saves_firmware(self):
        original = b'official simulated content' + b'a'*300000
        dest = self.run_download(FakeResponse(original))
        self.assertTrue(dest.is_file())
        self.assertEqual(dest.read_bytes(), original)
        self.assertEqual(list(self.folder.glob('*.partial')),[])
    def test_rejects_untrusted_redirect_without_saving(self):
        with self.assertRaisesRegex(backend.PagerError,'redirected outside'):
            self.run_download(FakeResponse(b'x'*300000,url='https://evil.example/pineapplepager.bin'))
        self.assertEqual(list(self.folder.iterdir()),[])
    def test_rejects_html_or_json(self):
        with self.assertRaisesRegex(backend.PagerError,'web/API'):
            self.run_download(FakeResponse(b'a'*300000,headers={'Content-Type':'text/html'}))
        self.assertEqual(list(self.folder.iterdir()),[])
    def test_rejects_truncated_file_cleans_partial(self):
        with self.assertRaisesRegex(backend.PagerError,'interrupted'):
            self.run_download(FakeResponse(b'x'*270000,headers={'Content-Length':'300000'}))
        self.assertEqual(list(self.folder.iterdir()),[])
    def test_existing_file_never_overwritten(self):
        name=pathlib.Path(GOOD_URL).name
        p=self.folder/name;p.write_bytes(b'existing')
        with self.assertRaisesRegex(backend.PagerError,'already exists'):
            self.run_download(FakeResponse(b'x'*300000))
        self.assertEqual(p.read_bytes(),b'existing')
    def test_only_https_official_or_known_bucket(self):
        self.assertFalse(backend._trusted_firmware_redirect('http://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest'))
        self.assertFalse(backend._trusted_firmware_redirect('https://downloads.hak5.org.bad.example/api/devices/wifipineapplepager/firmwares/latest'))
        self.assertFalse(backend._trusted_firmware_redirect('https://storage.googleapis.com/another-bucket/other.bin'))
        self.assertTrue(backend._trusted_firmware_redirect(backend.DOWNLOAD_URL))
        self.assertTrue(backend._trusted_firmware_redirect(GOOD_URL))

class ConnectRetry(unittest.TestCase):
    def setUp(self):
        self.fake_ssh = SimpleNamespace(AuthenticationException=type('Auth',(Exception,),{}),BadHostKeyException=type('HostKey',(Exception,),{}),SSHException=type('SSH',(Exception,),{}))
    def test_transient_network_failure_then_connects(self):
        class Conn:
            def __init__(self):self.calls=0;self.closes=0
            def connect(self,timeout=9):
                self.calls+=1
                if self.calls<3:raise OSError('usb not ready')
            def close(self):self.closes+=1
        c=Conn();events=[]
        with patch.object(backend,'get_ssh_lib',return_value=self.fake_ssh),patch.object(backend.time,'sleep',return_value=None):
            self.assertIs(backend.connect_pager_with_retry(c,events.append,max_wait=120),c)
        self.assertEqual(c.calls,3)
        self.assertEqual(c.closes,2)
        self.assertTrue(any('Retrying' in e for e in events))
    def test_bad_credentials_never_retried(self):
        ssh=self.fake_ssh
        class Conn:
            def __init__(self):self.calls=0
            def connect(self,timeout=9):self.calls+=1;raise ssh.AuthenticationException('bad password')
            def close(self):pass
        c=Conn()
        with patch.object(backend,'get_ssh_lib',return_value=ssh):
            with self.assertRaises(ssh.AuthenticationException):backend.connect_pager_with_retry(c)
        self.assertEqual(c.calls,1)
    def test_exits_after_maximum_wait(self):
        class Conn:
            def connect(self,timeout=9):raise OSError('usb failed')
            def close(self):pass
        times=iter([0.,0.,2.,2.,4.,4.,6.,6.,8.,8.,10.,10.])
        with patch.object(backend,'get_ssh_lib',return_value=self.fake_ssh),patch.object(backend.time,'monotonic',side_effect=lambda:next(times,12.0)),patch.object(backend.time,'sleep',return_value=None):
            with self.assertRaisesRegex(backend.PagerError,'did not become SSH-ready'):
                backend.connect_pager_with_retry(Conn(),max_wait=3)

class FreeSpace(unittest.TestCase):
    def test_preflight_failure_never_sends_install_command(self):
        class Conn:
            def __init__(self):self.commands=[]
            def command(self,cmd,timeout=12):self.commands.append(cmd);return (1,'df failed')
        c=Conn()
        with tempfile.TemporaryDirectory() as directory:
            p=pathlib.Path(directory)/'pineapplepager-firmware.bin';p.write_bytes(b'X'*270000)
            with self.assertRaisesRegex(backend.PagerError,'verify free /tmp space'):
                backend.run_firmware_update(c,str(p),'',lambda *args:None)
        self.assertNotIn('INSTALL_FIRMWARE',str(c.commands))

if __name__ == '__main__':unittest.main()

class LatestFirmwareButton(unittest.TestCase):
    """Prevent regression to the unreliable in-app downloader as main action."""
    def test_main_button_opens_exact_latest_hak5_url(self):
        import GS_WiFI_Pineapple_Pager_Companion_App as gui
        events = []
        standin = SimpleNamespace(
            firmware_note=SimpleNamespace(set=events.append),
            _append_log=events.append,
        )
        with patch.object(gui.webbrowser, 'open', return_value=True) as open_browser:
            gui.App.open_latest_firmware(standin)
            open_browser.assert_called_once_with(
                'https://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest',
                new=2,
            )
        self.assertTrue(any('No flashing has started' in x for x in events))
        source = pathlib.Path(gui.__file__).read_text(encoding='utf-8')
        self.assertIn('"1. GRAB THE LATEST PAGER FIRMWARE HERE  ↗",\n                   self.open_latest_firmware', source)

    def test_browser_failure_does_not_open_portal(self):
        import GS_WiFI_Pineapple_Pager_Companion_App as gui
        events = []
        standin = SimpleNamespace(
            firmware_note=SimpleNamespace(set=events.append),
            _append_log=events.append,
        )
        with patch.object(gui.webbrowser, 'open', return_value=False) as browser, patch.object(gui.messagebox, 'showwarning') as popup:
            gui.App.open_latest_firmware(standin)
            browser.assert_called_once_with(gui.DOWNLOAD_URL, new=2)
            popup.assert_called_once()
        self.assertTrue(any('Try again later' in x for x in events))
        self.assertFalse(any('portal' in x.lower() for x in events))

    def test_firmware_screen_removes_alternate_download_buttons(self):
        import GS_WiFI_Pineapple_Pager_Companion_App as gui
        source = pathlib.Path(gui.__file__).read_text(encoding='utf-8')
        self.assertNotIn('DOWNLOAD INSIDE APP (ALTERNATIVE)', source)
        self.assertNotIn('HAK5 DOWNLOAD PORTAL (IF LINK TIMES OUT)', source)
        self.assertNotIn('def download_firmware(self):', source)
        self.assertIn('self.open_latest_firmware, primary=True', source)
        self.assertIn('self.choose_firmware, big=True', source)
