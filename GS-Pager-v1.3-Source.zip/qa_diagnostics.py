"""Hardware-free tests of non-destructive diagnostics and command reporting."""
import unittest, pathlib, sys, tempfile, hashlib
from unittest import mock
ROOT=pathlib.Path(__file__).parent/'app'/'GS_WiFI_Pineapple_Pager_Companion_App'
sys.path.insert(0,str(ROOT))
import pager_backend as fw
import qa_firmware_monitor as q

class TestReadOnly(unittest.TestCase):
    def test_readonly_commands_no_flash(self):
        seen=[]
        class Connection:
            def command(self, text, timeout=12):
                seen.append(text)
                return 0,'ok'
        report=fw.check_pager_update_readiness(Connection())
        self.assertIn('No flash, reboot or file changes',report)
        self.assertEqual(len(seen),5)
        self.assertFalse(any(c.strip().startswith(('INSTALL_FIRMWARE ', 'reboot','sysupgrade','rm ','uci set')) for c in seen))

    def test_failed_probe_records_unavailable(self):
        class Connection:
            def command(self, text, timeout=12):raise TimeoutError()
        report=fw.check_pager_update_readiness(Connection())
        self.assertEqual(report.count('unavailable (TimeoutError)'),5)

class OutputReporting(q.FirmwareSimulation):
    def test_command_output_error_is_not_hidden(self):
        class ErrorChannel(q.Channel):
            def __init__(self): super().__init__();self.sent=False
            def recv_ready(self):return not self.sent
            def recv(self,n):self.sent=True;return b'Invalid firmware image!'
            def exit_status_ready(self):return self.sent
            def recv_exit_status(self):return 17
        self.ch=ErrorChannel();self.conn.transport.ch=self.ch
        with self.assertRaisesRegex(fw.PagerError,'exit 17'):
            self.invoke([True])
        self.assertTrue(any('Invalid firmware image' in str(e) for e in self.events))
        self.assertTrue(any('exit status: 17' in str(e) for e in self.events))
        self.assertFalse(any(e[:3]==('stage','install','done') for e in self.events))
    def test_exits_zero_but_no_reboot_is_unconfirmed(self):
        class ExitChannel(q.Channel):
            def exit_status_ready(self):return True
            def recv_exit_status(self):return 0
        self.ch=ExitChannel();self.conn.transport.ch=self.ch
        self.assertEqual(self.invoke([True]),'command_sent_unconfirmed')
        self.assertTrue(any('exit status: 0' in str(e) for e in self.events))
        self.assertTrue(any('No Pager reboot detected' in str(e) for e in self.events))
        self.assertFalse(any(e[:3]==('stage','install','done') for e in self.events))

if __name__=='__main__':unittest.main()
