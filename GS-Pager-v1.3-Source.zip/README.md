# GS WiFI Pineapple Pager Companion App

**Version V1.3 — Windows Beta**

A free, community-built Windows companion for the Hak5 WiFi Pineapple Pager.

> **Independent project:** Not an official Hak5 product. This application was not developed, sponsored, approved, or endorsed by Hak5.

## Why this exists

GhostStrats created this app to make connecting to the Pager, managing files, working with themes and payloads, and navigating firmware updates easier for beginners. It is a Pager-focused companion, not a replacement for official Hak5 firmware or documentation.

## What's in V1.3

- **Improved startup connections:** Automatic retry of temporary USB network and SSH startup failures for up to 120 seconds; incorrect passwords and unexpected SSH host-key changes do not get retried.
- **Simplified firmware screen:** One **GRAB THE LATEST PAGER FIRMWARE HERE** button opens Hak5's direct download in the browser, plus a local `.bin` file picker. The separate in-app downloader and backup download-portal button were removed.
- **Two update methods:** The Pager's own **Settings → Updates → Check for Updates** is recommended when the Pager has internet access. The computer-assisted option uses an official signed firmware file, preflight checks, SFTP, and Hak5's documented `INSTALL_FIRMWARE` over dedicated SSH (not the Virtual Pager terminal).
- **Safer update monitoring:** Firmware file transfer verification, optional published SHA-256 comparison, free-space check, progress logging, and status reporting. The app does not automatically retry a flash with an uncertain outcome or treat a command being sent as proof of success.
- **Connection guidance:** A startup reminder to wait around 60 seconds after power-on and use a USB-C data cable; SSH key reset after an intentional Pager reset with fingerprint verification.
- **Installer responsiveness:** Purple activity marker, live elapsed timer, clearer install/repair/uninstall messages, and native Windows shortcut creation.
- **Version updated:** Application footer, setup window, Windows installed-app registration, documentation, and downloadable filenames are V1.3.

Thank you to **Darren Kitchen, founder of Hak5**, for suggesting the streamlined official firmware-download shortcut.

## Downloads and installation

1. From the GitHub Release assets, download `GS_WiFI_Pineapple_Pager_Companion_App_V1.3_Easy_Install.zip`.
2. Extract the ZIP and read `README.txt` / `DISCLAIMER.txt`.
3. Open `GS_WiFI_Pineapple_Pager_Companion_App_Setup_V1.3.exe` and choose **Install / Upgrade**. The installer also offers **Repair** and **Uninstall**.
4. Allow dependency setup if required. The setup can request permission to install a private Python runtime if one is missing; an internet connection may be required.
5. Power on the Pager, let it finish booting, connect it with a **USB-C data cable**, and launch the application. The usual USB network address is `172.16.52.1`.

**Requirements:** Windows 10 or 11 (64-bit); Python 3.9–3.13 with Tkinter/pip, or the installer-managed Python 3.12 runtime; network connectivity if dependencies must be downloaded.

The Windows installer is currently **unsigned**, so SmartScreen or antivirus warnings are possible. Do not bypass a malware detection; investigate it before running.

## Features

- Connect Device — SSH / SFTP and SSH host-key verification.
- File Manager — upload by dragging files/folders **into** the app, or use Upload Files / Upload Folder; download files or complete folders with **Download to Your Computer**. Dragging out of the app is intentionally unsupported.
- Firmware Update — official update guidance and computer-assisted `.bin` selection with diagnostic logging.
- Virtual Pager — open the Pager's local web interface.
- Pager Terminal — start a dedicated SSH terminal session.
- Payloads & Themes — GitHub shortcuts and installation guidance.
- Appearance — Black & Gray, Black & Yellow, and GhostStrats Purple.

Theme creation is not included.

### Payloads and theme locations

- Payloads: `/root/payloads/user/` or `/mmc/root/payloads/user/` for SD-card storage.
- Themes: `/root/themes/` or `/mmc/root/themes/` for SD-card storage.

Repositories:

- https://github.com/hak5/wifipineapplepager
- https://github.com/hak5/wifipineapplepager-payloads
- https://github.com/hak5/wifipineapplepager-themes

Follow the relevant repository instructions, and back up any existing files before replacing them.

## Firmware safety

**Recommended:** On the Pager, connect to Wi-Fi and use **Settings → Updates → Check for Updates**.

**Windows-assisted:** Download official firmware from https://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest, select the downloaded `.bin` file in the app, and review the warnings before starting. The download button itself never flashes the device. The app has **no alternate in-app downloader or download-portal fallback**; retry the official link later if it is unavailable.

Use only official signed firmware. Keep power and USB connected throughout a possible update. A completed transfer does not prove the firmware was successfully installed; verify the new version on the Pager after it boots. If a prior flash is unconfirmed, do **not** launch another flash.

Official guide: https://documentation.hak5.org/wifi-pineapple-pager/software-updates/software-updates.md

## Uninstall

Use **Windows Settings → Apps → Installed Apps** or the installer **Uninstall** option. This does not erase files on the Pager or remove shared/system Python. Application preferences may be retained. Installer attempts to preserve unrelated files discovered within managed app folders.

## Source and verification

`GS_WiFI_Pineapple_Pager_Companion_App_V1.3_Source_Code.zip` contains Python/Go source, original assets, build instructions and tests. Earlier release notes are placed in the source-only `HISTORY/` directory; they are not shipped in the installed app.

**Source availability is not a license grant.** No license has been selected. Obtain permission before redistribution or reuse of artwork.

Automated tests and Linux-based cross-compilation validate portions of this build. The user has reported that the current updater now reaches the Pager's flashing screen and that USB connections are improved, but a complete successful flash, clean Windows install/upgrade/uninstall, and antivirus compatibility remain to be verified before calling V1.3 production-stable.

## Disclaimer

Provided **as is**, without warranty. Use only devices and networks you own or are authorized to administer. Back up your data. Hak5 and WiFi Pineapple are trademarks of their respective owners. GhostStrats is unaffiliated with Hak5.
