import os, pathlib, tempfile, shutil, sys, stat, errno, hashlib, importlib.util, unittest, types, queue
from unittest.mock import patch
ROOT=pathlib.Path(__file__).parent/'app'/'GS_WiFI_Pineapple_Pager_Companion_App'
sys.path.insert(0,str(ROOT))
import pager_backend as backend
spec=importlib.util.spec_from_file_location('gs_app',ROOT/'GS_WiFI_Pineapple_Pager_Companion_App.py')
app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
class MemSFTP:
 def __init__(self):self.fs={'/root':None};self.fail_commit=False
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def lstat(self,path):return self.stat(path)
 def stat(self,path):
  if path not in self.fs:raise FileNotFoundError(errno.ENOENT,'missing',path)
  return types.SimpleNamespace(st_mode=stat.S_IFDIR|0o755 if self.fs[path] is None else stat.S_IFREG|0o644,st_size=len(self.fs[path] or b''))
 def mkdir(self,path):
  if path in self.fs:raise FileExistsError(path)
  self.fs[path]=None
 def put(self,local,remote,callback=None,confirm=True):
  data=pathlib.Path(local).read_bytes();self.fs[remote]=data
  if callback:callback(len(data),len(data))
 def get(self,remote,local,callback=None):
  if remote not in self.fs or self.fs[remote] is None:raise IOError('missing file')
  pathlib.Path(local).write_bytes(self.fs[remote]);size=len(self.fs[remote]);
  if callback:callback(size,size)
 def rename(self,a,b):
  if self.fail_commit and '/.gs-upload-' in a:raise IOError('simulated commit failure')
  if a not in self.fs:raise FileNotFoundError(a)
  if b in self.fs:raise FileExistsError(b)
  block=[(k,v) for k,v in self.fs.items() if k==a or k.startswith(a+'/')]
  for k,_ in block:del self.fs[k]
  for k,v in block:self.fs[b+k[len(a):]]=v
 def listdir(self,path):
  return list({k[len(path)+1:].split('/')[0] for k in self.fs if k.startswith(path+'/') and k!=path})
 def rmdir(self,path):
  if self.listdir(path):raise OSError('not empty')
  del self.fs[path]
 def remove(self,path):del self.fs[path]
class Conn:
 def __init__(self,fs):self.client=self;self.fs=fs
 def open_sftp(self):return self.fs
class QA(unittest.TestCase):
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.p=pathlib.Path(self.temp.name);self.fs=MemSFTP();self.conn=backend.PagerConnection.__new__(backend.PagerConnection);self.conn.client=Conn(self.fs)
 def test_title(self):self.assertEqual(app.APP_TITLE,'GS WiFI Pineapple Pager Companion App')
 def test_default_theme(self):self.assertEqual(app.read_settings(self.p/'absent.json')['theme'],'slate')
 def test_settings_roundtrip(self):
  settings=self.p/'settings.json';app.save_settings('yellow','Extra large',settings);self.assertEqual(app.read_settings(settings),{'theme':'yellow','text_size':'Extra large'})
 def test_urls(self):self.assertEqual(app.virtual_pager_url('172.16.52.1'),'http://172.16.52.1:1471/')
 def test_url_reject(self):
  for url in ['https://example.com','host:1234','../foo','a b']:
   with self.subTest(url=url),self.assertRaises(ValueError):app.virtual_pager_url(url)
 def test_firmware_bad_suffix(self):
  p=self.p/'firmware.zip';p.write_bytes(b'x'*270000)
  with self.assertRaises(backend.PagerError):backend.validate_firmware_file(str(p))
 def test_firmware_bad_magic(self):
  p=self.p/'firmware.bin';p.write_bytes(b'PK\x03\x04'+b'0'*270000)
  with self.assertRaises(backend.PagerError):backend.validate_firmware_file(str(p))
 def test_firmware_checksum(self):
  p=self.p/'arbitrary-name.bin';p.write_bytes(b'good firmware sample'+b'!'*270000)
  digest=hashlib.sha256(p.read_bytes()).hexdigest();self.assertEqual(backend.validate_firmware_file(str(p),digest)[1],digest)
  with self.assertRaises(backend.PagerError):backend.validate_firmware_file(str(p),'a'*64)
 def test_file_upload(self):
  p=self.p/'file.txt';p.write_text('hello');self.assertEqual(self.conn.upload_items([str(p)],'/root'),['file.txt']);self.assertEqual(self.fs.fs['/root/file.txt'],b'hello')
 def test_folder_upload(self):
  d=self.p/'payloads';(d/'sub').mkdir(parents=True);(d/'sub'/'test.txt').write_text('yes');self.conn.upload_items([str(d)],'/root');self.assertEqual(self.fs.fs['/root/payloads/sub/test.txt'],b'yes')
 def test_replace_requires_approval(self):
  p=self.p/'file.txt';p.write_text('new');self.fs.fs['/root/file.txt']=b'old'
  with self.assertRaises(backend.PagerError):self.conn.upload_items([str(p)],'/root')
  self.assertEqual(self.fs.fs['/root/file.txt'],b'old')
 def test_replace_success(self):
  p=self.p/'file.txt';p.write_text('new');self.fs.fs['/root/file.txt']=b'old';self.conn.upload_items([str(p)],'/root',overwrite_names={'file.txt'});self.assertEqual(self.fs.fs['/root/file.txt'],b'new')
 def test_rollback(self):
  p=self.p/'file.txt';p.write_text('new');self.fs.fs['/root/file.txt']=b'old';self.fs.fail_commit=True
  with self.assertRaises(backend.PagerError):self.conn.upload_items([str(p)],'/root',overwrite_names={'file.txt'})
  self.assertEqual(self.fs.fs['/root/file.txt'],b'old')
 def test_recursive_folder_delete(self):
  self.fs.fs['/root/a']=None;self.fs.fs['/root/a/b.txt']=b'x';self.conn.delete_path('/root/a');self.assertNotIn('/root/a',self.fs.fs)
 def test_protected_folder_delete(self):
  with self.assertRaises(backend.PagerError):self.conn.delete_path('/root/payloads')
 def test_symlink_rejected(self):
  d=self.p/'dir';d.mkdir();(d/'link').symlink_to(self.p)
  with self.assertRaises(backend.PagerError):self.conn.upload_items([str(d)],'/root')
 def test_firmware_signed_filename_version(self):
  self.assertEqual(backend.firmware_version_from_filename('pineapplepager-1.1.3-firmware-signed.bin'),'1.1.3')
  self.assertEqual(backend.firmware_version_from_filename('pineapplepager-1.1.2-stable-firmware-signed.bin'),'1.1.2-stable')
  self.assertIsNone(backend.firmware_version_from_filename('my-renamed-firmware.bin'))
 def test_firmware_compare_safe(self):
  self.assertEqual(backend.compare_firmware_versions('1.1.3','1.1.3'),'same')
  self.assertEqual(backend.compare_firmware_versions('v1.1.3','1.1.3'),'same')
  self.assertEqual(backend.compare_firmware_versions('1.1.3','1.1.4'),'different')
  self.assertEqual(backend.compare_firmware_versions('1.1.3','1.1.3-beta'),'different')
  self.assertEqual(backend.compare_firmware_versions(None,'1.1.3'),'unknown')
  self.assertEqual(backend.compare_firmware_versions('OpenWrt 23.05','1.1.3'),'unknown')
 def test_firmware_version_device_marker(self):
  class Device:
   def __init__(self,result):self.result=result
   def command(self,*args,**kwargs):return self.result
  self.assertEqual(backend.read_installed_firmware_version(Device((0,'1.1.3\n'))),'1.1.3')
  self.assertIsNone(backend.read_installed_firmware_version(Device((0,'23.05.1 OpenWrt'))))
  self.assertIsNone(backend.read_installed_firmware_version(Device((1,''))))
 def test_download_one_file(self):
  self.fs.fs['/root/item.txt']=b'hello';dest=self.p/'download.txt'
  ret=self.conn.download_item('/root/item.txt',str(dest))
  self.assertEqual(ret,str(dest));self.assertEqual(dest.read_bytes(),b'hello')
 def test_download_nested_folder(self):
  self.fs.fs['/root/samples']=None;self.fs.fs['/root/samples/deep']=None
  self.fs.fs['/root/samples/deep/a.txt']=b'data'
  dest=self.p/'samples';events=[]
  self.conn.download_item('/root/samples',str(dest),lambda d,t:events.append((d,t)))
  self.assertEqual((dest/'deep'/'a.txt').read_bytes(),b'data')
  self.assertEqual(events[-1],(4,4))
 def test_download_existing_protected(self):
  self.fs.fs['/root/file.txt']=b'server';dest=self.p/'file.txt';dest.write_bytes(b'local')
  with self.assertRaises(backend.PagerError):self.conn.download_item('/root/file.txt',str(dest))
  self.assertEqual(dest.read_bytes(),b'local')
 def test_download_rollback_on_error(self):
  self.fs.fs['/root/archive']=None;self.fs.fs['/root/archive/a.txt']=b'good'
  self.fs.fs['/root/archive/b.txt']=b'failed'
  orig=self.fs.get
  def fail(remote,local,callback=None):
   if remote.endswith('/b.txt'):raise IOError('connection dropped')
   return orig(remote,local,callback)
  self.fs.get=fail
  with self.assertRaises(backend.PagerError):self.conn.download_item('/root/archive',str(self.p/'archive'))
  self.assertFalse((self.p/'archive').exists())
  self.assertFalse(list(self.p.glob('.gs-download-*')))
 def test_v12_dnd_upload_only(self):
  source=(ROOT/'GS_WiFI_Pineapple_Pager_Companion_App.py').read_text(encoding='utf-8')
  self.assertNotIn('drag_source_register',source)
  self.assertNotIn('<<DragInitCmd>>',source)
  self.assertNotIn('_drag_out_init',source)
  self.assertIn('drop_target_register(DND_FILES)',source)
  self.assertIn('self._register_inbound_file_drops(self.main)',source)
  self.assertIn('widget.drop_target_register(DND_FILES)',source)
  self.assertIn('widget.dnd_bind("<<Drop>>", self._file_drop)',source)
  self.assertNotIn('drag_source_register(',source.replace('drag_source_register/DragInitCmd', ''))
  self.assertIn('self.file_tree.bind("<B1-Motion>", lambda _event: "break")',source)
  self.assertNotIn('file_tree.drop_target_register',source)
  self.assertNotIn('for drag to Windows Explorer',source)
  self.assertIn('DOWNLOAD TO YOUR COMPUTER',source)
  self.assertIn('V1.3  •  WINDOWS BETA',source)
 def test_v122_connection_tip_present_and_consistent(self):
  src=(ROOT/'GS_WiFI_Pineapple_Pager_Companion_App.py').read_text(encoding='utf-8')
  self.assertIn('PAGER CONNECTION TIP',src)
  self.assertIn('wait about 60 seconds',src)
  self.assertIn('try Connect to Pager again',src)
  self.assertIn('supports data',src)
  self.assertIn('"timeout" in message.lower()',src)
  self.assertIn('before plugging it into your computer',src)
 def test_v12_file_manager_button_downloads_folder(self):
  self.fs.fs['/root/my_folder']=None;self.fs.fs['/root/my_folder/subdir']=None
  self.fs.fs['/root/my_folder/subdir/hello.txt']=b'from Pager'
  results=[]
  d=types.SimpleNamespace(
   busy=False,connected=lambda:True,_selected_remote=lambda:('my_folder',True),
   remote_folder='/root',connection=self.conn,
   file_transfer_percent=types.SimpleNamespace(set=lambda x:None),
   file_transfer_status=types.SimpleNamespace(set=lambda x:None),
   queue=queue.SimpleQueue(),
   _start_task=lambda callback,tag:results.append((tag,callback())))
  with patch.object(app.filedialog,'askdirectory',return_value=str(self.p)):
   app.App.file_download(d)
  self.assertEqual(results[0][0],'download_item')
  self.assertEqual(results[0][1],str(self.p/'my_folder'))
  self.assertEqual((self.p/'my_folder'/'subdir'/'hello.txt').read_bytes(),b'from Pager')
 def test_v12_file_manager_button_downloads_file(self):
  self.fs.fs['/root/a.txt']=b'abc';results=[]
  d=types.SimpleNamespace(
   busy=False,connected=lambda:True,_selected_remote=lambda:('a.txt',False),
   remote_folder='/root',connection=self.conn,
   file_transfer_percent=types.SimpleNamespace(set=lambda x:None),
   file_transfer_status=types.SimpleNamespace(set=lambda x:None),
   queue=queue.SimpleQueue(),
   _start_task=lambda callback,tag:results.append((tag,callback())))
  with patch.object(app.filedialog,'askdirectory',return_value=str(self.p)):
   app.App.file_download(d)
  self.assertEqual(results[0],('download_item',str(self.p/'a.txt')))
  self.assertEqual((self.p/'a.txt').read_bytes(),b'abc')
 def test_v12_installer_uninstall_controls(self):
  installer=(ROOT.parents[1]/'installer'/'main.go').read_text(encoding='utf-8')
  self.assertIn('version = "1.3"',installer)
  self.assertIn('func removeManaged(path string)error',installer)
  self.assertIn('func managedFilePath(root, rel string)',installer)
  self.assertIn('func preservedFilesRoot()string',installer)
  self.assertIn('os.Rename(path,destination)',installer)
  self.assertIn('Pager Setup Staging',installer)
 def test_v122_installer_activity_feedback(self):
  installer=(ROOT.parents[1]/'installer'/'main.go').read_text(encoding='utf-8')
  self.assertIn('case WM_TIMER:',installer)
  self.assertIn('call(pSetTimer,hMain,activityTimerID,110,0)',installer)
  self.assertIn('call(pKillTimer,hMain,activityTimerID)',installer)
  self.assertIn('func refreshActivity()',installer)
  self.assertIn('hPulse=newWnd("STATIC"',installer)
  self.assertIn('activityStart=time.Now()',installer)
  self.assertIn('NEEDS ATTENTION',installer)
  self.assertIn('COMPLETED',installer)
  self.assertIn('Setup stages: %d%%',installer)
 def test_no_code_running_on_import(self):self.assertIsNone(getattr(backend,'connection',None))

class SSHHostKeyResetQA(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  self.path=pathlib.Path(self.temp.name)/'known_hosts'
 def test_reset_specific_host_preserves_other_hosts(self):
  self.path.write_text('# User-managed comment\n172.16.52.1 ssh-ed25519 AAAATESTPAGER\n192.168.1.1 ssh-rsa AAAAOTHER\n172.16.52.1 ssh-rsa AAAAOLDPAGER\n')
  self.assertEqual(backend.clear_saved_ssh_host_key('172.16.52.1',22,self.path),2)
  self.assertEqual(self.path.read_text(),'# User-managed comment\n192.168.1.1 ssh-rsa AAAAOTHER\n')
  self.assertIn('AAAAOLDPAGER',self.path.with_name('known_hosts.before_reset.bak').read_text())
 def test_reset_no_file_is_noop(self):
  self.assertEqual(backend.clear_saved_ssh_host_key('172.16.52.1',22,self.path),0)
  self.assertFalse(self.path.exists())
 def test_reset_unknown_host_preserves_file(self):
  original='192.168.1.1 ssh-ed25519 AAAAOTHER\n'
  self.path.write_text(original)
  self.assertEqual(backend.clear_saved_ssh_host_key('172.16.52.1',22,self.path),0)
  self.assertEqual(self.path.read_text(),original)
  self.assertFalse(self.path.with_name('known_hosts.before_reset.bak').exists())
 def test_reset_nondefault_port_only(self):
  self.path.write_text('[172.16.52.1]:2222 ssh-rsa AAAA2222\n172.16.52.1 ssh-rsa AAAA22\n')
  self.assertEqual(backend.clear_saved_ssh_host_key('172.16.52.1',2222,self.path),1)
  self.assertEqual(self.path.read_text(),'172.16.52.1 ssh-rsa AAAA22\n')
 def test_reset_comma_alias_only_removes_target(self):
  self.path.write_text('172.16.52.1,other-host ssh-ed25519 AAAASHARED\n')
  self.assertEqual(backend.clear_saved_ssh_host_key('172.16.52.1',22,self.path),1)
  self.assertEqual(self.path.read_text(),'other-host ssh-ed25519 AAAASHARED\n')
 def test_reset_rejects_bad_host_and_port(self):
  self.path.write_text('172.16.52.1 ssh-rsa AAAAOLD\n')
  for host,port in [('host\nother',22),('a,b',22),('172.16.52.1',0),('172.16.52.1',65536)]:
   with self.subTest(host=host,port=port),self.assertRaises(backend.PagerError):
    backend.clear_saved_ssh_host_key(host,port,self.path)
  self.assertIn('AAAAOLD',self.path.read_text())
 def test_reset_does_not_follow_symlink(self):
  target=pathlib.Path(self.temp.name)/'target';target.write_text('172.16.52.1 ssh-rsa AAAAOLD\n')
  self.path.symlink_to(target)
  with self.assertRaises(backend.PagerError):backend.clear_saved_ssh_host_key('172.16.52.1',22,self.path)
  self.assertIn('AAAAOLD',target.read_text())

if __name__=='__main__':unittest.main(verbosity=2)
