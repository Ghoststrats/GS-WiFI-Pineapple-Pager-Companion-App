"""Non-destructive simulated SSH/Pager firmware tests. Never flashes hardware."""
import sys
import tempfile
import pathlib
import unittest
from contextlib import contextmanager
from unittest import mock
from types import SimpleNamespace

ROOT = pathlib.Path(__file__).parent / 'app' / 'GS_WiFI_Pineapple_Pager_Companion_App'
sys.path.insert(0, str(ROOT))
import pager_backend as fw

class Clock:
    def __init__(self): self.now = 0.
    def monotonic(self): return self.now
    def sleep(self, n): self.now += n

class Channel:
    def __init__(self, command_ok=True): self.closed = False; self.command_ok=command_ok
    def exec_command(self, command):
        if not self.command_ok: raise IOError('command rejected')
        self.command=command
    def recv_ready(self): return False
    def recv(self, n):return b''
    def recv_stderr_ready(self): return False
    def recv_stderr(self,n):return b''
    def exit_status_ready(self): return False

class Transport:
    def __init__(self, ch):self.ch=ch
    def is_active(self):return True
    def open_session(self, timeout=None):return self.ch

class SFTP:
    def __init__(self, upload_path, digest): self.digest=digest
    def __enter__(self): return self
    def __exit__(self,*args):pass
    def put(self, local, dest,callback=None,confirm=None):
        self.last_dest=dest
        if callback: callback(250000,250000)

class Conn:
    def __init__(self, sftp, transport):
        self.client = self; self.host='172.16.52.1'; self.port=22
        self.sftp=sftp; self.transport=transport; self.closed=False
    def open_sftp(self):return self.sftp
    def command(self, cmd, timeout):
        if cmd == 'df -k /tmp | tail -n 1':return (0,'tmpfs 262144 50000 212144 20% /tmp')
        if cmd.startswith('sha256sum'):return (0, self.sftp.digest+'  firmware.bin')
        if cmd=='command -v INSTALL_FIRMWARE':return(0,'/usr/bin/INSTALL_FIRMWARE')
        raise AssertionError(cmd)
    def get_transport(self):return self.transport
    def close(self):self.closed=True

class FirmwareSimulation(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.path=pathlib.Path(self.tmp.name)/'pineapplepager-1.2.0-firmware-signed.bin'
        self.path.write_bytes(b'FAKE simulated firmware content' + b'Z'*275000)
        import hashlib
        self.digest=hashlib.sha256(self.path.read_bytes()).hexdigest()
        self.clock=Clock();self.events=[]
        self.sftp=SFTP(str(self.path),self.digest)
        self.ch=Channel();self.conn=Conn(self.sftp,Transport(self.ch))
    def invoke(self, seq):
        probes=iter(seq)
        @contextmanager
        def fake_connect(*args,**kwargs):
            status=next(probes,seq[-1])
            if not status:raise OSError('disconnected')
            yield object()
        with mock.patch.object(fw.time,'monotonic',self.clock.monotonic), mock.patch.object(fw.time,'sleep',self.clock.sleep),mock.patch.object(fw.socket,'create_connection',fake_connect):
            return fw.run_firmware_update(self.conn,str(self.path),'',lambda *a:self.events.append(a))
    def test_offline_and_return(self):
        # Two consecutive misses, then two successful probes: reconnect observed.
        result=self.invoke([True, True, False, False,True,True])
        self.assertEqual(result,'reconnected')
        self.assertFalse(self.conn.closed,'must not cut the command SSH connection during flash')
        self.assertEqual(sum(x[0]=='irreversible' for x in self.events),1)
        self.assertTrue(any(x[:3]==('stage','reboot','done') for x in self.events))
    def test_stays_online_never_claims_success(self):
        result=self.invoke([True])
        self.assertEqual(result,'command_sent_unconfirmed')
        self.assertFalse(self.conn.closed)
        self.assertTrue(any(x[:3]==('stage','reboot','unknown') for x in self.events))
        self.assertGreaterEqual(self.clock.now,900)
    def test_command_refused_does_not_claim_started(self):
        self.ch.command_ok=False
        with self.assertRaises(fw.PagerError): self.invoke([True])
        self.assertFalse(any(x[0]=='irreversible' for x in self.events))
    def test_short_command_times_out(self):
        channel=Channel()
        class Client:
            def exec_command(self,*a,**kw):return None,SimpleNamespace(channel=channel),None
            def get_transport(self):return SimpleNamespace(is_active=lambda:True)
        conn=fw.PagerConnection.__new__(fw.PagerConnection);conn.client=Client()
        channel.close=lambda: setattr(channel,'closed',True)
        with mock.patch.object(fw.time,'monotonic',self.clock.monotonic),mock.patch.object(fw.time,'sleep',self.clock.sleep):
            with self.assertRaisesRegex(fw.PagerError,'timed out'): conn.command('test',timeout=2)
        self.assertTrue(channel.closed)

if __name__=='__main__':unittest.main()
