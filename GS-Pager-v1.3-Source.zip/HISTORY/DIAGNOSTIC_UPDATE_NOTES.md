# Firmware diagnostic revision — V1.2.2 beta

This revision addresses an observability issue, **not a confirmed device-flashing fix**.

- The firmware tool's real stdout, stderr, and exit status are now visible in the application activity log. A successful SSH request no longer counts as evidence of a flash.
- An SSH disconnect or process exit no longer marks the actual firmware installation as complete.
- When no reboot is observed after 90 seconds, the application warns that firmware execution remains unconfirmed (and continues to monitor, without rebooting or retrying the device).
- Added **READ-ONLY: CHECK PAGER UPDATE READINESS**, available before flashing. It checks version, uptime, updater path, updater file permissions, and /tmp free storage. It never triggers a flash, reboot or modification.
- Never start a second firmware update while the previous attempt's status is unknown.
- The system's 15-minute observation limit cannot prove a flash succeeded or failed; the real firmware version must be checked on the device.

**Safety:** Test with a fully recovered, known-good device and official Hak5 firmware. Windows/physical hardware flashing was not available for testing here. Keep the Pager powered during any possible active update. Do not bypass antivirus alerts for unsigned installers.
