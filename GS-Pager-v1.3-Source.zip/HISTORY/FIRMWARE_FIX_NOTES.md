# Firmware Updater Reliability Hotfix — V1.2.2

This replaces the V1.2.2 Windows application and installer with a corrected build, without changing the advertised app version.

## What changed

- Fixed an installer-monitoring issue that could leave the firmware screen apparently frozen after the upload completed.
- Removed the blocking modal warning at the moment firmware installation begins. The DO NOT DISCONNECT message now appears directly in the status/log instead.
- Removed the deliberate close of the firmware SSH session after just 35 seconds. INSTALL_FIRMWARE is allowed to proceed without intentionally interrupting its channel.
- Added a visible running timer and activity indicator while the app monitors the Pager.
- Extended the restart observation window to a maximum of 15 minutes. SSH disconnects during flashing are not automatically treated as errors.
- Firmware progress is not fabricated: only SFTP upload percent is real. A dark/blank Pager display is not proof of success or failure.
- Added a Copy Activity Log button to the Firmware Update page to make troubleshooting easier without opening a terminal.
- Fixed SSH short-command status reads to have a real timeout, rather than potentially waiting forever for an exit status.
- Restart can only be reported as observed after SSH was unreachable at least twice and later reachable twice. The app still asks the user to check the firmware version on the Pager itself.

## Safety

Only use authentic Hak5 signed Pager firmware from https://downloads.hak5.org/ . Never interrupt power while an update might still be in progress. If the screen stays black and the Pager does not return, do not attempt repeated flashes; consult Hak5 official guidance: https://docs.hak5.org/wifi-pineapple-pager/updating/software-updates/ .

This release was tested with simulated SSH/Pager behavior and GUI smoke testing, **not a real flash on physical hardware**. No guarantee of successful flash or Windows Defender clearance is made. The Windows EXE is unsigned and should be scanned before use.

**Tests:** 37 existing automated tests plus 4 simulated firmware-monitor tests passed. Windows GUI launcher and setup were cross-compiled successfully; end-to-end Windows installation is unverified.
