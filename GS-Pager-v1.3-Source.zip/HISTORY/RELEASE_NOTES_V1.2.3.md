# GS WiFI Pineapple Pager Companion App — v1.2.3 Windows Beta

## Simplified firmware download screen (V1.2.3 beta refresh)

- **Firmware Update → Step 1** now shows a single **GRAB THE LATEST PAGER FIRMWARE HERE** button, opening Hak5's direct official endpoint in your default browser.
- Removed **DOWNLOAD INSIDE APP (ALTERNATIVE)** from the app.
- Removed **HAK5 DOWNLOAD PORTAL (IF LINK TIMES OUT)** and all automatic portal fallback suggestions. If the direct link fails, the app clearly says to retry later without opening another site.
- Keep **CHOOSE MY DOWNLOADED .BIN FILE** for the separate Windows-assisted update method. Downloading alone never flashes the Pager.

## Safer, clearer firmware updating

- **Recommended:** Use the Pager's own **Settings → Updates → Check for Updates** when it has internet access. A button opens Hak5's official instructions; the app does not remotely start that update.
- **Windows-assisted alternative:** Open the official latest-firmware link in your browser, then choose the downloaded signed `.bin` file. Downloading **never** starts flashing automatically.
- The direct firmware link opens in the default browser. No alternative in-app download or portal fallback is offered.
- Retains the existing optional published SHA-256 comparison and local-to-Pager SFTP SHA-256 verification. Only the Pager's documented `INSTALL_FIRMWARE` validates the image's actual signature/compatibility; filenames/checksums do not establish authenticity by themselves.
- Checks `/tmp` free space with a safety margin **before uploading**; fails without flashing if the check is unavailable or storage is insufficient.
- Uses a digest-based temporary filename, runs `INSTALL_FIRMWARE` through a dedicated SSH channel (not Virtual Pager), reports its real output/errors, and watches for loss/return of the SSH port without treating reconnection as proof of version change.
- Retains 15-minute monitoring and read-only diagnostic checks. Never blindly resends a firmware command after an uncertain outcome.

## Improved connection startup

- Retries temporary USB-network/SSH startup errors for up to **120 seconds**, with status updates.
- Incorrect credentials, unexpected host keys, and explicit user trust rejection do **not** trigger repeated attempts.
- Reminds users that reconnection after the Pager has finished booting can prompt Windows to rediscover the USB Ethernet interface. **Never disconnect or power off during a possible firmware update.**

## Existing features retained

- File manager, themes, SSH terminal, Virtual Pager links, installer animations, connection guidance, host-key reset, manual upload/download and file management.
- Updated application footer and installer title to **v1.2.3**. This is a beta for physical device validation.

## Verification and limitations

- Automated tests cover downloaded-file validation, official redirect restrictions, interrupted transfers and cleanup, SSH retries and authentication failures, insufficient-storage preflight, plus all previous simulated firmware and app tests.
- Windows installer and app launcher can be cross-compiled and ZIP integrity checked on Linux, but **real Windows antivirus, install/repair/uninstall and physical Pager flashing are not tested in this environment**.
- The Windows executable remains **unsigned**. A Microsoft Defender detection is not proof of a false positive; investigate it before running.
- If your Pager has a black screen or an uncertain prior flash, **do not attempt another flash**. Let it complete its recovery and use Hak5's official support procedure if it cannot boot normally.

**Official Hak5 update guide:** https://documentation.hak5.org/wifi-pineapple-pager/software-updates/software-updates.md

**Latest firmware direct download:** https://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest

This is an independent GhostStrats community application; not developed, sponsored or endorsed by Hak5.
