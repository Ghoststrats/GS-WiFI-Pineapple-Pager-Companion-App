### Update diagnostic revision (November 1, 2026)
- Added read-only readiness check to identify a missing updater or low temporary storage without flashing.
- Surface actual remote installer output and exit code; command accepted is no longer equated with firmware started.
- Clearly mark unverified installation/reboot status, never automatically retry flashing.

# Firmware Updater Reliability Hotfix — V1.2.2

This replaces the V1.2.2 Windows application and installer with a corrected build, without changing the advertised app version.

## What changed

- Fixed an installer-monitoring issue that could leave the firmware screen apparently frozen after the upload completed.
- Removed the blocking modal warning at the moment firmware installation begins. The DO NOT DISCONNECT message now appears directly in the status/log instead.
- Removed the deliberate close of the firmware SSH session after just 35 seconds. INSTALL_FIRMWARE is allowed to proceed without intentionally interrupting its channel.
- Added a visible running timer and activity indicator while the app monitors the Pager.
- Extended the restart observation window to a maximum of 15 minutes. SSH disconnects during flashing are not automatically treated as errors.
- Firmware progress is not fabricated: only SFTP upload percent is real. A dark/blank Pager display is not proof of success or failure.
- Added a Copy Activity Log button to the Firmware Update page to make troubleshooting easier without opening a terminal.
- Fixed SSH short-command status reads to have a real timeout, rather than potentially waiting forever for an exit status.
- Restart can only be reported as observed after SSH was unreachable at least twice and later reachable twice. The app still asks the user to check the firmware version on the Pager itself.

## Safety

Only use authentic Hak5 signed Pager firmware from https://downloads.hak5.org/ . Never interrupt power while an update might still be in progress. If the screen stays black and the Pager does not return, do not attempt repeated flashes; consult Hak5 official guidance: https://docs.hak5.org/wifi-pineapple-pager/updating/software-updates/ .

This release was tested with simulated SSH/Pager behavior and GUI smoke testing, **not a real flash on physical hardware**. No guarantee of successful flash or Windows Defender clearance is made. The Windows EXE is unsigned and should be scanned before use.

**Tests:** 37 existing automated tests plus 4 simulated firmware-monitor tests passed. Windows GUI launcher and setup were cross-compiled successfully; end-to-end Windows installation is unverified.

---

# GS WiFI Pineapple Pager Companion App — V1.2.2

## What's changed in V1.2.2

- **Quick firmware download:** In **Firmware Update → Step 1**, the button now reads **“GRAB THE LATEST PAGER FIRMWARE HERE”** and opens Hak5’s direct latest WiFi Pineapple Pager firmware download URL. No need to find the Pager on the downloads website.
- **Help & About:** The firmware link button also goes directly to the latest Pager firmware.
- **Version labels:** The app footer says **V1.2.2 • WINDOWS BETA**. The native Windows installer says **VERSION 1.2.2**, and its version/Windows uninstall registry entry is updated.
- **Release packages:** The installer EXE, Easy Install ZIP, and source ZIP have V1.2.2 filenames. The README and build instructions reference V1.2.2.

### Direct official firmware link

https://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest

The download button **opens the web browser** to retrieve official firmware; it does **not** flash the Pager automatically. Select your downloaded `.bin` file in the app and follow the existing backup and installation prompts.

**Unchanged:** All existing connection, virtual Pager, file management, theme, payload, SSH key reset, checks, and firmware installation features are retained.


### Installer activity indicator (refined V1.2.2 setup)

- **Animated lavender progress marker:** A highlight continuously moves across the setup progress track while installation, repair, or uninstall is running, including during long Python and dependency installation steps.
- **Live working indicator and elapsed time:** The status area shows an animated spinner and a running `MM:SS` timer, so users know setup has not frozen when a stage takes a while.
- **Stage-based progress:** Progress percentages update at actual workflow milestones; the animation never artificially increases the percentage to imply an unfinished task is complete.
- **Clear end state:** The activity indicator stops and the status changes to **COMPLETED** or **NEEDS ATTENTION**, as appropriate.
- **All other app features unchanged:** Installer install/repair/uninstall behavior is unchanged.


### Connection screen guidance (refined V1.2.2 app)

- Added a visible **Pager Connection Tip** directly above **CONNECT TO PAGER**: allow about **60 seconds after power-on** before connecting the Pager to the computer.
- If connection times out, **try Connect to Pager again** and check that the **USB-C cable transfers data** (some cables charge only).
- Updated the connection checklist, troubleshooting tip, and timeout error message to repeat the advice.
- Existing firmware download link, application features, and animated setup progress remain unchanged.

## Windows installation

1. Extract `GS_WiFI_Pineapple_Pager_Companion_App_V1.2.2_Easy_Install.zip`.
2. Double-click `GS_WiFI_Pineapple_Pager_Companion_App_Setup_V1.2.2.exe`.
3. Choose **Install / Upgrade** to update the existing installation.

The separate app launcher EXE runs the app from its installed folder (with its Python runtime and support files). The source ZIP is provided for inspection and modification. For a clean installation the Windows setup may need internet access to obtain Python or application dependencies.

This is an independent GhostStrats community project, not an official Hak5 product or endorsed by Hak5.

**Build validation:** The Go launcher and installer were cross-compiled for Windows x64 and the Python code was syntax-checked. A live Windows installation and a physical Pager firmware update still require testing on Windows and real hardware.
