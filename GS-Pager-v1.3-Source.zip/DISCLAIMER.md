# Disclaimer — V1.3

GS WiFI Pineapple Pager Companion App — V1.3

This is an independent GhostStrats community project, not an official Hak5 product and not developed, sponsored, or endorsed by Hak5.

Use only on devices and networks you own or are authorized to test. Use official firmware. Back up files and keep the Pager powered and connected while flashing. A display of the flashing screen does not prove installation completed; verify the installed version after reboot.

Only reset saved SSH trust after confirming the device is your own. Examine any unexpected host-key changes.

The Windows installer is unsigned; do not bypass a malware/antivirus detection without proper investigation. This software is provided as-is with no warranty. Shared Python is not removed by uninstalling the app.
