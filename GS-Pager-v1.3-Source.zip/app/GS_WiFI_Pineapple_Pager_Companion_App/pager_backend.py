"""Hak5 WiFi Pineapple Pager SFTP + official firmware installer backend.

No update is performed on import. SSH credentials are retained only in memory.
The firmware command is the official INSTALL_FIRMWARE, never sysupgrade.
"""
from __future__ import annotations

import hashlib
import tempfile
import urllib.request
from urllib.parse import urlsplit
import os
from pathlib import Path
import re
import shlex
import socket
import time
from typing import Callable

DEFAULT_HOST = "172.16.52.1"
DOWNLOAD_URL = "https://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest"
DOCS_URL = "https://documentation.hak5.org/wifi-pineapple-pager/software-updates/software-updates.md"
PORTAL_URL = "https://downloads.hak5.org/pineapple/pager"
# Hak5's documentation shows an example filename, not a mandatory format.
# Use this only for friendly UI guidance; firmware legitimacy is NOT determined
# by the filename. The on-device INSTALL_FIRMWARE command validates images.
EXAMPLE_NAME_RE = re.compile(r"^pineapplepager-[A-Za-z0-9.+_-]+-firmware-signed\.bin$", re.I)


def has_example_firmware_filename(path: str) -> bool:
    """Non-blocking hint. Never treat a matching name as signature proof."""
    return bool(EXAMPLE_NAME_RE.fullmatch(Path(path).name))

def _trusted_firmware_redirect(url: str) -> bool:
    """Only the official endpoint or Hak5's known Google Storage firmware bucket.

    Fail closed if their delivery infrastructure changes: users can select a
    downloaded file after the official link becomes available.
    """
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.username or parsed.password or parsed.port:
        return False
    if parsed.hostname == "downloads.hak5.org":
        return parsed.path == "/api/devices/wifipineapplepager/firmwares/latest"
    if parsed.hostname == "storage.googleapis.com":
        return parsed.path.startswith("/hak5-dl.appspot.com/wifipineapplepager/firmwares/") and parsed.path.endswith(".bin")
    return False


def download_official_firmware(destination: str, progress: Callable[[int, int | None], None] | None = None,
                               open_url=None) -> Path:
    """Download an official Hak5 .bin to disk atomically, never flash it.

    A different domain, HTML/API error response, interrupted transfer, or
    implausible file size fails without leaving a partial .bin behind.
    """
    folder = Path(destination)
    if not folder.is_dir():
        raise PagerError("Choose an existing download folder.")
    opener = open_url or urllib.request.urlopen
    partial = None
    try:
        response = opener(urllib.request.Request(DOWNLOAD_URL, headers={"User-Agent": "GS-Pager-Companion/1.3"}), timeout=30)
        with response as stream:
            final_url = stream.geturl()
            if not _trusted_firmware_redirect(final_url):
                raise PagerError("Firmware download redirected outside Hak5's approved delivery path. Please retry later.")
            target_name = Path(urlsplit(final_url).path).name
            if not re.fullmatch(r"[a-zA-Z0-9_.-]+\.bin", target_name):
                raise PagerError("The server did not return a firmware .bin file. Please retry later.")
            content_type = (stream.headers.get("Content-Type", "") or "").lower()
            if "text/html" in content_type or "application/json" in content_type:
                raise PagerError("Firmware download returned a web/API response instead of firmware. Please retry later.")
            header_length = stream.headers.get("Content-Length", "")
            total = int(header_length) if header_length.isdigit() else None
            if total is not None and not 256 * 1024 <= total <= 512 * 1024 * 1024:
                raise PagerError("Official download reported an unexpected file size.")
            target = folder / target_name
            if target.exists():
                raise PagerError("That firmware file already exists. Choose another folder or keep your existing download; it was not overwritten.")
            with tempfile.NamedTemporaryFile(mode="wb", prefix=".gs-pager-", suffix=".partial", dir=folder, delete=False) as tmp:
                partial = Path(tmp.name)
                received = 0
                while True:
                    block = stream.read(256 * 1024)
                    if not block:
                        break
                    received += len(block)
                    if received > 512 * 1024 * 1024:
                        raise PagerError("Firmware download exceeded the safety size limit.")
                    tmp.write(block)
                    if progress:
                        progress(received, total)
            if total is not None and received != total:
                raise PagerError("Firmware download was interrupted or incomplete. No firmware file was saved.")
            if received < 256 * 1024:
                raise PagerError("Firmware download was too small to be a real image.")
            with partial.open("rb") as check:
                if check.read(8).startswith((b"<html", b"<!DOCTYP", b"PK\x03\x04", b"MZ")):
                    raise PagerError("The server did not return a valid firmware download.")
            partial.replace(target)
            partial = None
            return target
    except PagerError:
        raise
    except (OSError, TimeoutError, ValueError) as exc:
        raise PagerError("Firmware download failed or timed out: " + str(exc) + ". Please retry later.") from exc
    finally:
        if partial:
            partial.unlink(missing_ok=True)


def connect_pager_with_retry(connection, on_status=None, max_wait=120, retry_pause=3):
    """Retry startup/network failures only; never retry credentials/trust errors."""
    ssh = get_ssh_lib()
    deadline = time.monotonic() + max_wait
    attempt = 0
    last_error = None
    while True:
        attempt += 1
        try:
            if on_status:
                on_status("Checking Pager USB network and SSH (attempt %d)…" % attempt)
            connection.connect(timeout=6)
            if on_status:
                on_status("Pager SSH is ready.")
            return connection
        except (ssh.AuthenticationException, ssh.BadHostKeyException, PagerError):
            raise
        except Exception as exc:
            last_error = exc
            # Never retry arbitrary errors such as unsupported SSH ciphers or malformed config.
            if not isinstance(exc, (OSError, TimeoutError, EOFError, ssh.SSHException)):
                raise
            connection.close()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise PagerError("Pager did not become SSH-ready within %d seconds. Check its boot screen, USB data cable, and Windows USB Ethernet adapter. Last error: %s" % (max_wait, type(last_error).__name__)) from exc
            if on_status:
                on_status("Waiting for USB network / SSH to finish starting. Retrying… (%ds left)" % int(remaining))
            time.sleep(min(retry_pause, remaining))


class PagerError(Exception):
    pass


def get_ssh_lib():
    try:
        import paramiko
    except ImportError as exc:
        raise PagerError("SSH support is missing. Please run the Windows installer again to restore SSH support.") from exc
    return paramiko


def validate_firmware_file(path: str, expected_sha256: str = "") -> tuple[Path, str]:
    file = Path(path)
    if not file.is_file():
        raise PagerError("Select a firmware file downloaded from Hak5.")
    # Filename templates are not a signature check: let the Pager's official
    # installer verify authenticity and device compatibility instead.
    if file.suffix.lower() != ".bin":
        raise PagerError("Please choose a .bin firmware file downloaded from Hak5 for the WiFi Pineapple Pager. ZIPs and other files cannot be installed here.")
    if not (256 * 1024 <= file.stat().st_size <= 512 * 1024 * 1024):
        raise PagerError("Unexpected firmware file size. Download a fresh signed Pager firmware from Hak5.")
    hasher = hashlib.sha256()
    with file.open("rb") as stream:
        first = stream.read(1024 * 1024)
        # Catch common accidental non-firmware selections renamed to .bin.
        if first.startswith((b"PK\x03\x04", b"MZ")):
            raise PagerError("This looks like a ZIP archive or Windows program, not a firmware image. Download the Pager .bin firmware directly from Hak5.")
        hasher.update(first)
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(chunk)
    digest = hasher.hexdigest()
    expected = expected_sha256.strip().lower().replace(" ", "")
    if expected and (not re.fullmatch(r"[a-f0-9]{64}", expected) or expected != digest):
        raise PagerError("The firmware SHA-256 does not match the value you provided. Installation stopped.")
    return file, digest


# Only an identifiable signed Pager firmware filename is eligible for an
# automatic same-version decision. Renamed .bin files remain installable.
SIGNED_VERSION_RE = re.compile(
    r"^pineapplepager[-_](v?\d+(?:\.\d+){1,3}(?:[-_.](?:stable|beta|alpha|rc\d*))?)[-_]firmware[-_]signed\.bin$",
    re.I,
)
VERSION_RE = re.compile(r"^v?\d+(?:\.\d+){1,3}(?:[-_.](?:stable|beta|alpha|rc\d*))?$", re.I)


def firmware_version_from_filename(path: str) -> str | None:
    """Read the claimed release version; never treat the name as proof of authenticity."""
    match = SIGNED_VERSION_RE.fullmatch(Path(path).name)
    return match.group(1) if match else None


def compare_firmware_versions(installed: str | None, selected: str | None) -> str:
    """'same', 'different', or 'unknown'; uncertain inputs never suppress a flash."""
    if not installed or not selected:
        return "unknown"
    a, b = installed.strip().lower().removeprefix("v"), selected.strip().lower().removeprefix("v")
    if not VERSION_RE.fullmatch(a) or not VERSION_RE.fullmatch(b):
        return "unknown"
    return "same" if a == b else "different"


def read_installed_firmware_version(connection) -> str | None:
    """Read a Pager-specific release marker, not the unrelated OpenWrt OS version.

    Some firmware builds may not expose a readable marker. In that case report
    unknown; do not claim the current version or skip a requested installation.
    """
    locations = ("/etc/pineapple/version", "/etc/pineapple/firmware_version",
                 "/pineapple/version", "/etc/pineapple-release")
    command = "for f in " + " ".join(shlex.quote(p) for p in locations) + (
        "; do if [ -f \"$f\" ]; then head -n 1 \"$f\"; exit 0; fi; done; exit 1"
    )
    try:
        status, output = connection.command(command, timeout=10)
    except Exception:
        return None
    if status != 0:
        return None
    candidate = output.strip().splitlines()[0].strip() if output.strip() else ""
    return candidate if VERSION_RE.fullmatch(candidate) else None


def clear_saved_ssh_host_key(host: str, port: int = 22, known_hosts: Path | None = None) -> int:
    """Forget only this Pager's SSH host key; never clear the complete trust store.

    Paramiko writes plain hostnames to its private known_hosts file. Keep other
    hosts, their keys, comments and formatting exactly as they were. The next
    connection uses the existing fingerprint confirmation before saving a key.
    """
    import tempfile
    import shutil

    hostname = host.strip()
    if (not hostname or len(hostname) > 253 or any(ch.isspace() or ch in ",/\\" for ch in hostname)):
        raise PagerError("Enter a valid Pager address before resetting its SSH key.")
    try:
        port = int(port)
    except (TypeError, ValueError) as exc:
        raise PagerError("The SSH port must be between 1 and 65535.") from exc
    if not 1 <= port <= 65535:
        raise PagerError("The SSH port must be between 1 and 65535.")
    path = Path(known_hosts) if known_hosts is not None else Path.home() / ".gs_pager_gui" / "known_hosts"
    if path.is_symlink():
        raise PagerError("The saved SSH key file is a symbolic link; reset was cancelled for safety.")
    if not path.exists():
        return 0
    if not path.is_file():
        raise PagerError("The saved SSH key location is not a file.")
    # Paramiko uses [host]:port for non-standard SSH ports.
    target = hostname if port == 22 else f"[{hostname}]:{port}"
    try:
        original = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        raise PagerError("Could not read saved SSH host keys; nothing was changed.") from exc
    changed = []
    count = 0
    for line in original.splitlines(keepends=True):
        fields = line.split(None, 2)
        if len(fields) < 3 or line.lstrip().startswith("#"):
            changed.append(line)
            continue
        aliases = fields[0].split(",")
        if target not in aliases:
            changed.append(line)
            continue
        count += 1
        remaining = [alias for alias in aliases if alias != target]
        if remaining:
            changed.append(line.replace(fields[0], ",".join(remaining), 1))
    if not count:
        return 0
    temp = None
    try:
        # Leave a recovery copy for the user, then update atomically.
        shutil.copy2(path, path.with_name("known_hosts.before_reset.bak"))
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", newline="", suffix=".tmp",
                                         prefix=".known_hosts-", dir=path.parent, delete=False) as stream:
            temp = Path(stream.name)
            stream.write("".join(changed))
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temp, path.stat().st_mode)
        os.replace(temp, path)
        return count
    except OSError as exc:
        raise PagerError("Could not save the updated SSH trust file; the original was not intentionally removed.") from exc
    finally:
        if temp is not None:
            temp.unlink(missing_ok=True)


class FingerprintPolicy:
    """A callback-driven, verified SSH first-use policy; changed keys are rejected."""
    def __init__(self, ask_user: Callable[[str, str], bool]):
        self.ask_user = ask_user

    def apply(self, client, known_hosts: Path):
        paramiko = get_ssh_lib()
        asker = self.ask_user
        class Policy(paramiko.MissingHostKeyPolicy):
            def missing_host_key(self, cl, hostname, key):
                fp = hashlib.sha256(key.asbytes()).digest()
                import base64
                fingerprint = base64.b64encode(fp).decode().rstrip("=")
                if not asker(hostname, "SHA256:" + fingerprint):
                    raise PagerError("Connection cancelled. The new SSH host key was not trusted.")
                cl.get_host_keys().add(hostname, key.get_name(), key)
                known_hosts.parent.mkdir(parents=True, exist_ok=True)
                cl.save_host_keys(str(known_hosts))
        client.set_missing_host_key_policy(Policy())


class PagerConnection:
    def __init__(self, host: str, port: int, username: str, password: str,
                 trust_cb: Callable[[str, str], bool]):
        self.host = host.strip()
        self.port = int(port)
        self.username = username.strip()
        self.password = password
        self.trust_cb = trust_cb
        self.client = None
        self.known_hosts = Path.home() / ".gs_pager_gui" / "known_hosts"

    def connect(self, timeout=9):
        paramiko = get_ssh_lib()
        if not self.host or not 0 < self.port < 65536 or not self.username or not self.password:
            raise PagerError("Enter the Pager address, username, and password first.")
        client = paramiko.SSHClient()
        if self.known_hosts.exists():
            client.load_host_keys(str(self.known_hosts))
        FingerprintPolicy(self.trust_cb).apply(client, self.known_hosts)
        try:
            client.connect(hostname=self.host, port=self.port, username=self.username,
                           password=self.password, timeout=timeout, auth_timeout=timeout,
                           banner_timeout=timeout, look_for_keys=False, allow_agent=False)
            client.get_transport().set_keepalive(20)
        except Exception:
            client.close()
            raise
        self.client = client
        return self

    def close(self):
        if self.client:
            self.client.close()
            self.client = None

    def command(self, cmd: str, timeout: float = 20) -> tuple[int, str]:
        """Run a short SSH command with a REAL deadline (even if it never exits).

        Paramiko's recv_exit_status() can wait forever when the remote process
        hangs; a socket timeout on exec_command alone does not bound this wait.
        """
        if not self.client:
            raise PagerError("Connect to your Pager first.")
        _stdin, stdout, stderr = self.client.exec_command(cmd, timeout=timeout)
        channel = stdout.channel
        deadline = time.monotonic() + timeout
        output = bytearray()
        try:
            while time.monotonic() < deadline:
                if channel.recv_ready():
                    output.extend(channel.recv(65536))
                if channel.recv_stderr_ready():
                    output.extend(channel.recv_stderr(65536))
                if len(output) > 1024 * 1024:
                    raise PagerError("Pager command returned too much output; stopped reading it.")
                if channel.exit_status_ready():
                    code = channel.recv_exit_status()
                    while channel.recv_ready():
                        output.extend(channel.recv(65536))
                    while channel.recv_stderr_ready():
                        output.extend(channel.recv_stderr(65536))
                    return code, output.decode("utf-8", errors="replace").strip()
                if channel.closed or not self.client.get_transport().is_active():
                    raise PagerError("Pager SSH connection was interrupted during a command.")
                time.sleep(.1)
            raise PagerError("Pager command timed out after " + str(int(timeout)) + " seconds.")
        finally:
            # Only called for short preflight/verification commands, NEVER the
            # long-running INSTALL_FIRMWARE command (which uses its own channel).
            channel.close()

    def list_folder(self, remote: str):
        with self.client.open_sftp() as sftp:
            return sorted(sftp.listdir_attr(remote), key=lambda x: (not bool(x.st_mode & 0o040000), x.filename.casefold()))

    def upload_file(self, local: str, remote_folder: str, on_progress=None):
        safe_name = Path(local).name
        dest = remote_folder.rstrip("/") + "/" + safe_name
        with self.client.open_sftp() as sftp:
            sftp.put(local, dest, callback=on_progress, confirm=True)
        return dest

    def upload_files(self, paths, remote_folder: str, overwrite_names=None, notify=None):
        """Upload selected files to the current Pager folder using one SFTP session.

        Each transfer is checked against existing remote names; replacements only
        happen after an explicit yes from the UI. Progress is actual transferred
        bytes (across files), not a guessed timer.
        """
        import posixpath
        files = [Path(p) for p in paths]
        if not files or any(not p.is_file() for p in files):
            raise PagerError("Choose existing files on your computer.")
        if len(files) > 100 or len({p.name for p in files}) != len(files):
            raise PagerError("Too many files or duplicate filenames selected.")
        approved_replacements = set(overwrite_names or ())
        total = sum(f.stat().st_size for f in files)
        completed = 0
        uploaded = []
        with self.client.open_sftp() as sftp:
            # Check the entire batch before modifying remote files.
            for file in files:
                dest = posixpath.join(remote_folder, file.name)
                try:
                    info = sftp.stat(dest)
                except OSError as exc:
                    # ENOENT means there is no existing remote file.
                    import errno
                    if getattr(exc, "errno", None) not in (errno.ENOENT, 2):
                        raise PagerError(f"Couldn't check whether '{file.name}' already exists on the Pager: {exc}") from exc
                else:
                    import stat
                    if stat.S_ISDIR(info.st_mode):
                        raise PagerError(f"'{file.name}' is a folder on the Pager. Rename your file first.")
                    if file.name not in approved_replacements:
                        raise PagerError(f"'{file.name}' already exists on the Pager. Refresh files and choose whether to replace it.")
            for index, file in enumerate(files, 1):
                dest = posixpath.join(remote_folder, file.name)
                base = completed
                if notify:
                    notify("progress", base, total, index, len(files), file.name)
                try:
                    def progress(sent, _size):
                        if notify:
                            notify("progress", base + sent, total, index, len(files), file.name)
                    sftp.put(str(file), dest, callback=progress, confirm=True)
                except Exception as exc:
                    raise PagerError(f"Couldn't upload '{file.name}': {exc}. Check the Pager connection and free space; a partial file may remain.") from exc
                completed += file.stat().st_size
                uploaded.append(file.name)
                if notify:
                    notify("file_complete", file.name)
        return uploaded

    def upload_items(self, paths, remote_folder, overwrite_names=None, notify=None):
        """Upload files or entire directory trees safely using SFTP staging.

        Existing destination entries are never modified until their replacement
        is fully uploaded. A failed commit attempts to restore the old entry.
        """
        import errno
        import posixpath
        import stat
        import uuid

        sources = [Path(p) for p in paths]
        if not sources or len(sources) > 100:
            raise PagerError("Choose between 1 and 100 files or folders.")
        if len({p.name.casefold() for p in sources}) != len(sources):
            raise PagerError("Duplicate destination names selected. Rename one before uploading.")
        selected = []
        total_bytes = 0
        for src in sources:
            if src.is_symlink() or not (src.is_file() or src.is_dir()):
                raise PagerError(f"Unsupported file or linked folder: {src.name}")
            tree = []
            if src.is_file():
                tree.append((src, ""))
            else:
                tree.append((src, ""))
                for parent, dirs, files in os.walk(src, followlinks=False):
                    dirs.sort(); files.sort()
                    for name in dirs + files:
                        child = Path(parent) / name
                        if child.is_symlink():
                            raise PagerError(f"Linked entries are not uploaded: {child}")
                        relative = child.relative_to(src).as_posix()
                        tree.append((child, relative))
                        if len(tree) > 20000:
                            raise PagerError("Folder contains too many entries (limit: 20,000).")
            total_bytes += sum(path.stat().st_size for path, _ in tree if path.is_file())
            selected.append((src, tree))
        approved = set(overwrite_names or ())
        done = 0
        results = []
        with self.client.open_sftp() as sftp:
            def exists(path):
                try:
                    return sftp.lstat(path)
                except OSError as e:
                    if getattr(e, "errno", None) in (errno.ENOENT, 2):
                        return None
                    raise
            def purge(path):
                mode = sftp.lstat(path).st_mode
                if stat.S_ISDIR(mode):
                    for filename in sftp.listdir(path):
                        purge(posixpath.join(path, filename))
                    sftp.rmdir(path)
                else:
                    sftp.remove(path)
            # Preflight names before uploading anything.
            for src, tree in selected:
                dest = posixpath.join(remote_folder, src.name)
                if exists(dest) is not None and src.name not in approved:
                    raise PagerError(f"'{src.name}' already exists. Confirm replacement or skip it.")
            for index, (src, tree) in enumerate(selected, 1):
                dest = posixpath.join(remote_folder, src.name)
                stage = posixpath.join(remote_folder, ".gs-upload-" + uuid.uuid4().hex)
                backup = posixpath.join(remote_folder, ".gs-backup-" + uuid.uuid4().hex)
                staged = False
                backed_up = False
                installed = False
                try:
                    if src.is_dir():
                        sftp.mkdir(stage); staged = True
                        for child, rel in tree[1:]:
                            remote_child = posixpath.join(stage, rel)
                            if child.is_dir():
                                sftp.mkdir(remote_child)
                            else:
                                base = done
                                sftp.put(str(child), remote_child,
                                         callback=(lambda sent, size, base=base, idx=index, name=src.name:
                                             notify("progress", base + sent, total_bytes, idx, len(selected), name) if notify else None),
                                         confirm=True)
                                done += child.stat().st_size
                    else:
                        staged = True
                        base = done
                        sftp.put(str(src), stage,
                                 callback=(lambda sent, size, base=base, idx=index, name=src.name:
                                     notify("progress", base + sent, total_bytes, idx, len(selected), name) if notify else None),
                                 confirm=True)
                        done += src.stat().st_size
                    if exists(dest) is not None:
                        sftp.rename(dest, backup)
                        backed_up = True
                    try:
                        sftp.rename(stage, dest)
                        installed = True
                    except Exception:
                        if backed_up:
                            sftp.rename(backup, dest)
                            backed_up = False
                        raise
                    if backed_up:
                        try:
                            purge(backup)
                        except OSError:
                            # The replacement succeeded; left-over backup is intentionally
                            # preserved instead of silently discarding the user's data.
                            if notify:
                                notify("notice", "Previous version preserved at " + backup)
                    results.append(src.name)
                    if notify:
                        notify("file_complete", src.name)
                except Exception as exc:
                    if backed_up and not installed and exists(dest) is None:
                        try:
                            sftp.rename(backup, dest)
                        except Exception:
                            pass
                    raise PagerError(f"Upload failed for '{src.name}': {exc}. The previous item should remain intact; refresh before retrying.") from exc
                finally:
                    if staged and not installed and exists(stage) is not None:
                        try:
                            purge(stage)
                        except OSError:
                            pass
        return results


    def download_item(self, remote: str, local: str, on_progress=None):
        """Download a file or complete directory safely, without partial final copies.

        Files are transferred to a sibling temporary path, then renamed to
        the destination only after success. Remote symlinks and unsafe paths
        are rejected, and existing local contents are never overwritten.
        """
        import posixpath
        import shutil
        import stat
        import uuid

        destination = Path(local)
        if not destination.parent.is_dir():
            raise PagerError("Choose an existing folder on your computer.")
        if destination.exists() or destination.is_symlink():
            raise PagerError("That name already exists on your computer. Choose another destination.")
        remote = posixpath.normpath(remote)
        if not remote.startswith("/") or remote == "/":
            raise PagerError("Select one Pager file or folder to download.")
        stage = destination.with_name(".gs-download-" + uuid.uuid4().hex)
        completed = 0
        count = 0
        size_total = 0
        try:
            with self.client.open_sftp() as sftp:
                def check_name(name):
                    if name in ("", ".", "..") or "/" in name or "\\" in name or "\x00" in name:
                        raise PagerError("A Pager folder contains an unsafe filename; download cancelled.")

                def inventory(path, relative="", depth=0):
                    nonlocal count, size_total
                    if depth > 35:
                        raise PagerError("This folder is nested too deeply to download safely.")
                    meta = sftp.lstat(path)
                    if stat.S_ISLNK(meta.st_mode) or not (stat.S_ISDIR(meta.st_mode) or stat.S_ISREG(meta.st_mode)):
                        raise PagerError("Linked or special device files cannot be downloaded safely: " + path)
                    count += 1
                    if count > 20000:
                        raise PagerError("This folder contains more than 20,000 items.")
                    if stat.S_ISDIR(meta.st_mode):
                        children = [(name, *inventory(posixpath.join(path, name),
                                   relative + "/" + name if relative else name, depth + 1))
                                    for name in sorted(sftp.listdir(path)) for _ in (check_name(name),)]
                        return True, children
                    size_total += meta.st_size
                    if size_total > 8 * 1024**3:
                        raise PagerError("This download exceeds the 8 GB safety limit.")
                    return False, meta.st_size

                is_dir, tree = inventory(remote)
                if is_dir:
                    stage.mkdir()
                    def copy_tree(path, at, children):
                        nonlocal completed
                        for name, child_is_dir, child_data in children:
                            local_child = at / name
                            remote_child = posixpath.join(path, name)
                            if child_is_dir:
                                local_child.mkdir()
                                copy_tree(remote_child, local_child, child_data)
                            else:
                                base = completed
                                sftp.get(remote_child, str(local_child),
                                         callback=lambda sent, _total, base=base: on_progress(base + sent, size_total) if on_progress else None)
                                completed += child_data
                    copy_tree(remote, stage, tree)
                else:
                    sftp.get(remote, str(stage),
                             callback=lambda sent, _total: on_progress(sent, size_total) if on_progress else None)
                if destination.exists():
                    raise PagerError("The destination appeared during transfer. Your existing file was not touched.")
                stage.rename(destination)
                return str(destination)
        except Exception as exc:
            if stage.is_dir():
                shutil.rmtree(stage, ignore_errors=True)
            elif stage.exists():
                try: stage.unlink()
                except OSError: pass
            if isinstance(exc, PagerError):
                raise
            raise PagerError("Could not download the Pager item: " + str(exc)) from exc

    def delete_path(self, remote: str):
        """Delete a selected file or directory, with protection for root/system folders."""
        import posixpath
        import stat
        target = posixpath.normpath(remote)
        roots = {"/", "/root", "/mmc", "/mmc/root", "/root/payloads", "/root/themes",
                 "/mmc/root/payloads", "/mmc/root/themes", "/root/payloads/user",
                 "/mmc/root/payloads/user"}
        if not target.startswith("/") or target in roots or target.count("/") < 2:
            raise PagerError("This is a protected Pager folder. Select an individual file or subfolder instead.")
        with self.client.open_sftp() as sftp:
            def remove(path):
                meta = sftp.lstat(path)
                if stat.S_ISDIR(meta.st_mode):
                    for filename in sftp.listdir(path):
                        remove(posixpath.join(path, filename))
                    sftp.rmdir(path)
                else:
                    sftp.remove(path)
            remove(target)

    def read_preview(self, remote: str, max_bytes: int = 1024 * 1024):
        """Read at most 1 MB of a remote file for a safe read-only preview."""
        with self.client.open_sftp() as sftp:
            meta = sftp.stat(remote)
            if meta.st_size > max_bytes:
                raise PagerError("This file is too large to preview. Use Download to save it to your PC.")
            with sftp.open(remote, "rb") as handle:
                return handle.read(max_bytes + 1)

    def download_file(self, remote: str, local: str, on_progress=None):
        with self.client.open_sftp() as sftp:
            sftp.get(remote, local, callback=on_progress)

    def make_folder(self, remote: str):
        with self.client.open_sftp() as sftp:
            sftp.mkdir(remote)

    def delete_file(self, remote: str):
        with self.client.open_sftp() as sftp:
            sftp.remove(remote)


def check_pager_update_readiness(connection: PagerConnection) -> str:
    """Read-only checks for troubleshooting a stalled firmware update.

    Never executes INSTALL_FIRMWARE, reboots, modifies files, or clears logs.
    Report contains no credentials. Review any details before sharing publicly.
    """
    checks = (
        ("Pager version", "cat /etc/version 2>/dev/null || echo unavailable"),
        ("Device uptime", "uptime"),
        ("Official updater path", "command -v INSTALL_FIRMWARE"),
        ("Updater file details", "ls -l $(command -v INSTALL_FIRMWARE)"),
        ("Temporary storage", "df -k /tmp"),
    )
    report = ["GS PAGER - READ-ONLY UPDATE DIAGNOSTICS", "No flash, reboot or file changes were initiated."]
    for label, command in checks:
        try:
            status, output = connection.command(command, timeout=12)
            value = (output or "(no output)")[:1200]
            report.append("\n" + label + " [exit " + str(status) + "]:\n" + value)
        except Exception as exc:
            report.append("\n" + label + ": unavailable (" + type(exc).__name__ + ")")
    return "\n".join(report)


def run_firmware_update(connection: PagerConnection, firmware_path: str, expected_sha: str,
                        emit: Callable[..., None]) -> str:
    """Executes an update; reports stages but never pretends to know on-device flash percent.

    Return one of 'reconnected', 'command_sent_unconfirmed'. Exception before command
    means the firmware installer was not started. After launch, errors are conservative.
    """
    file, digest = validate_firmware_file(firmware_path, expected_sha)
    remote_path = "/tmp/gs-pager-" + digest[:16] + ".bin"
    emit("stage", "upload", "running", "Checking temporary storage and uploading firmware")
    # BusyBox/OpenWrt-compatible free-space check; fail closed if space cannot
    # be measured. The installer itself also needs working room in /tmp.
    status, space = connection.command("df -k /tmp | tail -n 1", timeout=12)
    columns = space.strip().split()
    if status != 0 or len(columns) < 4 or not columns[3].isdigit():
        raise PagerError("Could not verify free /tmp space. No firmware update was started. Check Pager storage first.")
    free_bytes = int(columns[3]) * 1024
    if free_bytes < file.stat().st_size + (16 * 1024 * 1024):
        raise PagerError("Not enough free /tmp space for the image and safety margin. No firmware update was started.")
    emit("progress", 0)
    try:
        with connection.client.open_sftp() as sftp:
            sftp.put(str(file), remote_path, callback=lambda done, total: emit("progress", int(done * 100 / max(total, 1))), confirm=True)
        emit("progress", 100)
        emit("stage", "upload", "done", "Firmware uploaded")

        emit("stage", "verify", "running", "Checking the file on your Pager")
        status, output = connection.command("sha256sum " + shlex.quote(remote_path), timeout=30)
        remote_digest = output.split()[0].lower() if output else ""
        if status != 0 or remote_digest != digest:
            raise PagerError("The upload did not pass SHA-256 verification. Firmware installation was NOT started.")
        emit("stage", "verify", "done", "File verified: local and Pager copies match")

        status, output = connection.command("command -v INSTALL_FIRMWARE", timeout=15)
        if status != 0:
            raise PagerError("The Pager's official INSTALL_FIRMWARE command was not found. Installation was NOT started.")

    except Exception:
        emit("stage", "verify", "error", "Upload or verification failed; installer not started")
        raise

    # Launch the official installer over a dedicated SSH channel. Do not
    # deliberately close this session after 35 seconds: services may take longer
    # to stop, and severing SSH ourselves can obscure actual device status.
    emit("stage", "install", "running", "Sending official INSTALL_FIRMWARE command; keep power connected")
    command = "INSTALL_FIRMWARE " + shlex.quote(remote_path)
    try:
        transport = connection.client.get_transport()
        if transport is None or not transport.is_active():
            raise PagerError("SSH disconnected before the firmware command could be sent. Check your Pager before retrying.")
        channel = transport.open_session(timeout=12)
        channel.exec_command(command)
    except Exception as exc:
        emit("stage", "install", "unknown", "Cannot confirm the installer was started")
        raise PagerError("The INSTALL_FIRMWARE command could not be confirmed. Check the device before attempting another update.") from exc

    # Once the command has been handed to SSH, treat it as irreversible.
    emit("irreversible")
    emit("log", "Firmware command sent; waiting for the Pager to reboot. The display may turn dark.")
    # Firmware installation is not externally observable as a percentage.
    # The first boot may be unusually slow (Hak5's official documentation).
    # Poll without closing the original SSH connection and without running
    # additional shell commands on the device during flashing.
    deadline = time.monotonic() + 900
    next_probe = 0.0
    next_note = 0.0
    saw_exit = False
    saw_offline = False
    consecutive_offline = 0
    consecutive_online = 0
    install_status_announced = False
    output = bytearray()
    last_output = 0.0
    first_unconfirmed_note = False
    logged_exit = False
    while time.monotonic() < deadline:
        now = time.monotonic()
        try:
            for stream, receiver, ready in (("stdout", channel.recv, channel.recv_ready),
                                             ("stderr", channel.recv_stderr, channel.recv_stderr_ready)):
                # Stream output as it arrives: previously the application silently
                # swallowed the firmware tool's errors/prompts until it exited.
                for _ in range(4):
                    if not ready():
                        break
                    chunk = receiver(4096)
                    if not chunk:
                        break
                    if len(output) < 32768:
                        output.extend(chunk[:32768-len(output)])
                    visible = " ".join(chunk.decode("utf-8", errors="replace").split())
                    if visible:
                        emit("log", "INSTALL_FIRMWARE " + stream + ": " + visible[:900])
                        last_output = now
                        if any(marker in visible.casefold() for marker in ("[y/n]", "[yes/no]", "press enter", "are you sure")):
                            emit("log", "WARNING: installer may be awaiting interactive input. No response was sent by the app.")
            if not saw_exit and channel.exit_status_ready():
                saw_exit = True
                code = channel.recv_exit_status()
                logged_exit = True
                emit("log", "INSTALL_FIRMWARE SSH process exit status: " + str(code))
                if code != 0:
                    details = output.decode("utf-8", errors="replace").strip()[-700:]
                    emit("stage", "install", "error", "Official installer returned a nonzero exit status")
                    raise PagerError("Pager firmware installer failed (exit " + str(code) + "). " + details)
                emit("log", "Exit 0 alone does not prove firmware flashing began; monitoring for a real reboot.")
                emit("stage", "install", "unknown", "Command exited 0; firmware installation has NOT been verified")
            if (saw_exit or channel.closed or not transport.is_active()) and not install_status_announced:
                if not saw_exit:
                    emit("stage", "install", "unknown", "SSH closed; whether firmware started is unconfirmed")
                emit("stage", "reboot", "running", "Watching for the Pager to go offline, then return")
                install_status_announced = True
        except PagerError:
            raise
        except Exception as exc:
            # The SSH daemon can terminate during an official firmware update.
            # Monitor the independent TCP restart signal rather than treating
            # a transport exception as proof of either success or failure.
            emit("log", "SSH channel changed during installation: " + str(exc))
            if not install_status_announced:
                emit("stage", "install", "unknown", "SSH session stopped; device installation remains unverified")
                emit("stage", "reboot", "running", "Watching for the Pager to reboot")
                install_status_announced = True

        if now >= next_probe:
            next_probe = now + 7
            try:
                with socket.create_connection((connection.host, connection.port), timeout=2):
                    online = True
            except OSError:
                online = False
            if online:
                consecutive_offline = 0
                if saw_offline:
                    consecutive_online += 1
            else:
                consecutive_online = 0
                consecutive_offline += 1
                if consecutive_offline >= 2 and not saw_offline:
                    saw_offline = True
                    emit("log", "Pager SSH became unreachable. This can happen during flashing and reboot.")
                    if not install_status_announced:
                        emit("stage", "install", "unknown", "Pager went offline; flash completion not yet verified")
                        emit("stage", "reboot", "running", "Waiting for the Pager to come back online")
                        install_status_announced = True
            if saw_offline and consecutive_online >= 2:
                emit("stage", "reboot", "done", "Pager SSH port returned; verify firmware version on device")
                return "reconnected"

        if now >= next_note:
            if now - (deadline - 900) >= 90 and not saw_offline and not first_unconfirmed_note:
                first_unconfirmed_note = True
                emit("log", "No Pager reboot detected after 90 seconds. Firmware may be running, waiting for input, or not started. Do NOT retry while status is unknown.")
                emit("stage", "install", "unknown", "No firmware start confirmation; checking for reboot")
                emit("stage", "reboot", "running", "Waiting for actual offline/online reboot evidence")
            remaining = max(0, int(deadline - now))
            emit("log", "Still monitoring firmware/reboot; " + str(remaining // 60) + " min left before status becomes unconfirmed.")
            next_note = now + 30
        time.sleep(.35)

    if not install_status_announced:
        emit("stage", "install", "unknown", "Installer did not confirm completion; avoid another flash until device is checked")
    emit("stage", "reboot", "unknown", "Reboot not confirmed in 15 minutes; check the Pager before retrying")
    return "command_sent_unconfirmed"
