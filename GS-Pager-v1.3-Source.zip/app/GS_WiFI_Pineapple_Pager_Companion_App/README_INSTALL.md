GS WiFI Pineapple Pager Companion App — V1.3 (Windows Beta)

To install, extract GS_WiFI_Pineapple_Pager_Companion_App_V1.3_Easy_Install.zip and run GS_WiFI_Pineapple_Pager_Companion_App_Setup_V1.3.exe.

Choose Install / Upgrade and allow the setup process to finish. An animated indicator and timer show activity during long steps. After your Pager powers on, wait around 60 seconds and use a USB-C data-transfer cable to connect.

Firmware downloads: https://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest
Use official signed firmware only. Follow the in-app safety guidance and do not interrupt an active flash.
