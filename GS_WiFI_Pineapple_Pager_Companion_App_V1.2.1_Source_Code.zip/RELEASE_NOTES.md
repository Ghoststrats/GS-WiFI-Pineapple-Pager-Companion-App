# GS WiFI Pineapple Pager Companion App — V1.2.1 Release

## What's changed

### New: Reset Saved SSH Key

After you intentionally factory-reset or reflash your WiFi Pineapple Pager, the device may generate a new SSH host key. To reconnect safely, open **Connect Device** and select **Reset Saved SSH Key**. Confirm the action for your own Pager, then verify and approve the new host-key fingerprint when you reconnect.

- Removes **only** the saved key matching the selected Pager address and SSH port.
- Preserves SSH trust entries for other devices and backs up the previous trust file.
- Does not automatically trust a replacement key: you must review its fingerprint.
- If the host key changes unexpectedly, investigate instead of immediately resetting it.

### V1.2 file manager fixes retained

- Drag and drop **from Windows to the application** to upload files or folders.
- Dragging **from the application to Windows Explorer** remains disabled for stability.
- Use **Download to Your Computer** to download a selected file or complete folder (including subfolders).

### Version and package labeling

- App footer and installer version are now **V1.2.1**.
- Installer, Easy Install ZIP, and Source Code ZIP are labeled **V1.2.1**.
- README and disclaimer version references are updated.

**All existing branding, themes, other features, and installer behavior are unchanged.**

## Installation

1. Download `GS_WiFI_Pineapple_Pager_Companion_App_V1.2.1_Easy_Install.zip`.
2. Extract it and run `GS_WiFI_Pineapple_Pager_Companion_App_Setup_V1.2.1.exe`.
3. Choose **Install / Upgrade**, then reconnect your Pager.

## Disclaimer

This is an independent GhostStrats community project, **not an official Hak5 product**, and is not affiliated with or endorsed by Hak5. Use official firmware and back up important device data. The full Windows install/upgrade/uninstall flow and actual physical Pager interactions still require testing on the target hardware.
