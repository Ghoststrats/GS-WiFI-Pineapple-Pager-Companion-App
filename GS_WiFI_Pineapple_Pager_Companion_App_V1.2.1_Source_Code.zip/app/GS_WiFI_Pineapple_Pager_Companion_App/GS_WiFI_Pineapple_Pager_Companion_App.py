"""GS WiFI Pineapple Pager Companion App — readable, connection-first Windows desktop app.

Firmware installation is never automatic on connect or selection: a deliberate
START FIRMWARE UPDATE click is required. All SSH/SFTP work stays off the UI thread.
"""
from __future__ import annotations

import datetime
import base64
import json
import os
import tempfile
import shutil
import subprocess
import sys
import urllib.request
import urllib.error
from urllib.parse import urlsplit
from pathlib import Path
import posixpath
import queue
import re
import stat
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, simpledialog

# Native Windows Explorer file drops via Tcl/TkDND. The Upload Files button
# remains available if the optional drag/drop runtime cannot be installed.
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
except ImportError:
    TkinterDnD, DND_FILES = None, None
DND_ROOT = TkinterDnD.Tk if TkinterDnD is not None else tk.Tk
import webbrowser

from pager_backend import (
    DEFAULT_HOST, DOCS_URL, DOWNLOAD_URL, PagerConnection, PagerError,
    run_firmware_update, validate_firmware_file, has_example_firmware_filename,
    firmware_version_from_filename, read_installed_firmware_version, compare_firmware_versions,
    clear_saved_ssh_host_key,
)

# These are app themes. They change the Windows GUI, not the physical Pager's theme.
THEMES = {
    "slate": {
        "name": "Black & Gray", "description": "Minimal, neutral, and easy to read",
        "bg": "#0d0e11", "side": "#14161b", "panel": "#1c2026",
        "input": "#2a3039", "line": "#444b57", "accent": "#e0e3eb",
        "primary": "#46515f", "hover": "#5d6a7b",
    },
    "yellow": {
        "name": "Black & Yellow", "description": "Your yellow-and-black Pager artwork, with readable dark panels",
        "bg": "#0d0e10", "side": "#151617", "panel": "#1e2022",
        "input": "#292c2e", "line": "#555148", "accent": "#f6d559",
        "primary": "#866718", "hover": "#a18123",
    },
    "purple": {
        "name": "GhostStrats Purple", "description": "The GhostStrats signature look",
        "bg": "#0c0f18", "side": "#121624", "panel": "#1a2030",
        "input": "#252d40", "line": "#394257", "accent": "#ae8aff",
        "primary": "#7955dd", "hover": "#906bfa",
    },
}
SETTINGS_PATH = Path.home() / ".gs_pager_gui" / "settings.json"
FONT = "Segoe UI"
APP_TITLE = "GS WiFI Pineapple Pager Companion App"
APP_ICON = Path(__file__).with_name("GS_Pager.ico")
HEADER_ART = Path(__file__).with_name("ghoststrats_glitch_banner.png")
YELLOW_HEADER_ART = Path(__file__).with_name("gs_yellow_header.png")
YELLOW_HERO_ART = Path(__file__).with_name("gs_yellow_hero.png")
YELLOW_WALLPAPER = Path(__file__).with_name("gs_yellow_wallpaper.png")
HAK5_REPO = "https://github.com/hak5/wifipineapplepager"
HAK5_PAYLOADS = "https://github.com/hak5/wifipineapplepager-payloads"
HAK5_THEMES = "https://github.com/hak5/wifipineapplepager-themes"
WHITE = "#ffffff"
MUTED = "#c5cad9"
GREEN = "#65e0ac"
AMBER = "#ffd080"
RED = "#ff9096"
BLUE = "#89caff"


def apply_theme(name):
    global BG, SIDE, PANEL, INPUT, LINE, ACCENT, PURPLE, PRIMARY_HOVER
    theme = THEMES.get(name, THEMES["slate"])
    BG, SIDE, PANEL, INPUT, LINE = (theme[k] for k in ("bg", "side", "panel", "input", "line"))
    ACCENT, PURPLE, PRIMARY_HOVER = theme["accent"], theme["primary"], theme["hover"]


def read_settings(path=SETTINGS_PATH):
    try:
        settings = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {"theme": "slate", "text_size": "Comfortable"}
    theme = settings.get("theme", "slate")
    text_size = settings.get("text_size", "Comfortable")
    return {"theme": theme if theme in THEMES else "slate",
            "text_size": text_size if text_size in ("Comfortable", "Extra large") else "Comfortable"}


def save_settings(theme, text_size, path=SETTINGS_PATH):
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps({"theme": theme, "text_size": text_size}, indent=2)
    temp_path = path.with_name(path.name + ".tmp")
    temp_path.write_text(payload, encoding="utf-8")
    os.replace(temp_path, path)


def virtual_pager_url(host):
    """Known Hak5 management UI port; custom SSH hosts use that same port."""
    host = host.strip()
    if (not host or len(host) > 253 or any(c in host for c in '/\\?#@:')
            or any(c.isspace() for c in host)):
        raise ValueError("Enter a valid Pager IP address or hostname first.")
    # Hostnames may have '-' and dots; no URL escapes or arbitrary full URLs.
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", host):
        raise ValueError("The Pager address contains unsupported characters.")
    return f"http://{host}:1471/"


def check_virtual_pager(url, timeout=5):
    """Probe the local management service; a 401/403 is still a reachable login."""
    request = urllib.request.Request(url, headers={"User-Agent": "GS-Pager-GUI/6"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            status = response.status
    except urllib.error.HTTPError as error:
        status = error.code
    except (urllib.error.URLError, OSError, TimeoutError) as error:
        raise RuntimeError("Virtual Pager did not respond at " + url +
                           "\nCheck the USB-C connection, Pager power, and device setup.") from error
    if not 200 <= status < 400 and status not in (401, 403):
        raise RuntimeError(f"The Pager web interface returned HTTP {status}. Try again or open in your browser.")
    return url


apply_theme("slate")


def text(parent, value, size=13, color=WHITE, bold=False, wrap=None, **opts):
    return tk.Label(parent, text=value, bg=parent.cget("bg"), fg=color,
                    font=(FONT, size, "bold" if bold else "normal"),
                    anchor="w", justify="left", wraplength=wrap or 1200, **opts)


def action(parent, title, callback, primary=False, danger=False, big=False):
    background = PURPLE if primary else ("#623443" if danger else INPUT)
    hover = PRIMARY_HOVER if primary else ("#784556" if danger else "#343f56")
    b = tk.Button(parent, text=title, command=callback, font=(FONT, 14 if big else 12, "bold"),
                  fg=WHITE, bg=background, activebackground=hover,
                  activeforeground=WHITE, padx=22 if big else 16,
                  pady=17 if big else 12, bd=0, relief="flat", cursor="hand2",
                  highlightthickness=0)
    b.bind("<Enter>", lambda _: b.config(bg=hover) if b.cget("state") == "normal" else None)
    b.bind("<Leave>", lambda _: b.config(bg=background) if b.cget("state") == "normal" else None)
    return b


def field(parent, var, secret=False, width=18):
    return tk.Entry(parent, textvariable=var, show="●" if secret else "", width=width,
                    font=(FONT, 15), fg=WHITE, bg=INPUT, insertbackground=WHITE,
                    relief="flat", bd=0, highlightthickness=1,
                    highlightbackground=LINE, highlightcolor=ACCENT)


def card(parent, padding=23):
    border = tk.Frame(parent, bg=LINE, padx=1, pady=1)
    content = tk.Frame(border, bg=PANEL, padx=padding, pady=padding)
    content.pack(fill="both", expand=True)
    return border, content


class ScrollingContent(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=BG)
        self.canvas = tk.Canvas(self, bg=BG, bd=0, highlightthickness=0)
        self.scrollbar = tk.Scrollbar(self, orient="vertical", command=self.canvas.yview,
                                      bg=INPUT, troughcolor=BG, width=14)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", expand=True, fill="both")
        self.inner = tk.Frame(self.canvas, bg=BG)
        self.window_id = self.canvas.create_window((0, 0), anchor="nw", window=self.inner)
        self.inner.bind("<Configure>", self._size_scrollregion)
        self.canvas.bind("<Configure>", self._size_width)

    def _size_scrollregion(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _size_width(self, event):
        self.canvas.itemconfigure(self.window_id, width=max(100, event.width - 14))

    def top(self):
        self.canvas.yview_moveto(0)


class App(DND_ROOT):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        if APP_ICON.exists():
            try:
                self.iconbitmap(str(APP_ICON))
            except tk.TclError:
                pass
        self.geometry("1360x880")
        self.minsize(975, 690)
        self.preferences = read_settings()
        self.theme_name = self.preferences["theme"]
        self.text_size = self.preferences["text_size"]
        apply_theme(self.theme_name)
        self.configure(bg=BG)
        try:
            self.tk.call("tk", "scaling", 1.35 if self.text_size == "Extra large" else 1.18)
        except tk.TclError:
            pass

        self.queue = queue.Queue()
        self.connection = None
        self.connected_installer = False
        self.busy = False
        self.current_task = None
        self.issued_install = False
        self.selected_firmware = ""
        self.log_lines = []
        self.page = "Connect Device"
        self.dragdrop_enabled = TkinterDnD is not None
        self.file_transfer_percent = tk.IntVar(value=0)
        self.file_transfer_status = tk.StringVar(value="Ready to upload files")
        self.file_last_result = ""
        self.remote_folder = "/root"
        self.folder_history = []
        self.opened_pc_files = []
        self.firmware_warning_shown = False
        self.remote_rows = {}
        self.terminal_channel = None
        self.terminal_window = None
        self.verify_reference_checksum = tk.BooleanVar(value=False)
        self.stage_state = {key: ("waiting", "Not started") for key in
                            ("upload", "verify", "install", "reboot")}
        self.stage_labels = {}
        self.firmware_step = 1
        self.upload_percent = tk.IntVar(value=0)
        self.update_activity = tk.StringVar(value="Ready: choose official Pager firmware.")
        self.activity_frame = 0
        self._firmware_spinner_active = False
        self.host = tk.StringVar(value=DEFAULT_HOST)
        self.port = tk.StringVar(value="22")
        self.username = tk.StringVar(value="root")
        self.password = tk.StringVar(value="")
        self.hash_var = tk.StringVar(value="")
        self.ready = tk.BooleanVar(value=False)
        self.connection_text = tk.StringVar(value="SSH NOT CONNECTED")
        self.firmware_text = tk.StringVar(value="No firmware selected")
        self.firmware_note = tk.StringVar(value="Choose an official Pager .bin file. The filename does not have to match an example.")
        self.virtual_status = tk.StringVar(value="Ready to open your Pager screen")
        self.status_text = tk.StringVar(value="Ready to connect")
        self._configure_styles()
        self._make_shell()
        self.show_page("Connect Device")
        # The handler finds the section under the mouse, rather than requiring
        # users to grab the narrow scrollbar. Linux and Windows wheel events
        # are supported. Nested widgets retain their own scroll position.
        self.bind_all("<MouseWheel>", self._wheel)
        self.bind_all("<Button-4>", self._wheel)
        self.bind_all("<Button-5>", self._wheel)
        self.after(100, self._pump)
        self.protocol("WM_DELETE_WINDOW", self._close)

    def _configure_styles(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("GS.Horizontal.TProgressbar", background=PURPLE, troughcolor=INPUT,
                    lightcolor=PURPLE, darkcolor=PURPLE, bordercolor=INPUT, thickness=18)
        s.configure("GS.Treeview", background=PANEL, foreground=WHITE,
                    fieldbackground=PANEL, font=(FONT, 13), rowheight=42, borderwidth=0)
        s.configure("GS.Treeview.Heading", background=INPUT, foreground=WHITE,
                    font=(FONT, 12, "bold"), relief="flat", padding=10)
        s.map("GS.Treeview", background=[("selected", PURPLE)], foreground=[("selected", WHITE)])

    def _make_shell(self):
        header = tk.Frame(self, bg=SIDE, height=112)
        header.pack(side="top", fill="x")
        header.pack_propagate(False)
        tk.Frame(header, width=5, bg=ACCENT).pack(side="left", fill="y")
        self.header_photo = None
        header_art = (HEADER_ART if self.theme_name == "purple" else
                      YELLOW_HEADER_ART if self.theme_name == "yellow" else None)
        if header_art is not None and header_art.exists():
            try:
                self.header_photo = tk.PhotoImage(file=str(header_art))
                art = tk.Label(header, bg=SIDE, image=self.header_photo, bd=0)
                art.place(relx=0.31 if self.theme_name == "yellow" else 0.54, y=0)
                art.lower()
            except tk.TclError:
                pass
        branding = tk.Frame(header, bg=SIDE)
        branding.pack(side="left", padx=25, pady=18)
        logo = Path(__file__).with_name("GS_logo_small.png")
        try:
            self.logo_photo = tk.PhotoImage(file=str(logo))
            tk.Label(branding, image=self.logo_photo, bg=SIDE).pack(side="left", padx=(0, 19))
        except tk.TclError:
            pass
        title_area = tk.Frame(branding, bg=SIDE)
        title_area.pack(side="left")
        text(title_area, APP_TITLE, 23, bold=True).pack(anchor="w")
        text(title_area, "Simple tools for your Hak5 WiFi Pineapple Pager", 12, MUTED).pack(anchor="w", pady=(2, 0))
        self.connection_chip = tk.Label(header, textvariable=self.connection_text,
                       bg=INPUT, fg=AMBER, font=(FONT, 12, "bold"), padx=16, pady=12)
        self.connection_chip.pack(side="right", padx=27)

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        sidebar = tk.Frame(body, bg=SIDE, width=255)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        text(sidebar, "MAIN MENU", 12, MUTED, bold=True).pack(anchor="w", padx=22, pady=(30, 15))
        self.nav_buttons = {}
        navs = [("Connect Device", "01", False),
                ("Dashboard", "02", True),
                ("File Manager", "03", True),
                ("Firmware Update", "04", True),
                ("Virtual Pager", "05", False),
                ("Pager Terminal", "06", True),
                ("Payloads & Themes", "07", False),
                ("Settings", "08", False),
                ("Help & About", "?", False)]
        self.restricted_pages = {name for name, _, locked in navs if locked}
        for name, symbol, _ in navs:
            nav = tk.Button(sidebar, text=f" {symbol}   {name}", anchor="w",
                            font=(FONT, 12, "bold"), bg=SIDE, fg=MUTED,
                            activebackground=INPUT, activeforeground=WHITE,
                            padx=18, pady=12, bd=0, relief="flat", highlightthickness=0,
                            cursor="hand2", command=lambda page=name: self.show_page(page))
            nav.pack(fill="x", pady=2)
            self.nav_buttons[name] = nav
        tk.Frame(sidebar, bg=SIDE).pack(fill="both", expand=True)
        text(sidebar, "GHOSTSTRATS", 14, ACCENT, bold=True).pack(anchor="w", padx=22)
        text(sidebar, "Community-built for easier Pager management.\nNot affiliated with Hak5.", 11, MUTED, wrap=215).pack(
            anchor="w", padx=22, pady=(6, 24))
        self.scroller = ScrollingContent(body)
        self.scroller.pack(side="left", fill="both", expand=True)
        self.main = self.scroller.inner
        self.yellow_wallpaper_photo = None
        self.yellow_hero_photo = None
        # Cache Tk images for this theme so switching sections stays responsive.
        self._theme_image_cache = {}
        footer = tk.Frame(self, bg=SIDE, height=48)
        footer.pack(side="bottom", fill="x")
        footer.pack_propagate(False)
        text(footer, "V1.2.1  •  WINDOWS BETA", 11, ACCENT, bold=True).pack(side="right", padx=25)

    @staticmethod
    def _wheel_units(event):
        """Normalize one mouse-wheel movement across Windows, Linux, and touchpads."""
        if getattr(event, "num", None) == 4:
            return -1
        if getattr(event, "num", None) == 5:
            return 1
        delta = getattr(event, "delta", 0)
        if not delta:
            return 0
        return -max(1, round(abs(delta) / 120)) if delta > 0 else max(1, round(abs(delta) / 120))

    def _wheel(self, event):
        steps = self._wheel_units(event)
        if not steps:
            return
        try:
            hovered = self.winfo_containing(event.x_root, event.y_root)
            if hovered is None:
                return
            main = self.scroller
            # Do not scroll the content when the pointer is over the menu,
            # desktop header, or any other region outside the content panel.
            path = []
            current = hovered
            while current is not None:
                path.append(current)
                if current == main:
                    break
                current = getattr(current, "master", None)
            if main not in path:
                return
            # Treeview and multiline text have their own scrollbar. Wheel
            # those directly (including the File Manager tree) when hovered.
            for widget in path:
                if isinstance(widget, ttk.Treeview):
                    widget.yview_scroll(steps, "units")
                    return "break"
                if isinstance(widget, (tk.Text, tk.Listbox)):
                    try:
                        if widget.yview() != (0.0, 1.0):
                            widget.yview_scroll(steps, "units")
                            return "break"
                    except tk.TclError:
                        pass
                if isinstance(widget, tk.Canvas) and widget != self.scroller.canvas:
                    try:
                        top, bottom = widget.yview()
                        if bottom - top < 0.999:
                            widget.yview_scroll(steps, "units")
                            return "break"
                    except tk.TclError:
                        pass
            self.scroller.canvas.yview_scroll(steps, "units")
            return "break"
        except tk.TclError:
            return

    def connected(self):
        if not self.connection or not self.connection.client:
            return False
        try:
            transport = self.connection.client.get_transport()
            return transport is not None and transport.is_active()
        except Exception:
            return False

    def show_page(self, requested):
        # Keep the progress view in place from upload through reboot monitoring.
        if self.busy and self.current_task == "update":
            requested = "Firmware Update"
        if (requested in self.restricted_pages and not self.connected()
                and not (self.busy and self.current_task == "update"
                         and requested == "Firmware Update")):
            requested = "Connect Device"
        if self.page == "Pager Terminal" and requested != "Pager Terminal":
            self.close_terminal()
        self.page = requested
        for page, nav in self.nav_buttons.items():
            selected = requested == page
            nav.config(bg=INPUT if selected else SIDE,
                       fg=WHITE if selected else (MUTED if page not in self.restricted_pages or self.connected() else "#78829a"))
        for child in self.main.winfo_children():
            child.destroy()
        self.stage_labels = {}
        {"Connect Device": self.render_connect,
         "Dashboard": self.render_dashboard,
         "File Manager": self.render_files,
         "Firmware Update": self.render_firmware,
         "Pager Terminal": self.render_terminal,
         "Payloads & Themes": self.render_resources,
         "Virtual Pager": self.render_virtual_pager,
         "Settings": self.render_settings,
         "Help & About": self.render_help}[requested]()
        self._apply_yellow_wallpaper()
        self.scroller.top()

    def _cached_theme_image(self, path):
        """Reuse decoded art rather than allocating a multi-megabyte bitmap per page."""
        key = str(path)
        if key not in self._theme_image_cache:
            self._theme_image_cache[key] = tk.PhotoImage(file=key)
        return self._theme_image_cache[key]

    def _apply_yellow_wallpaper(self):
        """Display the user's black/yellow artwork behind content, never over controls.

        All file rows, settings, status, and firmware controls remain opaque for legibility.
        The darkened asset needs only Tk's PNG support (no extra Python packages).
        """
        self.yellow_wallpaper_photo = None
        if self.theme_name != "yellow" or not YELLOW_WALLPAPER.is_file():
            return
        try:
            self.yellow_wallpaper_photo = self._cached_theme_image(YELLOW_WALLPAPER)
            background = tk.Label(self.main, image=self.yellow_wallpaper_photo,
                                  bg=BG, bd=0, highlightthickness=0)
            background.place(relx=0.0, rely=0.0, relwidth=1.0, relheight=1.0)
            background.lower()
        except tk.TclError:
            self.yellow_wallpaper_photo = None

    def heading(self, title, subtitle, eyebrow=None):
        if self.theme_name == "yellow" and YELLOW_HERO_ART.exists():
            # The original art is a subtle banner, with actual UI text layered on top.
            hero = tk.Canvas(self.main, bg=BG, height=185, highlightthickness=0, bd=0)
            hero.pack(fill="x", padx=34, pady=(26, 19))
            try:
                self.yellow_hero_photo = self._cached_theme_image(YELLOW_HERO_ART)
                hero.create_image(0, 0, anchor="nw", image=self.yellow_hero_photo)
            except tk.TclError:
                self.yellow_hero_photo = None
            if eyebrow:
                hero.create_text(22, 30, text=eyebrow.upper(), fill="#f8d445",
                                 font=(FONT, 11, "bold"), anchor="w")
            hero.create_text(22, 84 if eyebrow else 68, text=title, fill=WHITE,
                             font=(FONT, 27, "bold"), anchor="w")
            subtitle_id = hero.create_text(22, 130 if eyebrow else 118, text=subtitle,
                                           fill="#e6e7e7", font=(FONT, 14), anchor="w",
                                           width=640)
            hero.bind("<Configure>", lambda event: hero.itemconfigure(
                subtitle_id, width=max(260, min(640, event.width - 50))))
            return
        h = tk.Frame(self.main, bg=BG)
        h.pack(fill="x", padx=34, pady=(30, 21))
        if eyebrow:
            text(h, eyebrow.upper(), 12, ACCENT, bold=True).pack(anchor="w", pady=(0, 9))
        text(h, title, 27, bold=True).pack(anchor="w")
        subtitle_label = text(h, subtitle, 14, MUTED, wrap=830)
        subtitle_label.pack(anchor="w", pady=(7, 0))

    def section(self, padding=24, bottom=17):
        box, inside = card(self.main, padding)
        box.pack(fill="x", padx=34, pady=(0, bottom))
        return inside

    def step_head(self, parent, number, title):
        f = tk.Frame(parent, bg=PANEL)
        f.pack(anchor="w", fill="x", pady=(0, 13))
        tk.Label(f, text=str(number), bg=PURPLE, fg=WHITE,
                 font=(FONT, 14, "bold"), width=3, pady=7).pack(side="left", padx=(0, 14))
        text(f, title, 19, bold=True).pack(side="left")

    def line(self, parent):
        tk.Frame(parent, bg=LINE, height=1).pack(fill="x", pady=17)

    def render_connect(self):
        self.heading("Connect your Pager", "Start here. Connect once to unlock the file manager, firmware updates, and other tools.", "Step 1 of 1 • Device connection")
        if self.connected():
            content = self.section()
            text(content, "✓  Pager connected", 23, GREEN, bold=True).pack(anchor="w")
            text(content, f"Connected to {self.host.get()} as {self.username.get()}.", 14, MUTED).pack(anchor="w", pady=(9, 22))
            action(content, "OPEN YOUR DASHBOARD  →", lambda: self.show_page("Dashboard"), primary=True, big=True).pack(anchor="w")
            action(content, "Disconnect Pager", self.disconnect_pager).pack(anchor="w", pady=(13, 0))
            return
        panel = self.section()
        text(panel, "Pager sign-in", 20, bold=True).pack(anchor="w", pady=(0, 5))
        text(panel, "The default address and username are filled in for you.", 13, MUTED).pack(anchor="w", pady=(0, 20))
        row = tk.Frame(panel, bg=PANEL)
        row.pack(fill="x")
        for name, var in (("PAGER ADDRESS", self.host), ("USERNAME", self.username)):
            col = tk.Frame(row, bg=PANEL)
            col.pack(side="left", fill="x", expand=True, padx=(0, 16))
            text(col, name, 12, MUTED, bold=True).pack(anchor="w", pady=(0, 8))
            field(col, var).pack(fill="x", ipady=10)
        text(panel, "PASSWORD", 12, MUTED, bold=True).pack(anchor="w", pady=(19, 8))
        self.password_field = field(panel, self.password, secret=True, width=35)
        self.password_field.pack(fill="x", ipady=10)
        opts = tk.Frame(panel, bg=PANEL)
        opts.pack(fill="x", pady=(10, 18))
        self.reveal = tk.BooleanVar(value=False)
        tk.Checkbutton(opts, text="Show password", variable=self.reveal,
                       command=lambda: self.password_field.config(show="" if self.reveal.get() else "●"),
                       bg=PANEL, fg=WHITE, selectcolor=INPUT, activebackground=PANEL,
                       activeforeground=WHITE, font=(FONT, 12)).pack(side="left")
        text(opts, "SSH port: 22", 12, MUTED).pack(side="right")
        self.connect_btn = action(panel, "CONNECT TO PAGER  →", self.connect_pager, primary=True, big=True)
        self.connect_btn.pack(fill="x", pady=(4, 0))
        text(panel, "Secure local SSH connection. Your password is not saved to disk.", 12, MUTED).pack(anchor="w", pady=(13, 0))
        text(panel, "Factory-reset your Pager and now seeing an SSH host key mismatch?", 13, MUTED).pack(anchor="w", pady=(17, 6))
        action(panel, "RESET SAVED SSH KEY", self.reset_saved_ssh_key).pack(anchor="w")
        self._update_connection_ui()

        guide = self.section()
        text(guide, "Before you connect", 19, bold=True).pack(anchor="w", pady=(0, 13))
        for title in ("1   Plug the Pager into your computer using a USB-C data cable.",
                      "2   Make sure the Pager is powered on and its setup is complete.",
                      "3   Enter the password you use to access your Pager."):
            text(guide, title, 14).pack(anchor="w", pady=7)

        tips = self.section()
        text(tips, "Connection not working?", 18, bold=True).pack(anchor="w", pady=(0, 8))
        text(tips, "Try another USB-C data cable, confirm that the Pager is on, and check its SSH settings. If you changed the IP address, enter your custom address above.", 13, MUTED, wrap=790).pack(anchor="w")
        action(tips, "OPEN HELP", lambda: self.show_page("Help & About")).pack(anchor="w", pady=(17, 0))
        text(tips, "Prefer the live on-screen controls? Virtual Pager can connect through the web interface without first logging in over SSH.",
             13, MUTED, wrap=795).pack(anchor="w", pady=(17, 8))
        action(tips, "OPEN VIRTUAL PAGER  →", lambda: self.show_page("Virtual Pager"), big=True).pack(anchor="w")
        text(tips, "New Pager? You can finish the initial Hak5 setup in a browser first.", 13, MUTED).pack(anchor="w", pady=(20, 8))
        action(tips, "OPEN INITIAL DEVICE SETUP  ↗", self.open_setup).pack(anchor="w")

    def reset_saved_ssh_key(self):
        """User-initiated, host-specific trust reset after a legitimate factory reset."""
        if self.busy or self.issued_install or self.connected():
            messagebox.showwarning("Disconnect before resetting SSH trust",
                "Finish the current operation and disconnect before resetting a saved key.", parent=self)
            return
        host = self.host.get().strip()
        try:
            port = int(self.port.get().strip())
            if not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid SSH port", "Enter a valid SSH port (1–65535).", parent=self)
            return
        if not messagebox.askyesno("Reset saved SSH key?",
            f"Forget the previously trusted SSH key for {host} (port {port})?\n\n"
            "Only do this if you intentionally factory-reset or reflashed YOUR Pager. "
            "An unexpected SSH key change can indicate an impersonation attempt.\n\n"
            "Your other SSH host keys and Pager files will remain unchanged.\n\n"
            "On the next connection, carefully verify the newly displayed fingerprint.",
            icon="warning", parent=self):
            return
        try:
            removed = clear_saved_ssh_host_key(host, port)
        except PagerError as exc:
            messagebox.showerror("Could not reset SSH key", str(exc), parent=self)
            return
        if removed:
            self._append_log("Reset saved SSH host key for " + host + ".")
            messagebox.showinfo("SSH key reset",
                "The previous key for this Pager address was forgotten.\n\n"
                "Click CONNECT TO PAGER and verify the new SSH fingerprint before trusting it.\n"
                "A backup was saved as known_hosts.before_reset.bak.", parent=self)
        else:
            messagebox.showinfo("No saved key found",
                "There is no saved SSH key for this address and port.\n\n"
                "You can try CONNECT TO PAGER again. If a mismatch continues, confirm the address and SSH port.", parent=self)

    def disconnect_pager(self):
        if self.busy or self.issued_install:
            return
        if self.connection:
            self.connection.close()
        self.connection = None
        self.connected_installer = False
        self._update_connection_ui()
        self.show_page("Connect Device")

    def render_dashboard(self):
        self.heading("Dashboard", "Everything you need to manage your WiFi Pineapple Pager.",
                     "Your device is connected • Tools unlocked")
        welcome = self.section()
        text(welcome, "●  Connected and ready", 20, GREEN, bold=True).pack(anchor="w")
        text(welcome, "Choose a tool below. Your connection stays local to the Pager.", 14, MUTED).pack(anchor="w", pady=(6, 0))
        for title, desc, button_title, page in (
            ("File Manager", "Upload, download, open, preview, and organize Pager files.", "OPEN FILE MANAGER", "File Manager"),
            ("Firmware Update", "Official Pager firmware, guided installation, optional checksum check.", "FIRMWARE UPDATE", "Firmware Update"),
            ("Virtual Pager", "See and control your actual Pager screen in a viewer or browser.", "OPEN VIRTUAL PAGER", "Virtual Pager"),
            ("Pager Terminal", "Start an SSH shell in the app using your existing connection.", "LAUNCH TERMINAL", "Pager Terminal"),
            ("Hak5 GitHub Repositories", "Find official community payloads, themes, and ringtones.", "BROWSE HAK5 REPOS", "Payloads & Themes"),
        ):
            panel = self.section(padding=18, bottom=11)
            text(panel, title, 19, bold=True).pack(anchor="w")
            text(panel, desc, 14, MUTED, wrap=840).pack(anchor="w", pady=(4, 11))
            action(panel, button_title + "  →", lambda p=page: self.show_page(p),
                   primary=(page == "File Manager")).pack(anchor="w")

    def render_resources(self):
        self.heading("Hak5 Payloads & Themes", "Open the official WiFi Pineapple Pager community libraries.",
                     "Hak5 official GitHub repositories")
        for title, subtitle, url in (
            ("All Pager repositories", "Payloads, themes, ringtones and library information.", HAK5_REPO),
            ("Payload library", "Browse WiFi Pineapple Pager payloads and installation notes.", HAK5_PAYLOADS),
            ("Themes library", "Browse community themes and installation instructions.", HAK5_THEMES),
        ):
            body = self.section()
            text(body, title, 20, bold=True).pack(anchor="w")
            text(body, subtitle, 14, MUTED).pack(anchor="w", pady=(7, 12))
            action(body, "OPEN IN BROWSER  ↗", lambda u=url: webbrowser.open(u),
                   primary=(url == HAK5_REPO), big=True).pack(anchor="w")
        info = self.section()
        text(info, "QUICK GUIDE — INSTALL PAYLOADS & THEMES", 20, bold=True).pack(anchor="w")
        guide = (
            "1. Click a GitHub button above to open Hak5's official repository in your browser.\n"
            "2. Download the payload or theme you want. If it downloads as a ZIP, extract it on your PC first.\n"
            "3. Connect your Pager, open File Manager, and navigate to the correct destination:\n"
            "   • Payloads: /root/payloads/user/ (or /mmc/root/payloads/user/); choose the appropriate category subfolder.\n"
            "   • Themes: /root/themes/ (or /mmc/root/themes/).\n"
            "4. Drag the extracted files/folder into File Manager, or choose Upload Files / Upload Folder.\n"
            "5. Confirm any replacements, then wait for the upload to complete. Follow repository instructions for enabling the content."
        )
        text(info, guide, 14, MUTED, wrap=875).pack(anchor="w", pady=(12, 13))
        text(info, "These buttons take you directly to Hak5's GitHub pages. They do not automatically install code. "
                   "Review downloads before transferring them. Theme creation is a separate tool, not included here.",
             12, AMBER, wrap=875).pack(anchor="w")
        action(info, "OPEN FILE MANAGER TO UPLOAD FILES  →", lambda: self.show_page("File Manager"),
               primary=True, big=True).pack(anchor="w", pady=(15, 0))

    def render_terminal(self):
        self.heading("Pager Terminal", "Use an interactive SSH terminal connected to your Pager.",
                     "Live device shell • Commands run on the physical Pager")
        if not self.connected():
            self._unavailable("Connect to your Pager first.")
            return
        panel = self.section()
        text(panel, "Commands execute on the actual Pager. Only run commands you understand.",
             14, AMBER, wrap=880).pack(anchor="w", pady=(0, 15))
        controls = tk.Frame(panel, bg=PANEL)
        controls.pack(fill="x", pady=(0, 12))
        action(controls, "START SSH TERMINAL", self.launch_terminal, primary=True, big=True).pack(side="left", padx=(0, 10))
        action(controls, "CLOSE SESSION", self.close_terminal).pack(side="left")
        self.terminal_output = tk.Text(panel, bg="#080812", fg="#d9baff", insertbackground="#d9baff",
                                       font=("Consolas", 13), height=19, wrap="word", relief="flat",
                                       padx=14, pady=12, state="disabled", selectbackground="#583388")
        self.terminal_output.pack(fill="both", expand=True)
        prompt = tk.Frame(panel, bg=PANEL)
        prompt.pack(fill="x", pady=(14, 0))
        text(prompt, "COMMAND", 12, ACCENT, bold=True).pack(side="left", padx=(0, 12))
        self.terminal_input = tk.Entry(prompt, font=("Consolas", 14), bg=INPUT, fg=WHITE,
                                       insertbackground=WHITE, relief="flat", bd=0)
        self.terminal_input.pack(side="left", fill="x", expand=True, ipady=11)
        self.terminal_input.bind("<Return>", lambda _event: self.send_terminal_command())
        action(prompt, "SEND", self.send_terminal_command, primary=True).pack(side="left", padx=(8, 0))
        self._terminal_append("Select START SSH TERMINAL, then type a command and press Enter.\n")

    def _terminal_append(self, output):
        widget = getattr(self, "terminal_output", None)
        if widget is None or not widget.winfo_exists():
            return
        output = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", output)
        output = output.replace("\r\n", "\n").replace("\r", "")
        widget.configure(state="normal")
        widget.insert("end", output)
        widget.see("end")
        widget.configure(state="disabled")

    def launch_terminal(self):
        if self.busy or not self.connected():
            return
        if self.terminal_channel is not None and not self.terminal_channel.closed:
            self._terminal_append("\nAn SSH terminal session is already running.\n")
            return
        self._terminal_append("\nConnecting to the Pager shell...\n")
        def worker():
            transport = self.connection.client.get_transport()
            if not transport or not transport.is_active():
                raise PagerError("The SSH connection is no longer active.")
            channel = transport.open_session(timeout=12)
            channel.get_pty(term="vt100", width=100, height=30)
            channel.invoke_shell()
            channel.settimeout(0.0)
            return channel
        self._start_task(worker, "terminal")

    def send_terminal_command(self):
        if not hasattr(self, "terminal_input"):
            return
        command = self.terminal_input.get()
        channel = self.terminal_channel
        if not channel or channel.closed:
            self._terminal_append("\nOpen a terminal session first.\n")
            return
        try:
            channel.sendall(command + "\n")
            self.terminal_input.delete(0, "end")
        except Exception as error:
            self._terminal_append("\nConnection error: " + str(error) + "\n")

    def close_terminal(self):
        chan = self.terminal_channel
        self.terminal_channel = None
        if chan is not None:
            try:
                chan.close()
            except Exception:
                pass
        if self.page == "Pager Terminal":
            self._terminal_append("\nTerminal session closed.\n")

    def render_virtual_pager(self):
        self.heading("Virtual Pager", "Control your actual Pager screen from your computer.",
                     "Live device screen • Official Hak5 web interface")
        panel = self.section(padding=28)
        text(panel, "Your Pager, right here on Windows", 22, bold=True).pack(anchor="w")
        text(panel, "The Virtual Pager is provided by Hak5. It shows the LIVE screen, lets you press the Pager buttons, and includes a terminal and loot downloads.",
             15, MUTED, wrap=800).pack(anchor="w", pady=(12, 20))
        text(panel, "1   Connect the Pager to this PC using USB-C (SSH login is optional).", 15).pack(anchor="w", pady=6)
        text(panel, "2   Click OPEN VIRTUAL PAGER below.", 15).pack(anchor="w", pady=6)
        text(panel, "3   Sign in with your Pager password in the web window.", 15).pack(anchor="w", pady=6)
        self.virtual_btn = action(panel, "OPEN VIRTUAL PAGER  →", self.open_virtual_pager, primary=True, big=True)
        self.virtual_btn.pack(fill="x", pady=(22, 10))
        text(panel, "Checks the local connection first; opens an app window when the embedded viewer is available, otherwise opens your browser.",
             12, MUTED, wrap=760).pack(anchor="w")
        statusbox = tk.Frame(panel, bg=INPUT, padx=16, pady=15)
        statusbox.pack(fill="x", pady=(18, 0))
        tk.Label(statusbox, textvariable=self.virtual_status, bg=INPUT, fg=ACCENT,
                 font=(FONT, 14, "bold"), anchor="w", justify="left", wraplength=750).pack(fill="x")

        more = self.section()
        text(more, "Other ways to open it", 19, bold=True).pack(anchor="w", pady=(0, 13))
        action(more, "OPEN IN DEFAULT BROWSER  ↗", self.open_virtual_browser, big=True).pack(anchor="w", pady=(0, 12))
        text(more, "Hak5 Virtual Pager runs at port 1471 on your Pager. For a new Pager, finish its initial setup first.",
             13, MUTED).pack(anchor="w")
        action(more, "OPEN FIRST-TIME PAGER SETUP  ↗", self.open_setup).pack(anchor="w", pady=(14, 0))

        note = self.section()
        text(note, "Firmware updates use a different connection", 18, AMBER, bold=True).pack(anchor="w")
        text(note, "Do not start a firmware flash from the Virtual Pager's terminal. Use this app's separate Firmware Update menu, which connects over SSH instead.",
             14, MUTED, wrap=760).pack(anchor="w", pady=(8, 0))

    def open_setup(self):
        # Hak5's first-boot interface listens on port 80; 1471 is Virtual Pager after setup.
        try:
            host = self.host.get().strip()
            url = virtual_pager_url(host).replace(":1471/", "/")
        except ValueError as error:
            messagebox.showerror("Pager address", str(error), parent=self)
            return
        webbrowser.open(url)

    def open_virtual_browser(self):
        try:
            url = virtual_pager_url(self.host.get())
        except ValueError as error:
            messagebox.showerror("Pager address", str(error), parent=self)
            return
        webbrowser.open(url)
        self.virtual_status.set("Opened " + url + " in your default browser")

    def open_virtual_pager(self):
        if self.busy:
            return
        try:
            url = virtual_pager_url(self.host.get())
        except ValueError as error:
            messagebox.showerror("Pager address", str(error), parent=self)
            return
        self.virtual_status.set("◉  Checking the Pager's web interface...")
        self.virtual_btn.config(state="disabled")
        self._start_task(lambda: check_virtual_pager(url), "virtual_check")

    def _launch_virtual_window(self, url):
        """Run JS-capable Hak5 web UI in a SEPARATE Windows process.

        Tk owns this process's UI loop; pywebview must own the child's main thread.
        WebView2/pywebview missing: launch default browser, keeping feature usable.
        """
        import importlib.util
        if sys.platform == "win32" and importlib.util.find_spec("webview") is not None:
            if getattr(sys, "frozen", False):
                command = [sys.executable, "--virtual-pager-window", url]
            else:
                command = [sys.executable, str(Path(__file__).resolve()), "--virtual-pager-window", url]
            try:
                subprocess.Popen(command, close_fds=True)
                self.virtual_status.set("✓  Virtual Pager window launched. Sign in with your device password.")
                return
            except OSError:
                pass
        webbrowser.open(url)
        self.virtual_status.set("✓  Opened Hak5 Virtual Pager in your browser. Sign in with your device password.")

    def render_settings(self):
        self.heading("Settings", "Choose how your Windows app looks and reads.",
                     "Appearance • Saved automatically")
        panel = self.section(padding=25)
        text(panel, "App color theme", 22, bold=True).pack(anchor="w", pady=(0, 8))
        text(panel, "These themes change this Windows app, not the theme on the Pager itself.",
             14, MUTED, wrap=790).pack(anchor="w", pady=(0, 17))
        for key in ("slate", "yellow", "purple"):
            chosen = self.theme_name == key
            theme = THEMES[key]
            frame = tk.Frame(panel, bg=LINE if chosen else INPUT, padx=2, pady=2)
            frame.pack(fill="x", pady=7)
            inside = tk.Frame(frame, bg=theme["panel"], padx=18, pady=14)
            inside.pack(fill="both", expand=True)
            row = tk.Frame(inside, bg=theme["panel"])
            row.pack(fill="x")
            tk.Label(row, text="●", font=(FONT, 20), bg=theme["panel"],
                     fg=theme["accent"]).pack(side="left", padx=(0, 13))
            info = tk.Frame(row, bg=theme["panel"])
            info.pack(side="left", fill="x", expand=True)
            tk.Label(info, text=theme["name"] + ("   ✓ SELECTED" if chosen else ""),
                     font=(FONT, 16, "bold"), fg="#ffffff", bg=theme["panel"]).pack(anchor="w")
            tk.Label(info, text=theme["description"], font=(FONT, 12),
                     fg="#d3d7de", bg=theme["panel"]).pack(anchor="w", pady=(3, 0))
            btn = action(row, "IN USE  ✓" if chosen else "APPLY THEME", lambda k=key: self.change_theme(k))
            btn.pack(side="right")
            if chosen:
                btn.config(state="disabled")
        sizes = self.section()
        text(sizes, "Text size", 21, bold=True).pack(anchor="w", pady=(0, 7))
        text(sizes, "Make the buttons, labels, and menus even larger if needed.", 14, MUTED).pack(anchor="w", pady=(0, 17))
        bar = tk.Frame(sizes, bg=PANEL)
        bar.pack(fill="x")
        for size in ("Comfortable", "Extra large"):
            chosen = self.text_size == size
            btn = action(bar, size.upper() + ("  ✓" if chosen else ""), lambda v=size: self.change_text_size(v),
                         primary=chosen, big=True)
            btn.pack(side="left", fill="x", expand=True, padx=(0, 14))
            if chosen:
                btn.config(state="disabled")
        hint = self.section()
        text(hint, "Your preferences are saved locally.", 16, GREEN, bold=True).pack(anchor="w")
        text(hint, "No passwords are saved to settings. Appearance will remain selected the next time you open the app.",
             13, MUTED, wrap=790).pack(anchor="w", pady=(8, 0))

    def change_theme(self, name):
        if self.busy and self.current_task == "update":
            return
        self.theme_name = name if name in THEMES else "slate"
        self._save_and_rebuild()

    def change_text_size(self, size):
        if self.busy and self.current_task == "update":
            return
        self.text_size = size if size in ("Comfortable", "Extra large") else "Comfortable"
        self._save_and_rebuild()

    def _save_and_rebuild(self):
        try:
            save_settings(self.theme_name, self.text_size)
        except OSError as error:
            messagebox.showwarning("Settings were not saved", str(error), parent=self)
        apply_theme(self.theme_name)
        self.tk.call("tk", "scaling", 1.35 if self.text_size == "Extra large" else 1.18)
        self.configure(bg=BG)
        for child in self.winfo_children():
            child.destroy()
        self._theme_image_cache = {}
        self._configure_styles()
        self._make_shell()
        self._update_connection_ui()
        self.show_page("Settings")

    def render_firmware(self):
        self.heading("Firmware Update", "Three easy screens. Complete one step, then go to the next.", "Your device is connected • Firmware tools")
        roadmap = self.section(padding=15, bottom=14)
        road = tk.Frame(roadmap, bg=PANEL)
        road.pack(fill="x")
        for num, title in ((1, "Choose file"), (2, "Prepare Pager"), (3, "Start update")):
            chosen = num == self.firmware_step
            finished = num < self.firmware_step
            txt = ("✓ " if finished else f"{num}  ") + title
            tk.Label(road, text=txt, bg=PURPLE if chosen else INPUT,
                     fg=WHITE if chosen else (GREEN if finished else MUTED),
                     font=(FONT, 13, "bold"), padx=18, pady=12).pack(side="left", fill="x", expand=True, padx=4)

        if self.firmware_step == 1:
            panel = self.section(padding=27)
            self.step_head(panel, 1, "Choose your firmware file")
            text(panel, "Download the official signed firmware for the WiFi Pineapple Pager, then select the .bin file on your PC.",
                 15, MUTED, wrap=770).pack(anchor="w", pady=(0, 23))
            action(panel, "1. OPEN OFFICIAL DOWNLOADS  ↗",
                   lambda: webbrowser.open(DOWNLOAD_URL), big=True).pack(fill="x", pady=(0, 13))
            action(panel, "2. CHOOSE MY .BIN FILE", self.choose_firmware, primary=True, big=True).pack(fill="x")
            tk.Label(panel, textvariable=self.firmware_text, bg=INPUT, fg=WHITE,
                     font=(FONT, 14, "bold"), anchor="w", justify="left",
                     wraplength=710, padx=14, pady=17).pack(fill="x", pady=(20, 4))
            tk.Label(panel, textvariable=self.firmware_note, bg=PANEL, fg=MUTED,
                     font=(FONT, 13), anchor="w", justify="left",
                     wraplength=770).pack(fill="x", pady=(8, 0))
            bar = self.section()
            self.next_firmware_button = action(bar, "NEXT: PREPARE YOUR PAGER  →",
                                               self.advance_firmware, primary=True, big=True)
            self.next_firmware_button.pack(fill="x")
            self._enable_update()

        elif self.firmware_step == 2:
            panel = self.section(padding=27)
            self.step_head(panel, 2, "Prepare your Pager")
            for advice in ("Back up any files you want to keep.",
                           "Use ONLY signed firmware for the WiFi Pineapple Pager from Hak5.",
                           "Fully charge the Pager and keep its power connected.",
                           "Keep the USB-C cable connected during the update."):
                text(panel, "✓  " + advice, 15, WHITE).pack(anchor="w", pady=10)
            self.line(panel)
            text(panel, "Optional checksum verification", 18, ACCENT, bold=True).pack(anchor="w", pady=(0, 8))
            text(panel, "A checksum is a SHA-256 fingerprint. Comparing it with a value published by Hak5 can detect damage or tampering during download. It is recommended, but optional. The app always checks upload integrity on the Pager.",
                 13, MUTED, wrap=850).pack(anchor="w", pady=(0, 8))
            check = tk.Checkbutton(panel, text="Compare with a published SHA-256 checksum",
                variable=self.verify_reference_checksum, bg=PANEL, fg=WHITE,
                selectcolor=INPUT, activebackground=PANEL, activeforeground=WHITE,
                font=(FONT, 14, "bold"))
            check.pack(anchor="w", pady=(0, 7))
            text(panel, "Paste SHA-256 from the official download page (only needed if checked):",
                 12, MUTED).pack(anchor="w")
            field(panel, self.hash_var, width=65).pack(fill="x", ipady=8, pady=(7, 12))
            self.line(panel)
            self.ready_button = action(panel,
                    "✓  BACKUP & POWER CHECKED" if self.ready.get() else "○  TAP TO CONFIRM BACKUP & POWER",
                    self.toggle_ready, big=True)
            self.ready_button.pack(fill="x", pady=(2, 5))
            if self.ready.get():
                self.ready_button.config(bg="#276047", fg=WHITE)
            bar = self.section()
            self.next_firmware_button = action(bar, "NEXT: START THE UPDATE  →",
                                               self.advance_firmware, primary=True, big=True)
            self.next_firmware_button.pack(fill="x")
            action(bar, "← BACK TO FILE SELECTION", lambda: self.set_firmware_step(1)).pack(anchor="w", pady=(12, 0))
            self._enable_update()

        elif self.firmware_step == 3:
            panel = self.section(padding=27, bottom=14)
            self.step_head(panel, 3, "Start your firmware update")
            text(panel, "Everything is ready. Click the button and the app will upload your file, verify it, and launch the official updater.",
                 15, MUTED, wrap=770).pack(anchor="w", pady=(0, 17))
            self.update_btn = action(panel, "START FIRMWARE UPDATE  →",
                                     self.start_update, primary=True, big=True)
            self.update_btn.pack(fill="x")
            warning = tk.Frame(panel, bg="#64252f", padx=19, pady=17)
            warning.pack(fill="x", pady=(17, 0))
            tk.Label(warning, text="⚠  DO NOT DISCONNECT DURING FLASHING", bg="#64252f",
                     fg=WHITE, font=(FONT, 17, "bold"), wraplength=800).pack(anchor="w")
            tk.Label(warning, text="Keep your Pager powered and connected. Wait for it to restart automatically.",
                     bg="#64252f", fg=WHITE, font=(FONT, 13), wraplength=800).pack(anchor="w", pady=(7,0))
            self._enable_update()
            self.render_firmware_status()
            if not self.busy and not self.issued_install:
                bar = self.section()
                action(bar, "← BACK TO PREPARATION", lambda: self.set_firmware_step(2)).pack(anchor="w")

    def toggle_ready(self):
        self.ready.set(not self.ready.get())
        if hasattr(self, "ready_button") and self.ready_button.winfo_exists():
            self.ready_button.config(
                text="✓  BACKUP & POWER CHECKED" if self.ready.get() else "○  TAP TO CONFIRM BACKUP & POWER",
                bg="#276047" if self.ready.get() else INPUT)
        self._enable_update()

    def set_firmware_step(self, step):
        if self.busy or self.issued_install:
            return
        self.firmware_step = step
        self.show_page("Firmware Update")

    def optional_checksum(self):
        return self.hash_var.get() if self.verify_reference_checksum.get() else ""

    def advance_firmware(self):
        if self.firmware_step == 1:
            if not self.selected_firmware:
                messagebox.showinfo("Choose a file first", "Click CHOOSE MY .BIN FILE and select your official signed Pager firmware.", parent=self)
                return
            try:
                validate_firmware_file(self.selected_firmware, self.optional_checksum())
            except PagerError as error:
                messagebox.showerror("This file cannot be used", str(error), parent=self)
                return
            self.set_firmware_step(2)
        elif self.firmware_step == 2:
            if not self.ready.get():
                messagebox.showinfo("Check the preparation box", "Please confirm you have backed up your files and checked the Pager's power.", parent=self)
                return
            self.set_firmware_step(3)

    def render_firmware_status(self):
        panel = self.section(bottom=12)
        text(panel, "Update progress", 21, bold=True).pack(anchor="w", pady=(0, 5))
        text(panel, "You'll see each task change from waiting to working, finished, or needing attention.",
             13, MUTED, wrap=800).pack(anchor="w", pady=(0, 12))
        self.stage_labels = {}
        for key, name in (("upload", "Upload firmware"), ("verify", "Check uploaded file"),
                          ("install", "Run official installer"), ("reboot", "Wait for Pager restart")):
            row = tk.Frame(panel, bg=PANEL)
            row.pack(fill="x", pady=9)
            symbol = tk.Label(row, bg=PANEL, fg=MUTED, text="○", font=(FONT, 23, "bold"), width=3)
            symbol.pack(side="left")
            info = tk.Frame(row, bg=PANEL)
            info.pack(side="left", fill="x", expand=True)
            text(info, name, 15, bold=True).pack(anchor="w")
            status = text(info, "Waiting", 12, MUTED, wrap=750)
            status.pack(anchor="w", pady=(3, 0))
            self.stage_labels[key] = (symbol, status)
        self.progress = ttk.Progressbar(panel, variable=self.upload_percent, maximum=100,
                                        mode="determinate", style="GS.Horizontal.TProgressbar")
        self.progress.pack(fill="x", pady=(20, 7))
        self.upload_caption = text(panel, "Upload progress: 0% (only file transfer is measurable).", 12, MUTED)
        self.upload_caption.pack(anchor="w")
        activity_row = tk.Frame(panel, bg=INPUT, padx=16, pady=14)
        activity_row.pack(fill="x", pady=(16, 8))
        self.working_spinner = tk.Label(activity_row, text="○", font=("Consolas", 23, "bold"),
                                        fg=ACCENT, bg=INPUT, width=2)
        self.working_spinner.pack(side="left", padx=(0, 12))
        self.working_status_label = tk.Label(activity_row, textvariable=self.update_activity,
                 font=(FONT, 15, "bold"), fg=WHITE, bg=INPUT, justify="left",
                 anchor="w", wraplength=725)
        self.working_status_label.pack(side="left", fill="x", expand=True)
        self._firmware_spinner_active = False
        self._refresh_stages()

        logs = self.section()
        self.logs_visible = tk.BooleanVar(value=False)
        log_area = tk.Frame(logs, bg=PANEL)
        def toggle_log():
            if self.logs_visible.get():
                log_area.pack(fill="both", expand=True, pady=(14, 0))
            else:
                log_area.pack_forget()
        tk.Checkbutton(logs, text="Show technical details / activity log",
                       variable=self.logs_visible, command=toggle_log,
                       bg=PANEL, fg=MUTED, activebackground=PANEL,
                       activeforeground=WHITE, selectcolor=INPUT,
                       font=(FONT, 13)).pack(anchor="w")
        self.log_widget = tk.Text(log_area, height=10, bg=INPUT, fg=WHITE,
                  font=("Consolas", 11), relief="flat", bd=0,
                  padx=12, pady=12, wrap="word", state="disabled")
        self.log_widget.pack(fill="both", expand=True)
        for line in self.log_lines:
            self._log_to_widget(line)

    def _refresh_stages(self):
        for key, controls in self.stage_labels.items():
            if not controls[0].winfo_exists():
                continue
            symbol, subtitle = controls
            state, message = self.stage_state[key]
            glyph, color = {"waiting": ("○", MUTED), "running": ("◉", BLUE),
                            "done": ("✓", GREEN), "error": ("✕", RED),
                            "unknown": ("!", AMBER)}.get(state, ("○", MUTED))
            symbol.config(text=glyph, fg=color)
            subtitle.config(text=message, fg=color if state != "waiting" else MUTED)
        if self.page == "Firmware Update" and hasattr(self, "upload_caption") and self.upload_caption.winfo_exists():
            self.upload_caption.config(text=(f"File transfer: {self.upload_percent.get()}% complete."
                if self.stage_state["upload"][0] in ("waiting", "running") else
                "File transfer completed. Installation / reboot has no reliable percentage."))
            active = next((key for key in ("upload", "verify", "install", "reboot")
                           if self.stage_state[key][0] == "running"), None)
            installing = active in ("install", "reboot")
            if hasattr(self, "progress") and self.progress.winfo_exists():
                if installing and not self._firmware_spinner_active:
                    self.progress.configure(mode="indeterminate")
                    self.progress.start(16)
                    self._firmware_spinner_active = True
                elif not installing and self._firmware_spinner_active:
                    self.progress.stop()
                    self.progress.configure(mode="determinate")
                    self._firmware_spinner_active = False
            messages = {
                "upload": "Uploading firmware to your Pager. Keep it connected.",
                "verify": "Checking that the uploaded firmware matches your download.",
                "install": "Firmware installation is running on your Pager. Please be patient; do not unplug or power off.",
                "reboot": "Waiting for your Pager to reboot on its own. This may take several minutes. Keep it powered on.",
            }
            if active:
                self.update_activity.set(messages[active])
            elif self.stage_state["reboot"][0] == "done":
                self.update_activity.set("Pager is reachable again. Check the firmware version on your device.")
            elif self.stage_state["reboot"][0] == "unknown":
                self.update_activity.set("Restart not confirmed. Check your Pager and allow more time before retrying.")
            elif any(state == "error" for state, msg in self.stage_state.values()):
                self.update_activity.set("Update needs attention. Check the error and do not disconnect if installation began.")
            else:
                self.update_activity.set("Ready to update your Pager.")

    def _append_log(self, message):
        line = datetime.datetime.now().strftime("%H:%M:%S") + "   " + str(message)
        self.log_lines.append(line)
        self.log_lines = self.log_lines[-120:]
        if self.page == "Firmware Update" and hasattr(self, "log_widget") and self.log_widget.winfo_exists():
            self._log_to_widget(line)

    def _log_to_widget(self, line):
        self.log_widget.config(state="normal")
        self.log_widget.insert("end", line + "\n")
        self.log_widget.see("end")
        self.log_widget.config(state="disabled")

    def _update_connection_ui(self):
        connected = self.connected()
        if self.busy and self.current_task == "update":
            self.connection_text.set("◉  FIRMWARE UPDATING")
        elif connected:
            self.connection_text.set("●  SSH CONNECTED")
        elif self.busy and self.current_task == "connect":
            self.connection_text.set("◉  SSH CONNECTING...")
        else:
            self.connection_text.set("○  SSH NOT CONNECTED")
        self.connection_chip.config(fg=GREEN if connected and self.current_task != "update" else AMBER)
        if hasattr(self, "connect_btn") and self.connect_btn.winfo_exists():
            self.connect_btn.config(state="disabled" if self.busy else "normal")
        self._enable_update()

    def _enable_update(self):
        allowed = (self.connected() and self.connected_installer and bool(self.selected_firmware)
                   and self.ready.get() and not self.busy and not self.issued_install)
        if hasattr(self, "update_btn") and self.update_btn.winfo_exists():
            self.update_btn.config(state="normal" if allowed else "disabled",
                                   bg=PURPLE if allowed else INPUT,
                                   fg=WHITE if allowed else MUTED,
                                   cursor="hand2" if allowed else "arrow")

    def _prompt_host_key(self, hostname, fingerprint):
        request = {"done": threading.Event(), "allow": False}
        self.queue.put(("trust", hostname, fingerprint, request))
        if not request["done"].wait(120):
            return False
        return request["allow"]

    def _start_task(self, fn, tag):
        if self.busy:
            self._append_log("Wait until the current operation finishes.")
            return
        self.busy = True
        self.current_task = tag
        self._update_connection_ui()
        def worker():
            try:
                self.queue.put(("done", tag, fn()))
            except Exception as error:
                self.queue.put(("failure", tag, str(error)))
        threading.Thread(target=worker, daemon=True).start()

    def connect_pager(self):
        if self.busy or (self.issued_install and self.busy):
            return
        try:
            port = int(self.port.get().strip())
            if port < 1 or port > 65535:
                raise ValueError()
        except ValueError:
            messagebox.showerror("Invalid address", "Connection port must be 1–65535.", parent=self)
            return
        if self.connection:
            self.connection.close()
        self.connection = None
        self.connected_installer = False
        config = (self.host.get(), port, self.username.get(), self.password.get())
        self._append_log("Connecting to Pager...")
        def worker():
            c = PagerConnection(*config, trust_cb=self._prompt_host_key)
            c.connect()
            try:
                result, _ = c.command("command -v INSTALL_FIRMWARE", timeout=12)
                return (c, result == 0)
            except Exception:
                return (c, False)
        self._start_task(worker, "connect")

    def choose_firmware(self):
        selected = filedialog.askopenfilename(parent=self, title="Select signed Hak5 Pineapple Pager firmware",
                         filetypes=[("Pager firmware (.bin)", "*.bin"), ("All files", "*.*")])
        if not selected:
            return
        self.selected_firmware = selected
        self.firmware_text.set(Path(selected).name)
        if has_example_firmware_filename(selected):
            self.firmware_note.set("Filename matches Hak5's example format. Your Pager will still check the firmware before installing.")
        else:
            self.firmware_note.set("Different filename? That's okay. The app won't reject it for its name. Only install official Hak5 Pager firmware; the Pager validates it.")
        self._append_log("Selected " + Path(selected).name)
        self._enable_update()

    def _begin_verified_firmware_update(self):
        filename = self.selected_firmware
        self.stage_state = {k: ("waiting", "Not started") for k in self.stage_state}
        self.upload_percent.set(0)
        self.firmware_warning_shown = False
        self._refresh_stages()
        def event(*args):
            self.queue.put(("firmware_event",) + args)
        self._start_task(lambda: run_firmware_update(self.connection, filename, self.optional_checksum(), event), "update")

    def start_update(self):
        if self.busy or not self.connected() or not self.connected_installer or not self.ready.get() or self.issued_install:
            return
        try:
            _, digest = validate_firmware_file(self.selected_firmware, self.optional_checksum())
        except PagerError as error:
            messagebox.showerror("Please check your firmware file", str(error), parent=self)
            return
        self._append_log("Local file SHA-256: " + digest)
        self.update_activity.set("Checking the installed Pager firmware version before updating...")
        self._start_task(lambda: (read_installed_firmware_version(self.connection),
                                  firmware_version_from_filename(self.selected_firmware)), "firmware_preflight")

    def _pump(self):
        if self.page == "Firmware Update" and hasattr(self, "working_spinner") and self.working_spinner.winfo_exists():
            running = any(state == "running" for state, _ in self.stage_state.values())
            if running:
                self.activity_frame = (self.activity_frame + 1) % 4
                self.working_spinner.configure(text=("|", "/", "-", "\\")[self.activity_frame], fg=ACCENT)
            else:
                final = self.stage_state["reboot"][0]
                self.working_spinner.configure(text="✓" if final == "done" else ("!" if final == "unknown" else "○"),
                                               fg=GREEN if final == "done" else (AMBER if final == "unknown" else MUTED))
        try:
            while True:
                event, *args = self.queue.get_nowait()
                if event == "trust":
                    host, fingerprint, request = args
                    request["allow"] = messagebox.askyesno("Verify your Pager identity",
                        f"First connection to {host}.\n\nSSH fingerprint:\n{fingerprint}\n\n"
                        "Only trust if this is your Pager. A different saved key will be blocked.", parent=self)
                    request["done"].set()
                elif event == "firmware_event":
                    op, *data = args
                    if op == "stage":
                        key, state, msg = data
                        self.stage_state[key] = (state, msg)
                        self._append_log(msg)
                        self._refresh_stages()
                    elif op == "progress":
                        self.upload_percent.set(data[0])
                        self._refresh_stages()
                    elif op == "irreversible":
                        self.issued_install = True
                        self._enable_update()
                        if not self.firmware_warning_shown:
                            self.firmware_warning_shown = True
                            messagebox.showwarning("DO NOT DISCONNECT — FLASHING IN PROGRESS",
                                "Firmware installation has started on your Pager.\n\n"
                                "DO NOT unplug USB-C, remove power, or restart the device.\n\n"
                                "The Pager will reboot on its own. Please wait patiently, "
                                "even if the screen or connection goes quiet.", parent=self)
                    elif op == "log":
                        self._append_log(data[0])
                elif event == "file_download_progress":
                    downloaded, total, name = args
                    self.file_transfer_percent.set(round(downloaded * 100 / max(total, 1)))
                    self.file_transfer_status.set("Downloading " + name + "  •  " +
                                                  str(self.file_transfer_percent.get()) + "%")
                elif event == "file_upload_event":
                    kind, *details = args
                    if kind == "progress":
                        transferred, total, number, count, filename = details
                        percent = round(transferred * 100 / max(1, total))
                        self.file_transfer_percent.set(percent)
                        self.file_transfer_status.set(
                            f"Uploading {number} of {count}: {filename}  •  {percent}%")
                    elif kind == "file_complete":
                        self._append_log("Uploaded file: " + details[0])
                elif event == "done":
                    tag, result = args
                    self.busy = False
                    self.current_task = None
                    if tag == "connect":
                        self.connection, self.connected_installer = result
                        self._append_log("Connected to your Pager over SSH")
                        self._update_connection_ui()
                        self.show_page("Dashboard")
                        if not self.connected_installer:
                            messagebox.showwarning("Firmware update unavailable",
                                "Pager connected. File Manager works, but the official firmware installer was not found on this device.", parent=self)
                    elif tag == "firmware_preflight":
                        installed, selected = result
                        verdict = compare_firmware_versions(installed, selected)
                        if verdict == "same":
                            self.update_activity.set("Already updated to version " + installed + ". No update needed.")
                            self._append_log("Firmware already matches installed version " + installed + ". Flash cancelled.")
                            messagebox.showinfo("Already up to date — no update needed",
                                "Your Pager is already running firmware " + installed + ".\n\n"
                                "The selected .bin is the same release. No firmware was uploaded or flashed.", parent=self)
                        else:
                            if verdict == "unknown":
                                detail = ("Installed version: " + (installed or "Unable to read") + "\n"
                                          "Selected .bin version: " + (selected or "Cannot identify from filename") + "\n\n"
                                          "The versions could not be reliably compared.\n"
                                          "Only continue if this is the correct official Hak5 firmware.")
                            else:
                                detail = ("Installed version: " + installed + "\n"
                                          "Selected .bin version: " + selected + "\n\n"
                                          "These versions are different.")
                            proceed = messagebox.askokcancel("Firmware version check and safety warning",
                                detail + "\n\n⚠  DO NOT DISCONNECT DURING FLASHING.\n"
                                "Keep the Pager powered on and connected until it restarts itself.\n\n"
                                "Start the firmware update?", icon="warning", parent=self)
                            if proceed:
                                self._begin_verified_firmware_update()
                            else:
                                self.update_activity.set("Firmware update cancelled. No changes made.")
                    elif tag == "update":
                        self.connection = None
                        self.connected_installer = False
                        self._update_connection_ui()
                        if result == "reconnected":
                            messagebox.showinfo("Pager back online",
                                "Your Pager became reachable again after restarting.\n\n"
                                "Check the installed firmware version on the Pager to confirm the update.", parent=self)
                        else:
                            messagebox.showwarning("Check the Pager",
                                "The firmware command was sent, but the Pager's restart was not confirmed.\n\n"
                                "Please be patient and allow the Pager to finish restarting on its own. "
                                "Keep it powered on. Check its screen and version before trying again.", parent=self)
                    elif tag == "virtual_check":
                        if hasattr(self, "virtual_btn") and self.virtual_btn.winfo_exists():
                            self.virtual_btn.config(state="normal")
                        self._launch_virtual_window(result)
                    elif tag == "files":
                        self._apply_file_list(result)
                    elif tag == "preview":
                        self.display_preview(*result)
                    elif tag == "open_local":
                        self._launch_pc_file(result)
                    elif tag == "download_item":
                        self.file_transfer_percent.set(100)
                        self.file_transfer_status.set("✓  Downloaded to your computer: " + str(result))
                        messagebox.showinfo("Download complete", "Saved to:\n" + str(result), parent=self)
                    elif tag == "terminal":
                        self.terminal_channel = result
                        self._terminal_append("Connected.\n")
                    elif tag == "upload":
                        names = result
                        self.file_transfer_percent.set(100)
                        self.file_transfer_status.set(f"✓  Uploaded {len(names)} file(s) successfully")
                        self.file_last_result = self.file_transfer_status.get()
                        self._append_log(self.file_last_result)
                        if self.page == "File Manager":
                            self.refresh_files()
                    elif tag in ("download", "mkdir", "delete"):
                        self._append_log(tag.capitalize() + " complete")
                        if self.page == "File Manager":
                            self.refresh_files()
                    self._update_connection_ui()
                elif event == "failure":
                    tag, message = args
                    self.busy = False
                    self.current_task = None
                    self._append_log("ERROR: " + message)
                    if tag == "download_item":
                        self.file_transfer_status.set("✕  Download stopped: " + message)
                    if tag == "upload":
                        self.file_transfer_status.set("✕  Upload stopped: " + message)
                        self.file_last_result = self.file_transfer_status.get()
                    if tag == "virtual_check":
                        if hasattr(self, "virtual_btn") and self.virtual_btn.winfo_exists():
                            self.virtual_btn.config(state="normal")
                        self.virtual_status.set("✕  Can't reach the Virtual Pager. Check USB and device setup.")
                    if tag == "connect":
                        self.connection = None
                        self.connected_installer = False
                    if tag == "update":
                        if self.issued_install:
                            self.connection = None
                            self.connected_installer = False
                        else:
                            for k in ("upload", "verify"):
                                if self.stage_state[k][0] != "done":
                                    self.stage_state[k] = ("error", "Stopped before installation")
                            self._refresh_stages()
                    self._update_connection_ui()
                    if tag == "upload" and self.page == "File Manager" and self.connected():
                        self.refresh_files()
                    messagebox.showerror("Installation status uncertain" if self.issued_install else "Operation failed",
                         message + ("\n\nCheck your Pager before retrying. Keep it powered on if it may still be installing."
                                    if self.issued_install else ""), parent=self)
        except queue.Empty:
            pass
        channel = self.terminal_channel
        if channel is not None and self.page == "Pager Terminal":
            try:
                for _ in range(8):
                    if not channel.recv_ready():
                        break
                    chunk = channel.recv(16384)
                    if chunk:
                        self._terminal_append(chunk.decode("utf-8", errors="replace"))
                if channel.closed or channel.exit_status_ready():
                    self.close_terminal()
            except Exception as error:
                self._terminal_append("\nTerminal disconnected: " + str(error) + "\n")
                self.close_terminal()
        self.after(100, self._pump)

    def render_files(self):
        self.heading("File Manager", "Browse Pager files, drag in uploads from Windows, and download files or entire folders to your computer.", "Device files")
        if not self.connected():
            self._unavailable("Connect to your Pager first.")
            return

        banner = self.section(bottom=12)
        text(banner, "FILES WILL UPLOAD TO", 12, MUTED, bold=True).pack(anchor="w", pady=(0, 5))
        self.current_path_label = text(banner, self.remote_folder, 19, ACCENT, bold=True)
        self.current_path_label.pack(anchor="w", pady=(0, 14))
        controls = tk.Frame(banner, bg=PANEL)
        controls.pack(fill="x")
        self.back_folder_btn = action(controls, "←  BACK", self.back_folder)
        self.back_folder_btn.pack(side="left", padx=(0, 9))
        action(controls, "↑  UP ONE FOLDER", self.parent_folder).pack(side="left", padx=(0, 9))
        action(controls, "REFRESH FILES", self.refresh_files).pack(side="left")
        self._update_back_button()

        upload_panel = self.section(padding=18, bottom=12)
        zone = tk.Frame(upload_panel, bg=INPUT, highlightthickness=2,
                        highlightbackground=ACCENT, padx=18, pady=13)
        zone.pack(fill="x")
        self.file_drop_area = zone
        if self.dragdrop_enabled:
            headline = "↓  DRAG FILES OR FOLDERS HERE"
            explanation = "Drag files or folders from your computer into this window to upload them to the Pager."
        else:
            headline = "UPLOAD FILES OR FOLDERS FROM YOUR COMPUTER"
            explanation = "Use the button below. Drag-and-drop support is unavailable. You can still use Upload Files."
        label = text(zone, headline, 19, ACCENT, bold=True, wrap=760)
        label.pack(anchor="center")
        hint = text(zone, explanation, 13, MUTED, wrap=770)
        hint.pack(anchor="center", pady=(5, 13))
        upload_button = action(zone, "+  UPLOAD FILES", self.file_upload, primary=True, big=True)
        upload_button.pack(anchor="center", fill="x")
        self.upload_files_button = upload_button
        action(zone, "+  UPLOAD FOLDER", self.folder_upload, big=True).pack(anchor="center", fill="x", pady=(8,0))
        self.file_transfer_bar = ttk.Progressbar(upload_panel, variable=self.file_transfer_percent,
                             maximum=100, style="GS.Horizontal.TProgressbar", mode="determinate")
        self.file_transfer_bar.pack(fill="x", pady=(15, 7))
        text(upload_panel, "Upload status", 12, MUTED, bold=True).pack(anchor="w")
        tk.Label(upload_panel, textvariable=self.file_transfer_status, font=(FONT, 13),
                 bg=PANEL, fg=WHITE, justify="left", anchor="w", wraplength=820).pack(fill="x", pady=(5, 0))

        outer, inside = card(self.main, 15)
        outer.pack(fill="both", expand=True, padx=34, pady=(0, 14))
        text(inside, "FILES ON YOUR PAGER  •  Select any file or folder, then choose Download to Your Computer", 15, bold=True).pack(anchor="w", pady=(0, 11))
        self.file_tree = ttk.Treeview(inside, columns=("name", "type", "size"),
                                     show="headings", style="GS.Treeview", selectmode="browse", height=8)
        self.file_tree.heading("name", text="NAME")
        self.file_tree.heading("type", text="TYPE")
        self.file_tree.heading("size", text="SIZE")
        self.file_tree.column("name", width=450, minwidth=120)
        self.file_tree.column("type", width=125, minwidth=80)
        self.file_tree.column("size", width=130, minwidth=80, anchor="e")
        self.file_tree.pack(fill="both", expand=True)
        self.file_tree.bind("<Double-1>", lambda _: self.open_on_computer())
        self.file_tree.bind("<Return>", lambda _: self.open_on_computer())
        # Never initiate a file drag FROM the Pager list. A normal selection
        # and the explicit Download to Your Computer action are the only
        # outbound transfer paths. This also blocks stale TkDND drag motions.
        self.file_tree.bind("<B1-Motion>", lambda _event: "break")
        self.file_tree.bind("<MouseWheel>", self._wheel)
        self.file_tree.bind("<Button-4>", self._wheel)
        self.file_tree.bind("<Button-5>", self._wheel)
        tools = self.section()
        file_actions = tk.Frame(tools, bg=PANEL)
        file_actions.pack(fill="x", pady=(0, 8))
        for caption, callback in (("OPEN / PREVIEW", self.open_selected),
                                  ("OPEN ON MY COMPUTER", self.open_on_computer),
                                  ("DOWNLOAD TO YOUR COMPUTER", self.file_download)):
            action(file_actions, caption, callback, primary=caption == "DOWNLOAD TO YOUR COMPUTER").pack(side="left", padx=(0, 7))
        folder_actions = tk.Frame(tools, bg=PANEL)
        folder_actions.pack(fill="x")
        for caption, callback in (("NEW FOLDER", self.file_new_folder),
                                  ("DELETE SELECTED", self.file_delete)):
            action(folder_actions, caption, callback, danger=caption == "DELETE SELECTED").pack(side="left", padx=(0, 7))
        if self.dragdrop_enabled:
            # Drop targets ACCEPT files dragged from Windows Explorer; they
            # never initiate a drag from the Pager. Outgoing drag would require
            # a separate outgoing drag-source handler, neither of
            # which exists in this app.
            #
            # Register the *entire* File Manager area and every child. Windows
            # sends <<Drop>> to the actual widget under the cursor, often a
            # label, button, file row, or scrollable frame instead of the
            # decorative upload frame. Registering only four widgets made
            # inbound drag-and-drop appear broken on many screen positions.
            self._register_inbound_file_drops(self.main)
        self.refresh_files()

    def _register_inbound_file_drops(self, container):
        """Enable Explorer -> Pager uploads throughout the File Manager ONLY.

        TkDND drop_target_register is RECEIVE-only. This never enables
        dragging device contents to Explorer; those transfers still require
        the explicit Download to Your Computer button.
        """
        pending = [container]
        registered = 0
        while pending:
            widget = pending.pop()
            pending.extend(widget.winfo_children())
            try:
                widget.drop_target_register(DND_FILES)
                widget.dnd_bind("<<Drop>>", self._file_drop)
                widget.dnd_bind("<<DropEnter>>", lambda _event: "copy")
                widget.dnd_bind("<<DropPosition>>", lambda _event: "copy")
                registered += 1
            except (tk.TclError, AttributeError):
                # Some Windows/native widgets may not support registration.
                # Continue registering their siblings rather than disabling
                # uploads for the entire File Manager.
                continue
        self.dragdrop_enabled = registered > 0
        if not registered:
            self.file_transfer_status.set(
                "Drag and drop is unavailable here. Use Upload Files or Upload Folder."
            )


    def _file_drop(self, event):
        if not self.connected():
            messagebox.showinfo("Connect your Pager", "Connect to your Pager before uploading files.", parent=self)
            return "none"
        if self.busy:
            self.file_transfer_status.set("An operation is still running. Try again when it finishes.")
            return "none"
        try:
            # Tk splitlist preserves Windows paths containing spaces and braces.
            paths = self.tk.splitlist(event.data)
        except tk.TclError:
            messagebox.showerror("Couldn't read these files", "Try the Upload Files button instead.", parent=self)
            return "none"
        self._prepare_file_upload(paths)
        return "copy"

    def _unavailable(self, message):
        body = self.section()
        text(body, "○  Connect your Pager first", 19, AMBER, bold=True).pack(anchor="w")
        text(body, message, 14, MUTED).pack(anchor="w", pady=(12, 20))
        action(body, "GO TO CONNECT DEVICE", lambda: self.show_page("Connect Device"), primary=True, big=True).pack(anchor="w")

    def refresh_files(self):
        if self.busy or not self.connected():
            return
        if hasattr(self, "current_path_label") and self.current_path_label.winfo_exists():
            self.current_path_label.config(text=self.remote_folder)
        folder = self.remote_folder
        self._start_task(lambda: self.connection.list_folder(folder), "files")

    def _apply_file_list(self, files):
        if self.page != "File Manager":
            return
        self.file_tree.delete(*self.file_tree.get_children())
        self.remote_rows = {}
        for index, f in enumerate(files):
            isfolder = stat.S_ISDIR(f.st_mode)
            kind = "Folder" if isfolder else "File"
            size = "—" if isfolder else (f"{f.st_size / 1024:,.1f} KB" if f.st_size < 1048576 else f"{f.st_size / 1048576:,.1f} MB")
            key = str(index)
            self.remote_rows[key] = (f.filename, isfolder)
            self.file_tree.insert("", "end", iid=key, values=(("📁  " if isfolder else "📄  ") + f.filename, kind, size))

    def _selected_remote(self):
        if not hasattr(self, "file_tree") or not self.file_tree.winfo_exists():
            return None
        selected = self.file_tree.selection()
        return self.remote_rows.get(selected[0]) if selected else None

    def _update_back_button(self):
        if hasattr(self, "back_folder_btn") and self.back_folder_btn.winfo_exists():
            self.back_folder_btn.configure(state="normal" if self.folder_history else "disabled")

    def _enter_folder(self, folder):
        folder = posixpath.normpath(folder)
        if folder != self.remote_folder:
            self.folder_history.append(self.remote_folder)
            self.remote_folder = folder
            self._update_back_button()
            self.refresh_files()

    def back_folder(self):
        """Return to the last browsed directory, not merely its parent."""
        if self.busy or not self.folder_history:
            return
        self.remote_folder = self.folder_history.pop()
        self._update_back_button()
        self.refresh_files()

    def parent_folder(self):
        if self.busy:
            return
        self._enter_folder(posixpath.dirname(self.remote_folder.rstrip("/")) or "/")

    def open_selected(self):
        row = self._selected_remote()
        if not row:
            return
        if not row[1]:
            remote = posixpath.join(self.remote_folder, row[0])
            self._start_task(lambda: (row[0], self.connection.read_preview(remote)), "preview")
            return
        self._enter_folder(posixpath.join(self.remote_folder, row[0]))

    def display_preview(self, filename, data):
        window = tk.Toplevel(self)
        window.title("View File — " + filename)
        window.geometry("850x680")
        window.configure(bg=BG)
        if APP_ICON.exists():
            try:
                window.iconbitmap(str(APP_ICON))
            except tk.TclError:
                pass
        header = tk.Frame(window, bg=SIDE, padx=20, pady=15)
        header.pack(fill="x")
        text(header, filename, 19, bold=True).pack(anchor="w")
        text(header, "Read-only preview • File remains on your Pager", 12, MUTED).pack(anchor="w", pady=(4, 0))
        ext = Path(filename).suffix.lower()
        if ext in (".png", ".gif"):
            try:
                img = tk.PhotoImage(data=base64.b64encode(data))
                frame = tk.Frame(window, bg=BG)
                frame.pack(fill="both", expand=True, padx=20, pady=20)
                label = tk.Label(frame, image=img, bg=BG)
                label.image = img
                label.pack(anchor="center")
                return
            except tk.TclError:
                pass
        if b"\x00" in data[:8192] or ext in (".zip", ".bin", ".jpg", ".jpeg", ".webp", ".ico"):
            explanation = "This file is binary or an image format without a built-in preview. Select it in File Manager and click DOWNLOAD to open it on Windows."
            text(window, explanation, 15, MUTED, wrap=770).pack(anchor="w", padx=22, pady=30)
            return
        view = tk.Text(window, bg="#090d17", fg=WHITE, font=("Consolas", 12),
                       wrap="none", relief="flat", padx=18, pady=18)
        view.pack(fill="both", expand=True, padx=18, pady=18)
        view.insert("1.0", data.decode("utf-8", errors="replace"))
        view.configure(state="disabled")

    def open_on_computer(self):
        """Copy selected remote file locally and open via the user's Windows association.

        Never pass an untrusted remote path directly to the local shell; SFTP
        downloads a copy first. Script/executable formats need manual Save As.
        """
        if not self.connected() or self.busy:
            return
        row = self._selected_remote()
        if not row:
            messagebox.showinfo("Choose a file", "Select a file from the list first.", parent=self)
            return
        if row[1]:
            self._enter_folder(posixpath.join(self.remote_folder, row[0]))
            return
        filename = row[0]
        dangerous = {".exe", ".com", ".scr", ".msi", ".msp", ".bat", ".cmd",
                     ".ps1", ".psm1", ".vbs", ".vbe", ".wsf", ".wsh", ".hta",
                     ".lnk", ".url", ".reg", ".cpl", ".jar", ".js", ".jse",
                     ".py", ".pyw", ".sh"}
        if Path(filename).suffix.lower() in dangerous:
            messagebox.showwarning("Open on PC is restricted for this file type",
                "This file type can execute commands on Windows. For safety, choose DOWNLOAD "
                "to save it, examine it, and open it manually if you trust it.", parent=self)
            return
        if not messagebox.askyesno("Open this Pager file on your PC?",
                "A temporary copy of '" + filename + "' will be downloaded to your "
                "computer and opened using its default application.\n\n"
                "Only open files that you trust. The file on the Pager won't change.\n\nContinue?",
                parent=self):
            return
        safe_name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", filename).strip(" .")
        if not safe_name or safe_name.upper().split(".")[0] in {"CON","PRN","AUX","NUL","COM1","LPT1"}:
            safe_name = "pager-file" + Path(filename).suffix
        temporary_folder = tempfile.mkdtemp(prefix="GS-Pager-Open-")
        local_path = str(Path(temporary_folder) / safe_name)
        remote_path = posixpath.join(self.remote_folder, filename)
        self._append_log("Opening a local copy of " + filename)
        self._start_task(lambda: self._download_for_open(remote_path, local_path), "open_local")

    def _download_for_open(self, remote_path, local_path):
        try:
            self.connection.download_file(remote_path, local_path)
            return local_path
        except Exception:
            try:
                shutil.rmtree(Path(local_path).parent)
            except OSError:
                pass
            raise

    def _launch_pc_file(self, local_path):
        try:
            if os.name != "nt":
                raise OSError("Open on Computer is available in the Windows build only.")
            os.startfile(local_path)
            self.opened_pc_files.append(local_path)
            self._append_log("Opened local copy: " + Path(local_path).name)
        except Exception as error:
            messagebox.showerror("Windows could not open this file",
                "The file was downloaded to:\n" + local_path +
                "\n\nWindows could not find an app to open it: " + str(error) +
                "\n\nYou can choose Download to save it elsewhere.", parent=self)

    def file_upload(self):
        if not self.connected() or self.busy:
            return
        paths = filedialog.askopenfilenames(parent=self, title="Choose files to upload to your Pager")
        self._prepare_file_upload(paths)

    def folder_upload(self):
        if not self.connected() or self.busy:
            return
        folder = filedialog.askdirectory(parent=self, title="Choose a folder and all its contents to upload")
        if folder:
            self._prepare_file_upload([folder])

    def _prepare_file_upload(self, paths):
        if not paths or not self.connected() or self.busy:
            return
        paths = list(dict.fromkeys(str(Path(p)) for p in paths))
        if len(paths) > 100:
            messagebox.showwarning("Too many items", "Choose up to 100 files or folders at a time.", parent=self)
            return
        if any(not Path(p).exists() or Path(p).is_symlink() for p in paths):
            messagebox.showerror("Invalid selection", "Select existing regular files or folders; shortcuts/links aren't supported.", parent=self)
            return
        names = [Path(p).name for p in paths]
        if len({n.casefold() for n in names}) != len(names):
            messagebox.showerror("Duplicate names", "Two items have the same name. Rename one before uploading.", parent=self)
            return
        existing = {name.casefold(): (name, isdir) for name, isdir in self.remote_rows.values()}
        collisions = [name for name in names if name.casefold() in existing]
        approved_replacements = set()
        if collisions:
            choice = messagebox.askyesnocancel("Replace existing Pager items?",
                "These files or folders already exist on the Pager:\n\n" +
                "\n".join(collisions[:9]) + ("\n...and more" if len(collisions) > 9 else "") +
                "\n\nYES: Replace the entire matching item (a folder's old contents will be removed).\n"
                "NO: Skip items with matching names.\nCANCEL: Do nothing.\n\n"
                "Back up anything important before replacing a folder.", parent=self)
            if choice is None:
                return
            if choice:
                approved_replacements = set(collisions)
            else:
                paths = [p for p in paths if Path(p).name not in collisions]
                if not paths:
                    self.file_transfer_status.set("Nothing to upload — all selected items already exist.")
                    return
        folder = self.remote_folder
        self.file_transfer_percent.set(0)
        self.file_transfer_status.set(f"Uploading {len(paths)} item(s) → {folder}")
        def report(*args):
            self.queue.put(("file_upload_event", *args))
        self._start_task(lambda: self.connection.upload_items(paths, folder, overwrite_names=approved_replacements,
                                                               notify=report), "upload")

    def file_download(self):
        """Explicit download only: files and folders are copied to a chosen PC folder.

        Dragging from the Pager file list to Explorer is intentionally disabled;
        Windows-to-Pager drag-and-drop uploads are still supported.
        """
        if not self.connected() or self.busy:
            return
        row = self._selected_remote()
        if not row:
            messagebox.showinfo("Choose an item",
                "Select a file or folder on your Pager, then click DOWNLOAD TO YOUR COMPUTER.", parent=self)
            return
        name, is_folder = row
        base = filedialog.askdirectory(parent=self,
            title="Choose where to download this " + ("folder" if is_folder else "file"))
        if not base:
            return
        destination = Path(base) / name
        if destination.exists() or destination.is_symlink():
            messagebox.showwarning("Item already exists",
                "A file or folder with that name already exists on your computer. "
                "Choose a different destination folder or rename the existing item first. "
                "Your computer's files will not be overwritten.", parent=self)
            return
        remote = posixpath.join(self.remote_folder, name)
        self.file_transfer_percent.set(0)
        self.file_transfer_status.set("Downloading " + ("folder " if is_folder else "file ") + name + " to your computer...")
        def report(done, total):
            self.queue.put(("file_download_progress", done, total, name))
        self._start_task(lambda: self.connection.download_item(remote, str(destination), report), "download_item")

    def file_download_folder(self):
        """Compatibility shim for the existing folder action; same download button."""
        return self.file_download()

    def file_new_folder(self):
        if not self.connected() or self.busy:
            return
        name = simpledialog.askstring("New folder", "Folder name:", parent=self)
        if not name:
            return
        if not re.fullmatch(r"[A-Za-z0-9._ -]{1,90}", name) or name in (".", ".."):
            messagebox.showerror("Invalid name", "Use letters, numbers, spaces, dots, hyphens, and underscores.", parent=self)
            return
        self._start_task(lambda: self.connection.make_folder(posixpath.join(self.remote_folder, name)), "mkdir")

    def file_delete(self):
        if not self.connected() or self.busy:
            return
        row = self._selected_remote()
        if not row:
            messagebox.showinfo("Select an item", "Choose the file or folder you want to delete.", parent=self)
            return
        name, is_folder = row
        confirm = ("Delete the entire folder '" + name + "' and ALL contents, including subfolders?\n\n"
                   "This cannot be undone. Please be certain you have a backup.") if is_folder else (
                   "Permanently delete the file '" + name + "' from the Pager? This cannot be undone.")
        if messagebox.askyesno("Delete folder and contents?" if is_folder else "Delete file?",
                               confirm, icon="warning", parent=self):
            self._start_task(lambda: self.connection.delete_path(posixpath.join(self.remote_folder, name)), "delete")

    def render_help(self):
        self.heading("Help & About", "Simple answers when you need them.", "Getting started")
        topics = [
            ("How do I connect?", "Connect the Pager with a USB-C data cable. It needs to be on, configured, and reachable over SSH. The usual address is 172.16.52.1 with username root and the password you created."),
            ("Where is the firmware updater?", "First connect your Pager. Then open the separate Firmware Update menu on the left side. Choose the official signed .bin file, check the backup box, and click Start Firmware Update."),
            ("What do the status symbols mean?", "○ Waiting   ◉ Working   ✓ Finished   ✕ Error   ! Needs checking. Upload shows a real percentage; during flashing and reboot the bar moves continuously because the Pager does not report a reliable percentage."),
            ("What if the connection drops during a firmware update?", "After the installer begins, a dropped SSH connection may be part of a reboot. Keep the Pager powered and connected; check the Pager itself before another attempt."),
            ("How do I open Virtual Pager?", "After connecting, choose Virtual Pager on the left and click OPEN VIRTUAL PAGER. It uses Hak5's live web interface at http://172.16.52.1:1471. You'll still need to log in to the website with your device password."),
            ("Where can I find Pager payloads and themes?", "Open Payloads & Themes from the sidebar for direct links to Hak5's official GitHub libraries."),
            ("How can I use the Pager terminal?", "Connect over SSH, then open Pager Terminal and select Start SSH Terminal. Commands run on the real device. Closing the tab disconnects the shell."),
            ("How do I download a whole folder?", "In File Manager, click a folder once to select it, then choose Download to Your Computer. Choose a destination on your PC; the complete folder and its contents will be saved there. Drag and drop is for uploads from Windows to the Pager only."),
            ("How do I open a Pager file on my computer?", "In File Manager, select a file and click Open on My Computer. The app downloads a temporary copy and opens it with the Windows default application. For executable scripts, use Download to Your Computer and inspect them first. Preview remains available separately."),
            ("How do I change the colors?", "Open Settings, then choose Black & Gray (default), Black & Yellow, or GhostStrats Purple. These colors only affect the Windows app."),
            ("How can I install a downloaded theme or payload?", "Use Payloads & Themes for direct Hak5 GitHub links. Download and extract the files. Upload payloads to the appropriate subfolder of /root/payloads/user/ (or /mmc/root/payloads/user/) and themes to /root/themes/ (or /mmc/root/themes/). Drag folders/files into File Manager or use Upload Files / Upload Folder. Follow the repository instructions."),
        ]
        for topic, answer in topics:
            panel = self.section()
            text(panel, topic, 18, bold=True).pack(anchor="w")
            text(panel, answer, 14, MUTED, wrap=805).pack(anchor="w", pady=(9, 0))
        links = self.section()
        action(links, "OFFICIAL FIRMWARE DOWNLOADS  ↗", lambda: webbrowser.open(DOWNLOAD_URL), primary=True).pack(side="left", padx=(0, 10))
        action(links, "OFFICIAL UPDATE GUIDE  ↗", lambda: webbrowser.open(DOCS_URL)).pack(side="left")
        action(links, "HAK5 PAGER GITHUB  ↗", lambda: webbrowser.open(HAK5_REPO)).pack(side="left", padx=(10, 0))
        text(links, "Independent GhostStrats community project — not affiliated with Hak5.", 12, MUTED).pack(anchor="w", pady=(19, 0))

    def _close(self):
        if self.issued_install and self.busy:
            messagebox.showwarning("Firmware update in progress",
                "Do not disconnect the Pager. The official installer may still be running.\n\n"
                "This window will remain open until monitoring finishes.", parent=self)
            return
        self.close_terminal()
        if self.connection:
            self.connection.close()
        self.destroy()


def run_virtual_pager_window(url):
    """Official device UI in a native WebView2 window; no screen is simulated."""
    try:
        import webview
    except ImportError:
        webbrowser.open(url)
        return
    try:
        webview.create_window("GS WiFI Pineapple Pager Companion App  |  Virtual Pager", url,
                              width=1160, height=820, min_size=(780, 550))
        webview.start(debug=False)
    except Exception as error:
        # WebView2 is not installed or its rendering backend is unavailable.
        # Don't hide the original UI: fall back to a normal browser.
        print("Embedded viewer unavailable:", error, file=sys.stderr)
        webbrowser.open(url)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--virtual-pager-window":
        url = sys.argv[2]
        if urlsplit(url).scheme == "http" and urlsplit(url).port == 1471:
            run_virtual_pager_window(url)
        else:
            raise SystemExit("Invalid Virtual Pager URL")
    else:
        App().mainloop()
