GS WiFI Pineapple Pager Companion App — Version 1.2 Release
======================================================================

This is an independent GhostStrats community project, NOT an official Hak5
product and not affiliated with or endorsed by Hak5.

INSTALLATION — WINDOWS 10/11 (64-BIT)
1. Extract this ZIP using Windows Explorer > Extract All.
2. Read DISCLAIMER.txt, then run:
   GS_WiFI_Pineapple_Pager_Companion_App_Setup_V1.2.exe
3. Close your running Pager app and choose Install / Upgrade.
4. Setup can install missing Python components when internet is available.
5. Launch from the newly installed Start Menu shortcut (not an old pin).

FILE MANAGER — V1.2 FILE MANAGER
- WINDOWS -> PAGER: Open File Manager, then drag a file or folder from
  Windows File Explorer or the Desktop into the File Manager window.
  Drops are accepted over the whole File Manager, including the file list,
  buttons and the upload panel. The app prompts before replacing files.
- PAGER -> WINDOWS: Dragging out is NOT supported. Select a file or folder
  on your Pager and click DOWNLOAD TO YOUR COMPUTER instead.
- Use UPLOAD FILES or UPLOAD FOLDER if drag-and-drop is unavailable.
- If you see "Preparing for drag to Windows Explorer", Windows is still
  launching an older application. Unpin and repin the newly installed app.

Everything else remains as in Version 1.2: original GhostStrats branding,
three themes, firmware updater, virtual Pager and Pager terminal.

This update was tested with automated checks and simulated GUI drop events.
Actual Explorer drag-and-drop and device transfer require Windows/Pager testing.
