GS WiFI Pineapple Pager Companion App — Version 1.2.1

Community-built Windows companion for the Hak5 WiFi Pineapple Pager.
Not an official Hak5 product; not affiliated with or endorsed by Hak5.

INSTALLATION
1. Extract the ZIP and double-click the Setup.exe included here.
2. Choose Install / Upgrade, then open the installed application.
3. Connect the Pager with a USB-C data cable and sign in.

NEW: RESET SAVED SSH KEY
If you factory-reset or reflashed your own Pager, a host key mismatch may block your next SSH login.
On Connect Device, click RESET SAVED SSH KEY and confirm. The app forgets only the key for the Pager address and SSH port you selected, saves a backup of the old trust file, and prompts you to verify the new SSH fingerprint on the next connection.
Never reset trust for an unexpected key change if you cannot confirm the device is your own.

FILE MANAGER
Drag files and folders from Windows into the app to upload. To download files or whole folders, select them and use DOWNLOAD TO YOUR COMPUTER. Dragging OUT of the app to Windows Explorer is intentionally disabled for stability.

See the source README for more details.
