GS WiFI Pineapple Pager Companion App — Version 1.2.2

Community-built Windows companion for the Hak5 WiFi Pineapple Pager.
Not an official Hak5 product; not affiliated with or endorsed by Hak5.

INSTALLATION
1. Extract the ZIP and double-click the Setup.exe included here.
2. Choose Install / Upgrade. An animated activity light, spinner, and elapsed timer show setup is still working even when a stage percentage stays the same.
3. Open the installed application.
4. After powering on the Pager, allow about 60 seconds for startup before plugging
   it into your computer using a USB-C data-transfer cable. Then sign in.
5. If the connection times out, click Connect to Pager again and check your
   cable: some USB-C cables charge only and cannot transfer data.

NEW: RESET SAVED SSH KEY
If you factory-reset or reflashed your own Pager, a host key mismatch may block your next SSH login.
On Connect Device, click RESET SAVED SSH KEY and confirm. The app forgets only the key for the Pager address and SSH port you selected, saves a backup of the old trust file, and prompts you to verify the new SSH fingerprint on the next connection.
Never reset trust for an unexpected key change if you cannot confirm the device is your own.

FILE MANAGER
Drag files and folders from Windows into the app to upload. To download files or whole folders, select them and use DOWNLOAD TO YOUR COMPUTER. Dragging OUT of the app to Windows Explorer is intentionally disabled for stability.

See the source README for more details.
