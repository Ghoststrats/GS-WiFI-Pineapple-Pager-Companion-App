package main

import (
 "archive/zip"
 "bytes"
 _ "embed"
 "encoding/json"
 "errors"
 "fmt"
 "io"
 "net/http"
 "os"
 "os/exec"
 "path/filepath"
 "runtime"
 "strings"
 "sync"
 "syscall"
 "time"
 "unsafe"
)

//go:embed payload.zip
var payload []byte
//go:embed brand.bmp
var brandArt []byte
//go:embed app_icon.ico
var appIcon []byte
const (
 appName = "GS WiFI Pineapple Pager Companion App"
 version = "1.2"
 fileBase = "GS_WiFI_Pineapple_Pager_Companion_App"
 winTitle = appName + " - Setup " + version
 pythonPage = "https://www.python.org/downloads/windows/"
 pythonURL = "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe"
 WM_CREATE=0x0001; WM_DESTROY=0x0002; WM_COMMAND=0x0111; WM_CLOSE=0x0010; WM_CTLCOLORSTATIC=0x0138; WM_CTLCOLORLISTBOX=0x0134; WM_ERASEBKGND=0x0014; WM_PAINT=0x000F; WM_DRAWITEM=0x002B; WM_APP=0x8000
 WM_SETFONT=0x0030; WM_SETICON=0x0080; STM_SETIMAGE=0x0172; SS_BITMAP=0x000E; LR_LOADFROMFILE=0x0010; IMAGE_ICON=1
 WS_VISIBLE=0x10000000; WS_CHILD=0x40000000; WS_OVERLAPPEDWINDOW=0x00CF0000
 WS_CAPTION=0x00C00000; WS_SYSMENU=0x00080000; WS_MINIMIZEBOX=0x00020000; WS_OVERLAPPED=0
 WS_VSCROLL=0x00200000; LBS_NOINTEGRALHEIGHT=0x0100; LBS_DISABLENOSCROLL=0x1000
 SS_LEFT=0; BS_PUSHBUTTON=0; BS_DEFPUSHBUTTON=1; BS_OWNERDRAW=0x0000000B
 DT_CENTER=1; DT_VCENTER=4; DT_SINGLELINE=0x20; DT_NOPREFIX=0x800
 ODS_SELECTED=0x0001; ODS_DISABLED=0x0004; ODS_FOCUS=0x0010
 LB_ADDSTRING=0x0180; LB_SETTOPINDEX=0x0197; LB_GETCOUNT=0x018B
 SW_SHOW=5; SW_HIDE=0
 MB_OK=0; MB_OKCANCEL=1; MB_YESNO=4; MB_ICONWARNING=0x30; MB_ICONERROR=0x10; MB_ICONINFORMATION=0x40
 IDYES=6; IDOK=1
 COLOR_PURPLE=0x00BF35A3 // COLORREF BGR, deep electric purple #A335BF
 COLOR_DARK=0x00140E0D // near-black #0D0E14
 COLOR_PANEL=0x002A1920 // charcoal-violet #20192A
 COLOR_BUTTON=0x002D1B25 // dark plum #251B2D
 COLOR_OUTLINE=0x005C2A4F // muted purple border #4F2A5C
 COLOR_TEXT=0x00FFFFFF; COLOR_MUTED=0x00DAC9CC
 COLOR_ACCENT=0x00F383C5 // soft lavender #C583F3
 IDINSTALL=1001; IDREPAIR=1002; IDREMOVE=1003; IDPYTHON=1004; IDCLOSE=1005
)
var user32=syscall.NewLazyDLL("user32.dll")
var gdi32=syscall.NewLazyDLL("gdi32.dll")
var kernel32=syscall.NewLazyDLL("kernel32.dll")
var dwmapi=syscall.NewLazyDLL("dwmapi.dll")
var uxtheme=syscall.NewLazyDLL("uxtheme.dll")
var (
 pRegisterClass=user32.NewProc("RegisterClassExW")
 pCreateWindow=user32.NewProc("CreateWindowExW")
 pDefWindow=user32.NewProc("DefWindowProcW")
 pGetMessage=user32.NewProc("GetMessageW")
 pTranslate=user32.NewProc("TranslateMessage")
 pDispatch=user32.NewProc("DispatchMessageW")
 pPostMessage=user32.NewProc("PostMessageW")
 pSendMessage=user32.NewProc("SendMessageW")
 pSetText=user32.NewProc("SetWindowTextW")
 pSetPos=user32.NewProc("SetWindowPos")
 pEnable=user32.NewProc("EnableWindow")
 pDestroy=user32.NewProc("DestroyWindow")
 pPostQuit=user32.NewProc("PostQuitMessage")
 pLoadCursor=user32.NewProc("LoadCursorW")
 pGetModule=kernel32.NewProc("GetModuleHandleW")
 pCreateBrush=gdi32.NewProc("CreateSolidBrush")
 pSetBkMode=gdi32.NewProc("SetBkMode")
 pSetTextColor=gdi32.NewProc("SetTextColor")
 pCreateFont=gdi32.NewProc("CreateFontW")
 pFillRect=user32.NewProc("FillRect")
 pBeginPaint=user32.NewProc("BeginPaint")
 pEndPaint=user32.NewProc("EndPaint")
 pDrawText=user32.NewProc("DrawTextW")
 pSetBkColor=gdi32.NewProc("SetBkColor")
 pSelectObject=gdi32.NewProc("SelectObject")
 pDeleteObject=gdi32.NewProc("DeleteObject")
 pCreatePen=gdi32.NewProc("CreatePen")
 pRoundRect=gdi32.NewProc("RoundRect")
 pGetWindowText=user32.NewProc("GetWindowTextW")
 pGetDlgCtrlID=user32.NewProc("GetDlgCtrlID")
 pDwmSetWindowAttribute=dwmapi.NewProc("DwmSetWindowAttribute")
)
type wndClass struct{ Size uint32; Style uint32; WndProc uintptr; ClsExtra int32; WndExtra int32; Instance uintptr; Icon uintptr; Cursor uintptr; Background uintptr; MenuName *uint16; ClassName *uint16; IconSmall uintptr }
type rect struct{Left,Top,Right,Bottom int32}
type paintStruct struct{HDC uintptr;Erase int32;RcPaint rect;Restore int32;IncUpdate int32;Reserved [32]byte}
type drawItem struct{CtlType,CtlID,ItemID,ItemAction,ItemState uint32;HwndItem,HDC uintptr;RcItem rect;ItemData uintptr}
type point struct{X,Y int32}
type msg struct{Hwnd uintptr;Message uint32;Wparam,Lparam uintptr;Time uint32;Pt point;Private uint32}
type event struct{message string;percent int;done bool;err error}
var hMain uintptr
var brandTemp string
var brandBitmap uintptr
var iconTemp string
var installerIconBig uintptr
var installerIconSmall uintptr
var hProgressBg,hProgressFill,hStatus,hSubtitle,hAction uintptr
var widgets=[]uintptr{}
var fontNormal,fontTitle,fontSmall uintptr
var brushBg,brushPanel,brushPurple,brushButton,brushOutline uintptr
var buttonLabels=map[uintptr]string{}
var accentButtons=map[int]bool{IDINSTALL:true}
var classBrush uintptr
var taskMu sync.Mutex
var busy bool
var events=make(chan event,256)
var currentPercent int
var legacyTitles=[]string{"GS WiFi Pager Companion App","GS Wi-Fi Pineapple Pager GUI","GPS Wifi Paget Companion App","GS WiFi Pineapple Pager GUI","GS WiFi Pineapple Pager Companion App"}
var legacyFolders=[]string{"GS WiFi Pager Companion App","GS WiFi Pineapple Pager GUI","GS Wi-Fi Pineapple Pager GUI","GPS Wifi Paget Companion App","GS_WiFi_Pager_Companion_App","GS WiFi Pineapple Pager Companion App","GS WiFI Pineapple Pager Companion App"}

func utf(s string)*uint16 {p,_:=syscall.UTF16PtrFromString(s);return p}
func call(p *syscall.LazyProc,args ...uintptr)uintptr{r,_,_:=p.Call(args...);return r}
func msgBox(title,s string,flags uintptr)int {return int(call(user32.NewProc("MessageBoxW"),hMain,uintptr(unsafe.Pointer(utf(s))),uintptr(unsafe.Pointer(utf(title))),flags))}
func say(s string){msgBox(winTitle,s,MB_OK|MB_ICONINFORMATION)}
func newWnd(class,name string,style,exStyle uintptr,x,y,w,h int,parent uintptr,id int)uintptr{
 r:=call(pCreateWindow,exStyle,uintptr(unsafe.Pointer(utf(class))),uintptr(unsafe.Pointer(utf(name))),style,uintptr(x),uintptr(y),uintptr(w),uintptr(h),parent,uintptr(id),call(pGetModule,0),0)
 return r
}
func makeText(name string,x,y,w,h int,size uintptr)uintptr{q:=newWnd("STATIC",name,WS_VISIBLE|WS_CHILD|SS_LEFT,0,x,y,w,h,hMain,0);call(pSendMessage,q,WM_SETFONT,size,1);widgets=append(widgets,q);return q}
func makeButton(name string,x,y,w,h,id int)uintptr{
 q:=newWnd("BUTTON",name,WS_VISIBLE|WS_CHILD|BS_OWNERDRAW,0,x,y,w,h,hMain,id)
 call(pSendMessage,q,WM_SETFONT,fontNormal,1);widgets=append(widgets,q);buttonLabels[q]=name;return q
}
func createFont(px int,bold bool)uintptr{weight:=uintptr(400);if bold{weight=700};return call(pCreateFont,uintptr(px),0,0,0,weight,0,0,0,1,0,0,0,0,uintptr(unsafe.Pointer(utf("Segoe UI"))))}
func logLine(s string){if hStatus==0{return};call(pSendMessage,hStatus,LB_ADDSTRING,0,uintptr(unsafe.Pointer(utf(s))));cnt:=int(call(pSendMessage,hStatus,LB_GETCOUNT,0,0));if cnt>0{call(pSendMessage,hStatus,LB_SETTOPINDEX,uintptr(cnt-1),0)}}
func setProgress(p int){if p<0 {p=0};if p>100{p=100};currentPercent=p;size:=int(float64(730)*float64(p)/100);if p==0{size=0};call(pSetPos,hProgressFill,0,0,0,uintptr(size),uintptr(14),0x0002|0x0004);call(pSetText,hAction,uintptr(unsafe.Pointer(utf(fmt.Sprintf("Installation progress: %d%%",p))))) }
func postEvent(m string,p int,done bool,err error){events<-event{m,p,done,err};call(pPostMessage,hMain,WM_APP+1,0,0)}
func setBusy(v bool){busy=v;for _,q:=range actionButtons{if v{call(pEnable,q,0)}else{call(pEnable,q,1)}}
}
var actionButtons=[]uintptr{}
func begin(mode string){taskMu.Lock();if busy{taskMu.Unlock();return};setBusy(true);taskMu.Unlock();logLine("Working: "+mode)
 go func(){err:=perform(mode,func(s string,n int){postEvent(s,n,false,nil)});percent:=100; if err!=nil {percent=-1}; postEvent("",percent,true,err)}()
}
func makeRect(x,y,w,h int)rect{return rect{int32(x),int32(y),int32(x+w),int32(y+h)}}
func solidRect(dc uintptr,r rect,brush uintptr){call(pFillRect,dc,uintptr(unsafe.Pointer(&r)),brush)}
func darkWindow(hwnd uintptr){
 // Windows 10/11 DWM: dark native title bar, border, caption text.
 yes:=int32(1)
 if call(pDwmSetWindowAttribute,hwnd,20,uintptr(unsafe.Pointer(&yes)),4)!=0{
  call(pDwmSetWindowAttribute,hwnd,19,uintptr(unsafe.Pointer(&yes)),4)
 }
 caption:=uint32(COLOR_DARK);border:=uint32(COLOR_OUTLINE);white:=uint32(COLOR_TEXT)
 call(pDwmSetWindowAttribute,hwnd,35,uintptr(unsafe.Pointer(&caption)),4)
 call(pDwmSetWindowAttribute,hwnd,34,uintptr(unsafe.Pointer(&border)),4)
 call(pDwmSetWindowAttribute,hwnd,36,uintptr(unsafe.Pointer(&white)),4)
}
func paintButton(di *drawItem){
 dc:=di.HDC; r:=di.RcItem
 id:=int(di.CtlID);selected:=di.ItemState&ODS_SELECTED!=0;disabled:=di.ItemState&ODS_DISABLED!=0
 fill:=COLOR_BUTTON;edge:=COLOR_OUTLINE;ink:=COLOR_TEXT
 if accentButtons[id]{fill=COLOR_PURPLE;edge=COLOR_ACCENT}
 if selected{fill=COLOR_PANEL}
 if disabled {fill=COLOR_PANEL;edge=COLOR_OUTLINE;ink=COLOR_MUTED}
 b:=call(pCreateBrush,uintptr(fill));pen:=call(pCreatePen,0,1,uintptr(edge))
 oldb:=call(pSelectObject,dc,b);oldp:=call(pSelectObject,dc,pen)
 call(pRoundRect,dc,uintptr(r.Left),uintptr(r.Top),uintptr(r.Right),uintptr(r.Bottom),12,12)
 call(pSelectObject,dc,oldp);call(pSelectObject,dc,oldb);call(pDeleteObject,pen);call(pDeleteObject,b)
 oldFont:=call(pSelectObject,dc,fontNormal)
 call(pSetBkMode,dc,1);call(pSetTextColor,dc,uintptr(ink))
 textLabel:=buttonLabels[di.HwndItem]
 if textLabel!=""{t:=utf(textLabel);call(pDrawText,dc,uintptr(unsafe.Pointer(t)),uintptr(^uint32(0)),uintptr(unsafe.Pointer(&r)),DT_CENTER|DT_VCENTER|DT_SINGLELINE|DT_NOPREFIX)}
 call(pSelectObject,dc,oldFont)
}
func drawPanel(dc uintptr){
 // Solid dark canvas behind all static labels. No system-white strips.
 solidRect(dc,makeRect(0,0,1140,790),brushBg)
 solidRect(dc,makeRect(325,0,3,780),brushPurple)
 solidRect(dc,makeRect(345,198,740,1),brushOutline)
 solidRect(dc,makeRect(345,290,740,1),brushOutline)
 solidRect(dc,makeRect(345,459,740,1),brushOutline)
 solidRect(dc,makeRect(345,497,740,1),brushOutline)
 solidRect(dc,makeRect(345,675,740,1),brushOutline)
 solidRect(dc,makeRect(345,501,740,109),brushPanel)
 solidRect(dc,makeRect(345,616,740,24),brushPanel)
}
func showBrand(){
 if brandTemp=="" {return}
 bmp:=call(user32.NewProc("LoadImageW"),0,uintptr(unsafe.Pointer(utf(brandTemp))),0,0,0,LR_LOADFROMFILE)
 if bmp==0{return}
 brandBitmap=bmp
 q:=newWnd("STATIC","",WS_VISIBLE|WS_CHILD|SS_BITMAP,0,0,0,324,710,hMain,0)
 call(pSendMessage,q,STM_SETIMAGE,0,bmp)
}
func windowProc(hwnd uintptr,code uint32,wparam,lparam uintptr)uintptr{
 switch code{
 case WM_CREATE:
  hMain=hwnd
  brushBg=classBrush
  brushPanel=call(pCreateBrush,COLOR_PANEL);brushPurple=call(pCreateBrush,COLOR_PURPLE)
  brushButton=call(pCreateBrush,COLOR_BUTTON);brushOutline=call(pCreateBrush,COLOR_OUTLINE)
  darkWindow(hwnd)
  if installerIconBig!=0{call(pSendMessage,hwnd,WM_SETICON,1,installerIconBig)}
  if installerIconSmall!=0{call(pSendMessage,hwnd,WM_SETICON,0,installerIconSmall)}
  fontNormal=createFont(-18,false);fontTitle=createFont(-28,true);fontSmall=createFont(-15,false)
  showBrand()
  makeText("GHOSTSTRATS   /   WINDOWS SETUP",350,24,755,28,fontSmall)
  makeText(appName,350,61,765,48,fontTitle)
  makeText("A simpler way to manage your Hak5 WiFi Pineapple Pager.",350,119,755,32,fontNormal)
  makeText("Community-built companion app. Not affiliated with Hak5.",350,155,755,27,fontSmall)
  makeText("INSTALL OPTIONS   /   VERSION "+version,350,215,755,30,fontNormal)
  makeText("Your existing appearance settings and Pager device files are preserved.",350,251,755,28,fontSmall)
  makeText("PYTHON REQUIREMENT",350,311,755,25,fontNormal)
  makeText("Python 3.9–3.13 with Tkinter is required. Setup can install Python 3.12 if needed.",350,341,755,26,fontSmall)
  makeText("Internet is required if Python or application packages are missing.",350,371,755,24,fontSmall)
  makeButton("Open Official Python Download",350,403,324,42,IDPYTHON)
  makeText("LIVE INSTALLATION STATUS",350,469,755,28,fontNormal)
  hStatus=newWnd("LISTBOX","",WS_CHILD|WS_VISIBLE|WS_VSCROLL|LBS_NOINTEGRALHEIGHT|LBS_DISABLENOSCROLL,0,350,505,730,100,hMain,0)
  call(pSendMessage,hStatus,WM_SETFONT,fontSmall,1)
  // Keep scrollbar and selected rows dark when supported by Windows.
  call(uxtheme.NewProc("SetWindowTheme"),hStatus,uintptr(unsafe.Pointer(utf("DarkMode_Explorer"))),0)
  hProgressBg=newWnd("STATIC","",WS_CHILD|WS_VISIBLE,0,350,620,730,16,hMain,0)
  hProgressFill=newWnd("STATIC","",WS_CHILD|WS_VISIBLE,0,350,620,0,16,hMain,0)
  hAction=makeText("Installation progress: 0%",350,647,730,24,fontSmall)
  actionButtons=append(actionButtons,makeButton("Install / Upgrade",350,687,205,44,IDINSTALL),makeButton("Repair",565,687,135,44,IDREPAIR),makeButton("Uninstall",710,687,150,44,IDREMOVE))
  makeButton("Close",870,687,210,44,IDCLOSE)
  logLine("Ready. Existing application settings and device files will be preserved.")
  if findInstall()!="" {logLine("Previous installation detected: Upgrade or Repair is available.")}
  return 0
 case WM_ERASEBKGND:
  // Don't expose Windows' white class background during repaints.
  solidRect(wparam,makeRect(0,0,1140,790),brushBg)
  return 1
 case WM_PAINT:
  var ps paintStruct
  dc:=call(pBeginPaint,hwnd,uintptr(unsafe.Pointer(&ps)))
  drawPanel(dc)
  call(pEndPaint,hwnd,uintptr(unsafe.Pointer(&ps)))
  return 0
 case WM_DRAWITEM:
  if lparam!=0{di:=(*drawItem)(unsafe.Pointer(lparam));if di.CtlType==4{paintButton(di);return 1}}
  return 0
 case WM_COMMAND:
  id:=int(wparam&0xffff)
  switch id {
  case IDINSTALL:begin("install")
  case IDREPAIR:begin("repair")
  case IDREMOVE: if msgBox("Confirm uninstall","Uninstall the companion app from this Windows user?\n\nFiles on your physical Pager are not affected.",MB_YESNO|MB_ICONWARNING)==IDYES{begin("remove")}
  case IDPYTHON: cmd:=hiddenCmd("rundll32.exe","url.dll,FileProtocolHandler",pythonPage);_ = cmd.Start()
  case IDCLOSE: if !busy {call(pDestroy,hMain)}else{msgBox(winTitle,"Setup is working. Finish the current operation before closing.",MB_OK|MB_ICONWARNING)}
  }
  return 0
 case WM_APP+1:
  for{select{case e:=<-events:
   if e.message!=""{logLine(e.message)}
   if e.percent>=0 {setProgress(e.percent)}
   if e.done {
    taskMu.Lock();setBusy(false);taskMu.Unlock()
    if e.err!=nil {logLine("ERROR: "+e.err.Error());msgBox(winTitle,"Setup could not finish:\n\n"+e.err.Error()+"\n\nYour previous installation was preserved where possible.",MB_OK|MB_ICONERROR)}else{
     logLine("Operation completed successfully.")
     say("The operation completed successfully.")
     if lastMode=="install" || lastMode=="repair" {if launchAfter {launchApp()};call(pDestroy,hMain)}
     if lastMode=="remove" {call(pDestroy,hMain)}
    }
   }
   default:return 0
  }}
 case WM_CTLCOLORSTATIC,WM_CTLCOLORLISTBOX:
  dc:=wparam
  call(pSetBkMode,dc,1) // TRANSPARENT; never paint system-white bands around labels
  if code==WM_CTLCOLORLISTBOX {
   call(pSetTextColor,dc,COLOR_ACCENT);call(pSetBkColor,dc,COLOR_PANEL)
   return brushPanel
  }
  if lparam==hProgressFill{return brushPurple}
  if lparam==hProgressBg{return brushPanel}
  call(pSetTextColor,dc,COLOR_TEXT);call(pSetBkColor,dc,COLOR_DARK)
  return brushBg
 case WM_CLOSE: if busy{return 0};call(pDestroy,hwnd);return 0
 case WM_DESTROY:
  if brandBitmap!=0{call(pDeleteObject,brandBitmap)}
  for _,b:=range []uintptr{brushBg,brushPanel,brushPurple,brushButton,brushOutline}{if b!=0{call(pDeleteObject,b)}}
  for _,f:=range []uintptr{fontNormal,fontTitle,fontSmall}{if f!=0{call(pDeleteObject,f)}}
  call(pPostQuit,0);return 0
 }
 return call(pDefWindow,hwnd,uintptr(code),wparam,lparam)
}
var wndProc=syscall.NewCallback(windowProc)
func runGUI(){runtime.LockOSThread();defer runtime.UnlockOSThread()
 f,err:=os.CreateTemp("","gs-pager-brand-*.bmp")
 if err==nil {brandTemp=f.Name(); _,_ =f.Write(brandArt);_ =f.Close();defer os.Remove(brandTemp)}
 fIcon,errIcon:=os.CreateTemp("","gs-pager-icon-*.ico")
 if errIcon==nil {
  iconTemp=fIcon.Name();_,_=fIcon.Write(appIcon);_=fIcon.Close();defer os.Remove(iconTemp)
  iconLoad:=user32.NewProc("LoadImageW")
  installerIconBig=call(iconLoad,0,uintptr(unsafe.Pointer(utf(iconTemp))),IMAGE_ICON,48,48,LR_LOADFROMFILE)
  installerIconSmall=call(iconLoad,0,uintptr(unsafe.Pointer(utf(iconTemp))),IMAGE_ICON,16,16,LR_LOADFROMFILE)
  defer func(){if installerIconBig!=0{call(user32.NewProc("DestroyIcon"),installerIconBig)};if installerIconSmall!=0{call(user32.NewProc("DestroyIcon"),installerIconSmall)}}()
 }
 cls:=utf("GSPagerCompanionSetup623")
 classBrush=call(pCreateBrush,COLOR_DARK)
 wc:=wndClass{Size:uint32(unsafe.Sizeof(wndClass{})),WndProc:wndProc,Instance:call(pGetModule,0),Cursor:call(pLoadCursor,0,32512),Background:classBrush,ClassName:cls,Icon:installerIconBig,IconSmall:installerIconSmall}
 if call(pRegisterClass,uintptr(unsafe.Pointer(&wc)))==0 {msgBox(winTitle,"Could not initialize setup window.",MB_OK|MB_ICONERROR);return}
 hMain=newWnd("GSPagerCompanionSetup623",winTitle,WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_VISIBLE,0,115,80,1140,780,0,0)
 if hMain==0{msgBox(winTitle,"Could not open installer window.",MB_OK|MB_ICONERROR);return}
 var m msg
 for {if int32(call(pGetMessage,uintptr(unsafe.Pointer(&m)),0,0,0))<=0{break};call(pTranslate,uintptr(unsafe.Pointer(&m)));call(pDispatch,uintptr(unsafe.Pointer(&m)))}
}

func localAppData()string {v:=os.Getenv("LOCALAPPDATA");if v=="" {v=filepath.Join(os.Getenv("USERPROFILE"),"AppData","Local")};return v}
func targetDir()string{return filepath.Join(localAppData(),"Programs",appName)}
func logsDir()string{return filepath.Join(localAppData(),"GhostStrats","Pager Installer Logs")}
func logFile()string{return filepath.Join(logsDir(),"install-v"+version+".log")}
func writeLog(s string){os.MkdirAll(logsDir(),0700);f,err:=os.OpenFile(logFile(),os.O_CREATE|os.O_APPEND|os.O_WRONLY,0600);if err==nil{defer f.Close();fmt.Fprintf(f,"[%s] %s\n",time.Now().Format(time.RFC3339),s)}}
func reporter(f func(string,int))func(string,int){return func(s string,n int){writeLog(s);f(s,n)}}
func hiddenCmd(name string, args ...string)*exec.Cmd{cmd:=exec.Command(name,args...);cmd.SysProcAttr=&syscall.SysProcAttr{HideWindow:true,CreationFlags:0x08000000};return cmd}
func execOut(timeout time.Duration, cmd *exec.Cmd)(string,error){done:=make(chan error,1);var buf bytes.Buffer;cmd.Stdout=&buf;cmd.Stderr=&buf;err:=cmd.Start();if err!=nil{return "",err};go func(){done<-cmd.Wait()}();select{case err=<-done: return buf.String(),err;case <-time.After(timeout): _=cmd.Process.Kill();<-done;return buf.String(),errors.New("command timed out")}}
func exists(path string)bool{_,err:=os.Stat(path);return err==nil}
func managed(path string)bool{if path==""{return false};st,err:=os.Stat(path);if err!=nil||!st.IsDir(){return false};for _,f:=range []string{".gs-pager-managed.json",fileBase+".py","GS_WiFi_Pager_Companion_App.py","GS_WiFi_Pager_Companion_App.exe","GS_WiFi_Pineapple_Pager_GUI.py","GS_Pager.ico","pager_backend.py"}{if exists(filepath.Join(path,f)){return true}};return false}
func knownDirs()[]string{dirs:=[]string{targetDir()};for _,n:=range legacyFolders {if strings.EqualFold(n,appName){continue};dirs=append(dirs,filepath.Join(localAppData(),"Programs",n))};return dirs}
func findInstall()string{for _,path:=range knownDirs(){if managed(path){return path}};return ""}
func presentPython(path string)bool{if !exists(path){return false};out,err:=execOut(12*time.Second,hiddenCmd(path,"-c","import tkinter, pip, sys; assert (3,9) <= sys.version_info[:2] <= (3,13); print(sys.version_info[0], sys.version_info[1])"));if err!=nil{return false};return strings.Contains(out,"3 ")}
func findPython()string{candidates:=[]string{filepath.Join(localAppData(),"GhostStrats","Python312","python.exe")};for _,candidate:=range candidates{if presentPython(candidate){return candidate}}
 for _,name:=range []string{"py.exe","python.exe"}{p,err:=exec.LookPath(name);if err==nil&&presentPython(p){return p}}
 for _,v:=range []string{"Python312","Python311","Python310","Python39","Python313"}{p:=filepath.Join(localAppData(),"Programs","Python",v,"python.exe");if presentPython(p){return p}}
 return ""
}
func preparePython(stage string,report func(string,int))(string,error){p:=findPython();if p!=""{report("Compatible Python detected.",12);return p,nil}
 report("Downloading a private Python 3.12 runtime from python.org...",8)
 download:=filepath.Join(stage,"python-3.12.10-amd64.exe")
 client:=&http.Client{Timeout:7*time.Minute}
 resp,err:=client.Get(pythonURL);if err!=nil{return "",fmt.Errorf("could not download Python; use the Python download button and retry: %w",err)};defer resp.Body.Close();if resp.StatusCode!=200{return "",fmt.Errorf("Python download returned HTTP %d",resp.StatusCode)}
 f,err:=os.Create(download);if err!=nil{return "",err};_,err=io.Copy(f,io.LimitReader(resp.Body,100<<20));err2:=f.Close();if err!=nil{return "",err};if err2!=nil{return "",err2}
 b,err:=os.ReadFile(download);if err!=nil||len(b)<1000000||b[0]!='M'||b[1]!='Z'{return "",errors.New("Python download did not contain a valid Windows installer")}
 installRoot:=filepath.Join(localAppData(),"GhostStrats","Python312")
 report("Installing a private Python runtime. This may take a few minutes...",15)
 out,err:=execOut(8*time.Minute,hiddenCmd(download,"/quiet","InstallAllUsers=0","TargetDir="+installRoot,"Include_pip=1","Include_tcltk=1","PrependPath=0","Include_test=0","AssociateFiles=0","Shortcuts=0"))
 if err!=nil {return "",fmt.Errorf("Python installation failed: %v (%s)",err,last(out,250))}
 p=filepath.Join(installRoot,"python.exe");if !presentPython(p){return "",errors.New("Python installation completed without Tkinter/pip. Please install Python from the official download page and retry")}
 _ = os.Remove(download)
 os.WriteFile(filepath.Join(installRoot,".gs-pager-private-runtime"),[]byte(version),0600)
 return p,nil
}
func last(s string,n int)string{if len(s)>n{return s[len(s)-n:]};return s}
func unpackZip(dst string)error{
 zr,err:=zip.NewReader(bytes.NewReader(payload),int64(len(payload)));if err!=nil{return err}
 for _,f:=range zr.File {
  name:=filepath.ToSlash(f.Name); parts:=strings.SplitN(name,"/",2);if len(parts)<2{continue};rel:=filepath.FromSlash(parts[1]);if rel==""{continue}
  full:=filepath.Join(dst,rel);back,err:=filepath.Rel(dst,full);if err!=nil||back==".."||strings.HasPrefix(back,".."+string(filepath.Separator)){return errors.New("invalid archive path")}
  if f.FileInfo().IsDir(){if err=os.MkdirAll(full,0755);err!=nil{return err};continue}
  if err=os.MkdirAll(filepath.Dir(full),0755);err!=nil{return err}
  r,err:=f.Open();if err!=nil{return err};w,err:=os.Create(full);if err!=nil{r.Close();return err}
  _,copyErr:=io.Copy(w,io.LimitReader(r,100<<20));close1:=w.Close();close2:=r.Close()
  if copyErr!=nil{return copyErr};if close1!=nil{return close1};if close2!=nil{return close2}
 }
 return nil
}
type manifest struct{ AppName string `json:"app_name"`;Version string `json:"version"`;Files []string `json:"files"` }
func buildManifest(dst string)error{var entries []string;err:=filepath.Walk(dst,func(path string,info os.FileInfo,err error)error{if err!=nil{return err};if info.IsDir(){return nil};rel,e:=filepath.Rel(dst,path);if e==nil{entries=append(entries,rel)};return e});if err!=nil{return err}
 b,err:=json.MarshalIndent(manifest{AppName:appName,Version:version,Files:entries},"","  ");if err!=nil{return err};return os.WriteFile(filepath.Join(dst,".gs-pager-managed.json"),b,0600)}
func install(stage string,repair bool,report func(string,int))error{
 report=reporter(report)
 target:=targetDir()
 if exists(target)&&!managed(target){return errors.New("destination contains unrelated files. Setup will not replace or delete them. Please choose a different location or move that folder first: "+target)}
 prior:=findInstall()
 if repair&&prior==""{return errors.New("no existing installation found; select Install / Upgrade")}
 if prior!="" {report("Existing installation recognized. User preferences will be preserved.",7)}
 if err:=os.MkdirAll(stage,0755);err!=nil{return err}
 if err:=unpackZip(stage);err!=nil{return err}
 py,err:=preparePython(stage,report);if err!=nil{return err}
 report("Building isolated application environment...",32)
 runtimeDir:=filepath.Join(stage,"runtime")
 out,err:=execOut(4*time.Minute,hiddenCmd(py,"-m","venv",runtimeDir));if err!=nil{return fmt.Errorf("creating app environment failed: %v (%s)",err,last(out,400))}
 python:=filepath.Join(runtimeDir,"Scripts","python.exe")
 if !exists(python){return errors.New("Python environment is missing its interpreter")}
 report("Installing dependencies...",47)
 out,err=execOut(9*time.Minute,hiddenCmd(python,"-m","pip","install","--disable-pip-version-check","--no-input","-r",filepath.Join(stage,"requirements.txt")))
 if err!=nil{return fmt.Errorf("installing app dependencies failed: %v (%s)",err,last(out,600))}
 report("Validating the installed Python packages...",72)
 out,err=execOut(25*time.Second,hiddenCmd(python,"-c","import tkinter, paramiko, tkinterdnd2; import webview; print('OK')"));if err!=nil{return fmt.Errorf("Python validation failed: %v (%s)",err,last(out,250))}
 script:=filepath.Join(stage,fileBase+".py");if !exists(script)||!exists(filepath.Join(stage,fileBase+".exe")){return errors.New("application files were missing from setup package")}
 if err:=buildManifest(stage);err!=nil{return err}
 // Prepare own uninstaller before touching old installation. It will run from the new directory.
 self,err:=os.Executable();if err!=nil{return err}
 if err=copyFile(self,filepath.Join(stage,"Uninstall.exe"));err!=nil{return err}
 report("Safely replacing application files...",83)
 os.MkdirAll(filepath.Dir(target),0755)
 stamp:=time.Now().Format("20060102-150405")
 backup:=target+".__previous_"+stamp
 var oldPaths []string
 // If previous version uses another directory, keep it untouched until commit.
 if exists(target){if err=os.Rename(target,backup);err!=nil{return fmt.Errorf("could not backup current installation; close the app and retry: %w",err)};oldPaths=append(oldPaths,backup)}
 if err=os.Rename(stage,target);err!=nil{if len(oldPaths)>0{os.Rename(backup,target)};return fmt.Errorf("could not commit updated application; original was restored: %w",err)}
 report("Creating Windows shortcuts and app registration...",91)
 // Nonfatal: if the user has a redirected Desktop or locked-down registry, app remains valid.
 if e:=registerApp(target);e!=nil{
  _=regDelete(appRegistryKey());failed:=target+".__failed_"+stamp
  if e2:=os.Rename(target,failed);e2==nil{_ = removeManaged(failed)}
  if len(oldPaths)>0{_ = os.Rename(backup,target)}
  return fmt.Errorf("Windows app registration failed; previous installation restored: %w",e)
 }
 if e:=createShortcuts(target);e!=nil{writeLog("WARNING: shortcuts: "+e.Error())}
 cleanupLegacy(target)
 // Backups are only retired after the new program is present and registered.
 for _,old:=range oldPaths{if managed(old){removeManaged(old)}else{writeLog("Retained prior folder: "+old)}}
 report("Installation completed. Your Pager files were not changed.",100)
 return nil
}
func copyFile(src,dst string)error{r,e:=os.Open(src);if e!=nil{return e};defer r.Close();w,e:=os.Create(dst);if e!=nil{return e};_,e=io.Copy(w,r);e2:=w.Close();if e!=nil{return e};return e2}
func appRegistryKey()string{return `HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\GSWiFIPineapplePagerCompanionApp`}
func regAdd(key,field,value string)error{_,err:=execOut(12*time.Second,hiddenCmd("reg.exe","add",key,"/v",field,"/t","REG_SZ","/d",value,"/f"));return err}
func regDelete(key string)error{_,err:=execOut(12*time.Second,hiddenCmd("reg.exe","delete",key,"/f"));return err}
func registerApp(target string)error{
 k:=appRegistryKey();fields:=map[string]string{"DisplayName":appName,"DisplayVersion":version,"Publisher":"GhostStrats Community (unaffiliated with Hak5)","InstallLocation":target,"UninstallString":`"`+filepath.Join(target,"Uninstall.exe")+`" --uninstall`,"DisplayIcon":`"`+filepath.Join(target,"GS_Pager.ico")+`",0`,"NoModify":"1"}
 for k1,v:=range fields {if err:=regAdd(k,k1,v);err!=nil{return fmt.Errorf("%s: %w",k1,err)}}
 return nil
}
func psLiteral(s string)string{return "'"+strings.ReplaceAll(s,"'","''")+"'"}
func knownFolder(csidl uintptr, fallback string)string{
 var buf [260]uint16
 proc:=syscall.NewLazyDLL("shell32.dll").NewProc("SHGetFolderPathW")
 r,_,_:=proc.Call(0,csidl,0,0,uintptr(unsafe.Pointer(&buf[0])))
 if r==0 && buf[0]!=0{return syscall.UTF16ToString(buf[:])}
 return fallback
}
func desktopRoot()string{return knownFolder(0x10,filepath.Join(os.Getenv("USERPROFILE"),"Desktop"))}
func linkRoot()string{fallback:=filepath.Join(os.Getenv("APPDATA"),"Microsoft","Windows","Start Menu","Programs");return filepath.Join(knownFolder(0x02,fallback),"GhostStrats")}
func createShortcuts(target string)error{
 shortcut:=filepath.Join(linkRoot(),appName+".lnk");desktop:=filepath.Join(desktopRoot(),appName+".lnk")
 script:=fmt.Sprintf(`$ErrorActionPreference='Stop';$w=New-Object -ComObject WScript.Shell;foreach($path in @(%s,%s)){$dir=[IO.Path]::GetDirectoryName($path);[IO.Directory]::CreateDirectory($dir)|Out-Null;$s=$w.CreateShortcut($path);$s.TargetPath=%s;$s.WorkingDirectory=%s;$s.IconLocation=%s;$s.Save()};$s=$w.CreateShortcut(%s);$s.TargetPath=%s;$s.Arguments='--uninstall';$s.WorkingDirectory=%s;$s.Save()`,psLiteral(shortcut),psLiteral(desktop),psLiteral(filepath.Join(target,fileBase+".exe")),psLiteral(target),psLiteral(filepath.Join(target,"GS_Pager.ico")),psLiteral(filepath.Join(linkRoot(),"Uninstall "+appName+".lnk")),psLiteral(filepath.Join(target,"Uninstall.exe")),psLiteral(target))
 _,err:=execOut(25*time.Second,hiddenCmd("powershell.exe","-NoLogo","-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-Command",script));return err
}
func cleanupLegacy(target string){
 // Remove only exact obsolete shortcuts / registry registration, never device files.
 for _,n:=range legacyTitles{if strings.EqualFold(n,appName){continue};_ = os.Remove(filepath.Join(linkRoot(),n+".lnk"));_ = os.Remove(filepath.Join(desktopRoot(),n+".lnk"))}
 for _,key:=range []string{"GSWiFiPagerCompanionApp","GSWiFiPineapplePagerGUI","GPSWifiPagetCompanionApp","GS WiFi Pager Companion App","GPS Wifi Paget Companion App"}{_ = regDelete(`HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\`+key)}
 for _,path:=range knownDirs(){if !strings.EqualFold(filepath.Clean(path),filepath.Clean(target))&&managed(path){removeManaged(path)}}
}
// managedFilePath confines every manifest entry to this one installation directory.
// Never trust an absolute path or ../ entry from a damaged manifest.
func managedFilePath(root, rel string)(string,bool){
 if rel==""||filepath.IsAbs(rel){return "",false}
 cleaned:=filepath.Clean(rel)
 if cleaned=="."||cleaned==".."||strings.HasPrefix(cleaned,".."+string(os.PathSeparator)){return "",false}
 full:=filepath.Join(root,cleaned)
 back,err:=filepath.Rel(root,full)
 if err!=nil||back==".."||strings.HasPrefix(back,".."+string(os.PathSeparator)){return "",false}
 return full,true
}
func preservedFilesRoot()string{return filepath.Join(localAppData(),"GhostStrats","Preserved Pager App Files")}
func removeManaged(path string)error {
 // Remove only verified app installations. Do not delete arbitrary directories.
 if !managed(path){return errors.New("directory isn't a recognized GS Pager installation: "+path)}
 info,err:=os.Lstat(path)
 if err!=nil{return err}
 if !info.IsDir(){return errors.New("the application installation path is not a directory")}
 manifestFile:=filepath.Join(path,".gs-pager-managed.json")
 if contents,err:=os.ReadFile(manifestFile);err==nil{
  var m manifest
  if json.Unmarshal(contents,&m)==nil{
   for _,relative:=range m.Files{
    full,ok:=managedFilePath(path,relative)
    if !ok{return errors.New("invalid entry in installed-file manifest: "+relative)}
    if err:=os.Remove(full);err!=nil&&!os.IsNotExist(err){return fmt.Errorf("could not remove installed file %s: %w",relative,err)}
   }
  }
 }
 // Older versions have no complete manifest. Use the fixed allow-list too.
 files:=[]string{fileBase+".exe",fileBase+".py","GS_WiFi_Pager_Companion_App.exe","GS_WiFi_Pager_Companion_App.py","GS_WiFi_Pineapple_Pager_GUI.exe","GS_WiFi_Pineapple_Pager_GUI.py","Uninstall.exe","pager_backend.py","GS_Pager.ico","GS_Pager_Icon.png","GS_Pager_Transparent.png","GS_logo_small.png","ghoststrats_glitch_banner.png","gs_yellow_header.png","gs_yellow_hero.png","gs_yellow_original.jpg","gs_yellow_wallpaper.png","requirements.txt","README.md","README_INSTALL.md",".gs-pager-managed.json"}
 for _,f:=range files{
  if err:=os.Remove(filepath.Join(path,f));err!=nil&&!os.IsNotExist(err){return fmt.Errorf("could not remove %s: %w",f,err)}
 }
 for _,pattern:=range []string{"RELEASE_NOTES_V*.md","RELEASE_NOTES.md"}{
  matches,_:=filepath.Glob(filepath.Join(path,pattern))
  for _,item:=range matches{if err:=os.Remove(item);err!=nil&&!os.IsNotExist(err){return err}}
 }
 for _,folder:=range []string{"runtime","__pycache__"}{
  if err:=os.RemoveAll(filepath.Join(path,folder));err!=nil{return fmt.Errorf("could not remove %s: %w",folder,err)}
 }
 // Remove empty subfolders (including old Python cache directories).
 var dirs []string
 if err:=filepath.Walk(path,func(at string,info os.FileInfo,err error)error{
  if err!=nil{return err}
  if info.IsDir(){dirs=append(dirs,at)}
  return nil
 });err!=nil{return err}
 for i:=len(dirs)-1;i>=0;i--{_ = os.Remove(dirs[i])}
 if !exists(path){return nil}
 // Never delete unknown files from the installation folder. Moving the
 // leftovers out of the installation path prevents reinstall collisions.
 if err:=os.MkdirAll(preservedFilesRoot(),0700);err!=nil{return err}
 destination:=filepath.Join(preservedFilesRoot(),filepath.Base(path)+"-"+time.Now().Format("20060102-150405.000000000"))
 if err:=os.Rename(path,destination);err!=nil{return fmt.Errorf("could not relocate leftover files for safe reinstall: %w",err)}
 writeLog("Preserved unrecognized files in "+destination)
 return nil
}
func removeInstall(report func(string,int))error{
 report=reporter(report)
 found:=false
 var failed []string
 // All previous recognized app-name directories, including interrupted upgrade
 // backups, must be inspected; no files on the physical Pager are involved.
 dirs:=append([]string{},knownDirs()...)
 for _,base:=range knownDirs(){
  for _,suffix:=range []string{".__previous_*",".__failed_*"}{
   matches,_:=filepath.Glob(base+suffix)
   dirs=append(dirs,matches...)
  }
 }
 visited:=map[string]bool{}
 for _,path:=range dirs{
  k:=strings.ToLower(filepath.Clean(path))
  if visited[k]{continue};visited[k]=true
  if managed(path){
   found=true
   report("Removing application files from "+path,40)
   if err:=removeManaged(path);err!=nil{failed=append(failed,path+": "+err.Error())}
  }
 }
 if len(failed)>0{return errors.New("some installed files could not be removed. Close the app and retry:\n"+strings.Join(failed,"\n"))}
 report("Removing shortcuts and Windows registration...",82)
 for _,n:=range append(append([]string{},legacyTitles...),appName){
  _=os.Remove(filepath.Join(linkRoot(),n+".lnk"))
  _=os.Remove(filepath.Join(linkRoot(),"Uninstall "+n+".lnk"))
  _=os.Remove(filepath.Join(desktopRoot(),n+".lnk"))
 }
 for _,key:=range []string{"GSWiFIPineapplePagerCompanionApp","GSWiFiPagerCompanionApp","GSWiFiPineapplePagerGUI","GPSWifiPagetCompanionApp","GS WiFi Pager Companion App","GPS Wifi Paget Companion App"}{
  _=regDelete(`HKCU\Software\Microsoft\Windows\CurrentVersion\Uninstall\`+key)
 }
 // Staging/logs belong only to this installer, not to the user's Pager.
 // These paths are under the app's own LocalAppData/GhostStrats area.
 _=os.RemoveAll(filepath.Join(localAppData(),"GhostStrats","Pager Setup Staging"))
 _=os.Remove(linkRoot())          // remove only when empty; keep unrelated shortcuts
 _=os.Remove(filepath.Join(localAppData(),"GhostStrats")) // leave private Python and user data
 if !found{report("No installed program files remained. Removed any old shortcuts and entries.",100)
  _=os.RemoveAll(logsDir());return nil}
 report("Uninstall complete. Program folders removed; preferences and Pager contents preserved.",100)
 _=os.RemoveAll(logsDir())
 return nil
}
var lastMode string;var launchAfter=true
func perform(mode string,emit func(string,int))error{
 lastMode=mode
 if mode=="remove"{return removeInstall(emit)}
 base:=filepath.Join(localAppData(),"GhostStrats","Pager Setup Staging")
 if err:=os.MkdirAll(base,0755);err!=nil{return err}
 stage,err:=os.MkdirTemp(base,"gs-v12-");if err!=nil{return err}
 defer os.RemoveAll(stage)
 return install(stage,mode=="repair",emit)
}
func launchApp(){q:=filepath.Join(targetDir(),fileBase+".exe");if exists(q){_ = hiddenCmd(q).Start()}}
func doUninstallWorker(){if msgBox("Uninstall "+appName,"Remove the application from this computer?\n\nAll application installation folders will be removed. Any unrelated files found inside them will be safely preserved elsewhere. Your settings and files on the Pager will be preserved.",MB_YESNO|MB_ICONWARNING)!=IDYES{return}
 err:=removeInstall(func(s string,p int){writeLog(s)});if err!=nil{msgBox(winTitle,"Uninstall could not finish: "+err.Error(),MB_OK|MB_ICONERROR)}else{say("The application was uninstalled. Your Pager files were not changed.")}
}
func main(){
 if len(os.Args)>1&&os.Args[1]=="--uninstall"{
  // Run from a temporary copy so the installed Uninstall.exe can be removed.
  self,err:=os.Executable();if err!=nil{return};name:=filepath.Join(os.TempDir(),fmt.Sprintf("gs-pager-uninstall-%d.exe",time.Now().UnixNano()));if copyFile(self,name)==nil{p:=hiddenCmd(name,"--uninstall-worker");if p.Start()==nil{return}}
  doUninstallWorker();return
 }
 if len(os.Args)>1&&os.Args[1]=="--uninstall-worker"{doUninstallWorker();return}
 if len(os.Args)>1&&os.Args[1]=="--verify-package"{if len(payload)>1000{os.Exit(0)};os.Exit(1)}
 runGUI()
}
