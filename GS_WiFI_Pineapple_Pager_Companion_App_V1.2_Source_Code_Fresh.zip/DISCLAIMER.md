# Disclaimer

GS WiFI Pineapple Pager Companion App — Version 1.2 Release — DISCLAIMER
================================================

NOT AN OFFICIAL HAK5 PRODUCT
This is a free, independent GhostStrats community-built application.
It was created to make it easier for people to connect to and manage
their Hak5 WiFi Pineapple Pager. It is not made by Hak5 and is NOT
affiliated with, endorsed by, sponsored by, or supported by Hak5.

WHY THIS EXISTS
I wanted a simpler, more approachable, Pager-specific alternative to
my WinSCP file-management workflow. WinSCP development began in March
2000 (with first releases later in 2000), over 26 years ago. WinSCP
is still maintained and this is not a claim that it is insecure.

USE AT YOUR OWN RISK
This software is provided AS-IS, with no warranties of any kind.
It can connect over SSH/SFTP, transfer, replace, and delete files,
open a shell, and initiate official firmware installation. Mistakes,
unsupported files, untrusted payloads, interrupted firmware updates,
or deleting/replacing folders may cause data loss or device issues.

Before changing firmware or replacing files, back up important data.
Use firmware from Hak5's official Pager download page only. Keep the
Pager powered during updates, and wait for it to finish rebooting.
Review third-party payloads/themes before using them. Run security
payloads only on devices and networks you own or are authorized to
assess; follow applicable laws and Hak5's documentation.

The application installer/uninstaller acts on Windows program files;
it is not intended to remove files from your physical Pager. The
installer is unsigned, and a Windows security prompt may appear.

TRADEMARKS AND SUPPORT
Hak5, WiFi Pineapple, DuckyScript and related marks belong to their
respective owners. WinSCP belongs to its respective project owners.
Neither Hak5 nor WinSCP is responsible for this community application.
Questions about THIS application should be directed to its community
maintainer, not to Hak5 support.

Project version: 1.2 Release
