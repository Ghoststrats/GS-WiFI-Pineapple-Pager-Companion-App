# GS WiFI Pineapple Pager Companion App — Version 1.2 Release

## File Manager: one-way drag-and-drop reliability fix

- **Upload from Windows:** Drag local files or folders into the File Manager's clearly marked upload area, or use **Upload Files / Upload Folder**.
- **No outgoing drag:** The Pager file list cannot initiate a file drag toward Windows Explorer. Its mouse-drag behavior and drag-and-drop registrations are explicitly disabled to prevent the reported crash.
- **Download to Your Computer:** Click a Pager file or folder once, then click the download button and choose where to save it. Full folder trees, including nested files and subfolders, are supported.
- **Previous installs:** Close the application before upgrading; open the newly installed Start Menu shortcut afterward instead of an old pinned shortcut.

All other branding, themes, icons, firmware tools, Virtual Pager, SSH terminal, and installer/uninstall behavior remain unchanged from the existing release.

**Disclaimer:** This is an independent community project and not an official Hak5 product, nor affiliated with or endorsed by Hak5.

**Testing:** Automated application and transfer tests plus desktop GUI startup. Live Windows Explorer drag-and-drop and the complete install/upgrade/uninstall flows still require testing on a Windows PC.
