# Release notes — v6.2.3 (release candidate)

- Darkened Windows installer styling with GhostStrats purple Pager artwork.
- Retained the validated v6.2.0 application baseline and its features.
- Added install, upgrade, repair, and uninstall handling, with Python setup assistance.
- Prepared a separate easy-install ZIP and source-review ZIP for GitHub.
- No source or feature changes were made solely to prepare these release archives.

The installer is unsigned, and complete Windows hardware/upgrade/uninstall testing is still recommended before calling the build stable.

**Independent community project. Not an official Hak5 product, and not affiliated with Hak5.**
