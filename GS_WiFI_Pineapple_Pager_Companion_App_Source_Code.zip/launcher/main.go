package main
import (
 "unsafe"; "os"; "os/exec"; "path/filepath"; "strings"; "syscall"; "fmt"
)
const appTitle = "GS WiFI Pineapple Pager Companion App"
func message(s string){ u:=syscall.NewLazyDLL("user32.dll");p:=u.NewProc("MessageBoxW");t,_:=syscall.UTF16PtrFromString(appTitle);v,_:=syscall.UTF16PtrFromString(s);p.Call(0,uintptr(unsafePtr(v)),uintptr(unsafePtr(t)),0x10)}
// syscall.UTF16PtrFromString pointers survive synchronously across Win32 calls.
func unsafePtr(p *uint16) unsafe.Pointer {return unsafe.Pointer(p)}
func main(){
 exe,err:=os.Executable(); if err!=nil {message("Could not locate application folder: "+err.Error());return}
 base:=filepath.Dir(exe); script:=filepath.Join(base,"GS_WiFI_Pineapple_Pager_Companion_App.py")
 interp:=filepath.Join(base,"runtime","Scripts","pythonw.exe")
 if _,err=os.Stat(interp);err!=nil { interp=filepath.Join(base,"runtime","Scripts","python.exe") }
 if _,err=os.Stat(interp);err!=nil {message("Application Python environment is missing. Re-run Setup and choose Repair.\n"+err.Error());return}
 cmd:=exec.Command(interp,script);cmd.Dir=base;cmd.SysProcAttr=&syscall.SysProcAttr{HideWindow:true,CreationFlags:0x08000000}
 b,err:=cmd.CombinedOutput();if err!=nil {
  logdir:=filepath.Join(os.Getenv("LOCALAPPDATA"),"GhostStrats","Pager Installer Logs");os.MkdirAll(logdir,0700)
  logpath:=filepath.Join(logdir,"app-startup.log");os.WriteFile(logpath,[]byte(fmt.Sprintf("%v\n%s",err,b)),0600)
  detail:=strings.TrimSpace(string(b));if len(detail)>800 {detail=detail[len(detail)-800:]}
  message("Could not open the application. Try Repair in Setup.\n\n"+detail+"\n\nDetails: "+logpath)
 }
}
