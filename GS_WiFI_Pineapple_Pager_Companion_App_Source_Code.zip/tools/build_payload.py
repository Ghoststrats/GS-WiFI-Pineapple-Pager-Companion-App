"""Build installer/payload.zip from the app directory. Run from repository root."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
name = "GS_WiFI_Pineapple_Pager_Companion_App"
app = root / "app" / name
exe = app / (name + ".exe")
if not exe.is_file():
    raise SystemExit("Build the launcher EXE first; see BUILD_WINDOWS.md")
out = root / "installer" / "payload.zip"
allowed_extensions = {".py", ".txt", ".md", ".png", ".jpg", ".jpeg", ".ico", ".exe"}
with ZipFile(out, "w", compression=ZIP_DEFLATED, compresslevel=8) as archive:
    for path in sorted(app.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in allowed_extensions:
            continue
        if any(x in ("__pycache__", ".venv", "venv") for x in path.relative_to(app).parts):
            continue
        archive.write(path, arcname=f"{name}/{path.relative_to(app).as_posix()}")
print("Created", out)
