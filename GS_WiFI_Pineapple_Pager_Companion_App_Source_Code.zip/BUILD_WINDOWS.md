# Build from source (Windows)

**Project:** GS WiFI Pineapple Pager Companion App v6.2.3 (release candidate)

This is an independent community project, **not an official Hak5 product**.

## Source layout

- `app/GS_WiFI_Pineapple_Pager_Companion_App/`: Python GUI, SSH/SFTP backend, artwork/assets, requirements, and version history.
- `launcher/main.go`: Windows GUI launcher.
- `installer/main.go`: native Windows setup application.
- `installer/brand.bmp` and `installer/app_icon.ico`: installer assets.
- `tools/build_payload.py`: recreates the installer-embedded `installer/payload.zip` from application files.
- `qa_tests.py`: application tests.

**The source archive intentionally excludes compiled EXEs and the generated embedded `installer/payload.zip`.** You can regenerate them from the source with the steps below. The easy-install ZIP contains the already-built Windows installer.

## Prerequisites

- Windows 10 or 11 (64-bit), Python 3.9+ (with standard library), and Go 1.23+.
- Internet access may be needed to obtain Go, Python, and the application's Python requirements.

## Rebuild the native Windows installer

Run these commands in PowerShell from the extracted source archive root:

```powershell
# 1. Build the Windows GUI launcher.
go build -trimpath -ldflags="-H windowsgui -s -w" -o "app/GS_WiFI_Pineapple_Pager_Companion_App/GS_WiFI_Pineapple_Pager_Companion_App.exe" "launcher/main.go"

# 2. Assemble the application files for embedding.
py -3 tools/build_payload.py

# 3. Compile the native installer.
cd installer
go build -trimpath -ldflags="-H windowsgui -s -w" -o "../GS_WiFI_Pineapple_Pager_Companion_App_Setup_V6.2.3_RC.exe" main.go
cd ..
```

`installer/main.go` uses Go's `//go:embed` to include `payload.zip`, `brand.bmp`, and `app_icon.ico`, so build payload.zip **before** building the installer.

## Tests

```powershell
py -3 qa_tests.py -v
```

Test the install, upgrade, repair, and uninstall flows on clean Windows systems and against actual hardware before distributing a stable release. Test the signing and flashing workflow only with official firmware and a test device.

**Distribution and licensing:** Source is provided for review. No license grant is implied; there is no LICENSE file yet. Obtain permission before distributing modified builds or reusing branded artwork.
