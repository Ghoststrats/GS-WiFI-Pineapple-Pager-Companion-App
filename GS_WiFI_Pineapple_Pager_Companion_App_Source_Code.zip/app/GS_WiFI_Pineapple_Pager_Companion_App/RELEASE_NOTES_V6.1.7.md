# GS WiFI Pineapple Pager Companion App V6.1.7 — Installer stability update

- Native setup screen clearly explains Python 3.9–3.13 / Tkinter requirements and includes a direct **Download Python** button linking to the official python.org Windows downloads page.
- If no compatible Python is found, Setup continues to offer an automatic private Python 3.12 installation from python.org, requiring internet access; certificate signature is checked.
- Native Windows progress indicator uses a purple fill rather than the default green.
- Reworked setup layout for readable help text and installation status.
- Python runtime health checks and unique temporary download paths; friendlier errors.
- Fixed PowerShell shortcut generation for Windows user paths containing non-ASCII characters.
- Improved upgrade rollback to retain previous shortcut and uninstall registration where possible.
- Preserved existing device manager features and other themes.

**Note:** The Windows installer and uninstall actions require validation on a real Windows system; source-level compilation is not equivalent to a full end-to-end installer test.
