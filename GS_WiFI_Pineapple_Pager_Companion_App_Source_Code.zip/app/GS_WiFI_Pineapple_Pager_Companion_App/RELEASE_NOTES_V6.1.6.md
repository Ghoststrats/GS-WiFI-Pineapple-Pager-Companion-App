# GS WiFI Pineapple Pager Companion App — 6.1.6

- Corrected the product name everywhere in the GUI, Virtual Pager, setup, shortcuts, and Windows installed-app registration.
- Migrates prior installations under “GPS Wifi Paget Companion App” and the original “GS WiFI Pineapple Pager Companion App” name.
- Preserves application features, purple Pager logo, and all three themes.
- Keeps Python setup, safe upgrade/repair, and managed uninstall.
- Community project, not affiliated with Hak5.
