GS WiFI Pineapple Pager Companion App — v6.2.3 Release Candidate
================================================================

UNOFFICIAL COMMUNITY PROJECT
This is NOT an official Hak5 product and is not affiliated with,
sponsored by, or endorsed by Hak5. I built it to make connecting to and
managing the WiFi Pineapple Pager easier for the community.

WHY I BUILT IT
I wanted something more beginner-friendly and Pager-focused than my
usual WinSCP workflow. WinSCP's development began in March 2000, more
than 26 years ago, and its first public versions were released later
in 2000. WinSCP is still maintained; I simply wanted another option.

EASY WINDOWS INSTALLATION
1. Extract the entire ZIP (right-click > Extract All).
2. Read this README and the DISCLAIMER.txt file.
3. Double-click GS_WiFI_Pineapple_Pager_Companion_App_Setup_V6.2.3_RC.exe.
4. Choose Install / Upgrade (or Repair if you need to fix an install).
5. Let the setup finish. If Python/dependencies are missing, the
   installer will attempt to set them up. Internet may be required.
   If automatic Python installation fails, use the official Python
   download link in the setup window.
6. Connect your Pager using a USB-C DATA cable, launch the app from
   the Desktop/Start Menu, and log in with your own device credentials.
   The typical USB network address is 172.16.52.1.

WHAT YOU CAN DO
- Browse, drag and drop, upload, download and open files.
- Replace or delete files/folders with confirmation.
- Use the guided firmware update screen for official signed firmware.
- Open Virtual Pager and the Pager SSH terminal.
- Open Hak5's GitHub repositories to download payloads and themes.

ADDING PAYLOADS / THEMES
1. Follow the GitHub links under Payloads & Themes in the app.
2. Download files and extract ZIPs on your computer.
3. In File Manager, browse to the correct folder and drag/drop files,
   or use Upload Files / Upload Folder.
   Payloads: /root/payloads/user/ (or /mmc/root/payloads/user/),
             under the correct category.
   Themes:   /root/themes/ (or /mmc/root/themes/).
4. Follow the readme included with the payload or theme. Back up
   anything important before replacing an existing folder.

FIRMWARE
Official Pager firmware: https://downloads.hak5.org/pineapple/pager
Keep the Pager powered on during firmware updates and allow it time
for an automatic reboot. Never unplug it during installation.

UNINSTALL
Windows Settings > Apps > Installed Apps >
GS WiFI Pineapple Pager Companion App > Uninstall.
This does not erase files stored on your physical Pager.

IMPORTANT
This installer is currently unsigned. Windows may show a warning.
A final full install/upgrade/uninstall test on Windows is recommended.
This archive contains the installer plus README.txt and DISCLAIMER.txt.
