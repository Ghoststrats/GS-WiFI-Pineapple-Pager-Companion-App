# GS WiFI Pineapple Pager Companion App — Version 6.1

- Drag files or complete directory trees onto the File Manager, including nested subfolders.
- "Upload Folder" button for people who prefer using a file chooser.
- Before overwriting a remote file or folder, the app explicitly asks whether to replace, skip, or cancel.
- Staging uploads and backups mean failed uploads should not overwrite the previous item; on failed commit a rollback is attempted.
- Folder/file icons for clearer browsing.
- Delete a selected file or an entire folder (with irreversible deletion warning). Important root folders are protected.
- Payloads & Themes section includes direct Hak5 GitHub links and a step-by-step quick guide for extracting and uploading files to category-specific payload and theme folders.
- Preserves V6 terminal, firmware, preferences, and install/repair/uninstall workflow.

Caution: Folder replacement intentionally replaces the entire folder, not just changed files. Backup first. Do not remove the USB cable while files are transferring. Test against your Pager before relying on these operations.
