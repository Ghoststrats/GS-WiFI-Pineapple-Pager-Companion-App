# GS WiFI Pineapple Pager Companion App — 6.1.2

- New transparent purple Pager desktop/taskbar/Start Menu icon generated from the user-provided image. Header branding uses the same Pager image.
- Branded black-and-purple native Windows setup design.
- Installer automatically closes shortly after successful installation, optionally launching the app first.
- Installer includes the icon as a Windows executable resource, not only as a shortcut image.
- Uninstall marker compatibility corrected for V6.1 installations, and removal list updated for new artwork assets.
- Preserves V6.1 file/folder uploads, drag-and-drop, overwriting with confirmation, folder deletion, firmware progress, Virtual Pager, terminal, GitHub links, themes, and app settings.

This is a community-developed application, not affiliated with or endorsed by Hak5.
