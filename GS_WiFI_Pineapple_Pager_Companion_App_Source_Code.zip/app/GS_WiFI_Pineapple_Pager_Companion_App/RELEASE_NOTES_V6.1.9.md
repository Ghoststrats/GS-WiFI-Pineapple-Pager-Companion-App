# GS WiFI Pineapple Pager Companion App — Version 6.1.9

## Installer background-process fix

- Python detection, Python setup, pip/venv operations, registry changes, and PowerShell shortcut creation now start without creating visible Command Prompt windows.
- Installation status and errors remain in the installer UI and log.
- The installed app still opens normally as a visible GUI window.
- Version 6.1.8 file management, firmware, themes, and Pager Terminal features are unchanged.

Windows end-to-end installation and uninstall require verification on a Windows computer.
