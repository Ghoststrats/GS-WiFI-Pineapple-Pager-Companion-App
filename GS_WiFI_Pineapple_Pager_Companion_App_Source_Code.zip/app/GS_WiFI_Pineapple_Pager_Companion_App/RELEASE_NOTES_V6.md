# Version 6 — Release notes

- Back now returns to the last browsed folder; Up One Folder navigates to the parent separately.
- New Open on My Computer action downloads a temporary local copy over SFTP, confirms with the user, and opens it via the associated Windows application. Automatic execution of scripts and executables is blocked; use Download instead.
- Existing read-only Preview and separate Download remain available.
- During firmware installation and automatic reboot monitoring, a moving activity indicator replaces the static upload percentage; clear messages tell the user to be patient and keep the Pager powered until it reboots on its own.
- Setup includes preflight checks, an isolated Python environment, visible diagnostics, previous-version detection, Replace/Upgrade and Repair, and rollback of program files on upgrade failure.
- Clean uninstall via Windows Apps; saved preferences optionally preserved; real Pager data never deleted.
- Uses GhostStrats black/purple installer styling, with the seated artwork only in the installer; subtle digital glitch styling in the GhostStrats purple app theme.
- Retains virtual Pager, Pager Terminal, Hak5 GitHub theme and payload links, and Black/Gray, Yellow, and Purple themes. No theme-building tools.
- The **new custom logo PNG has not yet been uploaded**, so the icon cannot be replaced with that specific image yet.
