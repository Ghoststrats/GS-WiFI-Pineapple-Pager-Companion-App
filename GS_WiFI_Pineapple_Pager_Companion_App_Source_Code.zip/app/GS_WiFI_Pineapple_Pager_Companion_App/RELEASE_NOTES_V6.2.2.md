# GS WiFI Pineapple Pager Companion App — V6.2.2

Name-only update based on the user-verified V6.2.0 build. No changes to backend, themes, or application layout. Installer restores the branded GhostStrats design.
