# GS WiFI Pineapple Pager Companion App — v6.2.3 (Release Candidate)

## Changes from v6.2.2

- Dark native Windows installer title bar and border, with Windows-compatible fallback.
- All installer body controls and status area use consistent dark/charcoal/purple colors; system-white paint artifacts eliminated in the source.
- Custom drawn purple action button and charcoal secondary buttons; purple progress bar retained.
- Installer window now uses a fixed layout (no stretched/misaligned controls).
- Installer still supports install/upgrade, repair, uninstall, rollback, Python 3.12 assistance, and automatic close on success.
- The underlying Pager backend and visual assets are unchanged from the user-tested v6.2.0 baseline.

## Validation

Automated application tests and Windows binary packaging checks run in the build environment. Full Windows installer/upgrade/repair/uninstall and hardware testing are **required before marking this as a stable GitHub release**.

This is an independent community project; not affiliated with Hak5.
