# GS WiFI Pineapple Pager Companion App V6.1.8 — Installer Reliability Update

- Staged dependency wheel downloads before replacing the old version, reducing failed-upgrade risk when Python or package downloads fail.
- Local/offline installation of previously downloaded dependencies after the app swap.
- Added an explicit preflight test of Python virtual-environment support.
- Fixed Repair detection when the app launcher is missing.
- Rebuilt purple installer progress bar without relying on Windows visual theme colors.
- Improved status colors, readable setup typography, logging, and error recovery.
- Missing shortcut creation is reported instead of triggering a destructive rollback.
- Retains prior file manager, terminal, firmware, Virtual Pager and three app themes.

**Not yet verified on a physical Windows PC:** complete install, upgrade, uninstall, and real Pager interaction. This is a beta build.
