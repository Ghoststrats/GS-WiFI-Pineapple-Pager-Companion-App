# GS WiFI Pineapple Pager Companion App — Version 6.2.0

- Fixed a failed prior installation being misidentified as an unrelated folder. Recognizes complete and partial installs, including folders without the old marker. An unrelated folder requires permission and is backed up instead of overwritten.
- Replaced the overlapping installer log with a native per-row list and opaque text rendering.
- Reworked staging/rollback to preserve previous installation files and user-added content during errors.
- Corrected setup log version labels, separated Python environment timeouts, and kept subprocesses hidden.
- Improved uninstall by removing only managed app files, preserving unknown user files, and using a separate finalizer to remove Uninstall.exe after it exits. Offers optional removal of private Python and saved preferences; system Python and files on the Pager are never touched.
- All application features, three themes, file manager, firmware tools, and branding are preserved.

The Windows installer requires a real Windows installation/upgrade/uninstall verification.
