# GS WiFI Pineapple Pager Companion App v6.1.4

- Renamed the Windows application, Setup program, Start Menu shortcut, desktop shortcut, and installed app registration.
- Preserves the transparent purple Pager icon supplied in the previous build for the app, setup executable and pinned-shortcut icon.
- Improved mouse-wheel scrolling when hovering over page contents, including the File Manager and nested file list.
- Rebuilt uninstall to recognize older GS-managed installations safely even if version markers or registration are missing/mismatched; no arbitrary directories are deleted.
- New setup migrates compatible older installations, removes obsolete shortcuts and registry entries, and registers one uninstaller under the new application title.
- Keeps all previous firmware, file management, themes, payload GitHub resources, and Virtual Pager functions.
- Physical Windows installation and hardware integration still need testing.
