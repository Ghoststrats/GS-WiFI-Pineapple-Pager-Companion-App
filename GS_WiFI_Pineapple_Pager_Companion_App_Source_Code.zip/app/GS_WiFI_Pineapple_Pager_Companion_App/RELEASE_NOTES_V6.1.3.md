# GS WiFI Pineapple Pager Companion App — Version 6.1.3

## Yellow theme artwork

- The **Black & Yellow** Windows application theme now incorporates the user's supplied yellow-and-black Pager collage as a subtle, darkened background and a more prominent page header.
- Panels, file operations, and critical firmware warnings remain in opaque dark cards for readability.
- Includes the original artwork as `gs_yellow_original.jpg`, plus optimized `gs_yellow_wallpaper.png`, `gs_yellow_hero.png`, and `gs_yellow_header.png` assets.
- **Black & Gray remains the default** for new installations. GhostStrats Purple is unchanged.
- Theme selection remains available in Settings and is persisted between sessions.

This changes only the Windows manager application's look, not the physical Pager's installed theme. All V6.1.2 File Manager, Firmware Update, Virtual Pager, Payloads & Themes, and SSH Terminal features remain intact.
