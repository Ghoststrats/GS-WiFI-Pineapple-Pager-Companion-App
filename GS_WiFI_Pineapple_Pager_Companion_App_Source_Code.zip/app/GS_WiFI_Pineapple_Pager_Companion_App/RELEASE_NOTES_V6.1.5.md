# GS WiFI Pineapple Pager Companion App — 6.1.5

- Replaced Black & Yellow theme background with the supplied yellow/black graffiti artwork. Generated a darkened tall wallpaper, more visible content banner, and matching header for readability. Other two themes unchanged.
- Rebuilt the installer artwork with only the current project name and existing transparent purple Pager icon.
- Setup explains Python 3.9+ requirement and that it automatically installs a private Python 3.12 runtime when no supported installation exists. Internet is needed on first setup. Added human-readable recovery guidance and digital signature verification for the Python installer downloaded from python.org.
- Improved section-change performance by caching large yellow theme bitmaps, and reduced dependency-cache writes during installation.
- More accurate removal-success status in Setup; maintained existing install/repair/uninstall flows.
- QA: Python unit tests, Go cross compilation, bundled ZIP checks, UI smoke test where display environment is available. Physical Windows installer and Pager firmware transfers still require real-device testing.
