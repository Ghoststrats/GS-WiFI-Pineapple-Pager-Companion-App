import os, pathlib, tempfile, shutil, sys, stat, errno, hashlib, importlib.util, unittest, types
ROOT=pathlib.Path(__file__).parent/'app'/'GS_WiFI_Pineapple_Pager_Companion_App'
sys.path.insert(0,str(ROOT))
import pager_backend as backend
spec=importlib.util.spec_from_file_location('gs_app',ROOT/'GS_WiFI_Pineapple_Pager_Companion_App.py')
app=importlib.util.module_from_spec(spec);spec.loader.exec_module(app)
class MemSFTP:
 def __init__(self):self.fs={'/root':None};self.fail_commit=False
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def lstat(self,path):return self.stat(path)
 def stat(self,path):
  if path not in self.fs:raise FileNotFoundError(errno.ENOENT,'missing',path)
  return types.SimpleNamespace(st_mode=stat.S_IFDIR|0o755 if self.fs[path] is None else stat.S_IFREG|0o644,st_size=len(self.fs[path] or b''))
 def mkdir(self,path):
  if path in self.fs:raise FileExistsError(path)
  self.fs[path]=None
 def put(self,local,remote,callback=None,confirm=True):
  data=pathlib.Path(local).read_bytes();self.fs[remote]=data
  if callback:callback(len(data),len(data))
 def rename(self,a,b):
  if self.fail_commit and '/.gs-upload-' in a:raise IOError('simulated commit failure')
  if a not in self.fs:raise FileNotFoundError(a)
  if b in self.fs:raise FileExistsError(b)
  block=[(k,v) for k,v in self.fs.items() if k==a or k.startswith(a+'/')]
  for k,_ in block:del self.fs[k]
  for k,v in block:self.fs[b+k[len(a):]]=v
 def listdir(self,path):
  return list({k[len(path)+1:].split('/')[0] for k in self.fs if k.startswith(path+'/') and k!=path})
 def rmdir(self,path):
  if self.listdir(path):raise OSError('not empty')
  del self.fs[path]
 def remove(self,path):del self.fs[path]
class Conn:
 def __init__(self,fs):self.client=self;self.fs=fs
 def open_sftp(self):return self.fs
class QA(unittest.TestCase):
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.p=pathlib.Path(self.temp.name);self.fs=MemSFTP();self.conn=backend.PagerConnection.__new__(backend.PagerConnection);self.conn.client=Conn(self.fs)
 def test_title(self):self.assertEqual(app.APP_TITLE,'GS WiFI Pineapple Pager Companion App')
 def test_default_theme(self):self.assertEqual(app.read_settings(self.p/'absent.json')['theme'],'slate')
 def test_settings_roundtrip(self):
  settings=self.p/'settings.json';app.save_settings('yellow','Extra large',settings);self.assertEqual(app.read_settings(settings),{'theme':'yellow','text_size':'Extra large'})
 def test_urls(self):self.assertEqual(app.virtual_pager_url('172.16.52.1'),'http://172.16.52.1:1471/')
 def test_url_reject(self):
  for url in ['https://example.com','host:1234','../foo','a b']:
   with self.subTest(url=url),self.assertRaises(ValueError):app.virtual_pager_url(url)
 def test_firmware_bad_suffix(self):
  p=self.p/'firmware.zip';p.write_bytes(b'x'*270000)
  with self.assertRaises(backend.PagerError):backend.validate_firmware_file(str(p))
 def test_firmware_bad_magic(self):
  p=self.p/'firmware.bin';p.write_bytes(b'PK\x03\x04'+b'0'*270000)
  with self.assertRaises(backend.PagerError):backend.validate_firmware_file(str(p))
 def test_firmware_checksum(self):
  p=self.p/'arbitrary-name.bin';p.write_bytes(b'good firmware sample'+b'!'*270000)
  digest=hashlib.sha256(p.read_bytes()).hexdigest();self.assertEqual(backend.validate_firmware_file(str(p),digest)[1],digest)
  with self.assertRaises(backend.PagerError):backend.validate_firmware_file(str(p),'a'*64)
 def test_file_upload(self):
  p=self.p/'file.txt';p.write_text('hello');self.assertEqual(self.conn.upload_items([str(p)],'/root'),['file.txt']);self.assertEqual(self.fs.fs['/root/file.txt'],b'hello')
 def test_folder_upload(self):
  d=self.p/'payloads';(d/'sub').mkdir(parents=True);(d/'sub'/'test.txt').write_text('yes');self.conn.upload_items([str(d)],'/root');self.assertEqual(self.fs.fs['/root/payloads/sub/test.txt'],b'yes')
 def test_replace_requires_approval(self):
  p=self.p/'file.txt';p.write_text('new');self.fs.fs['/root/file.txt']=b'old'
  with self.assertRaises(backend.PagerError):self.conn.upload_items([str(p)],'/root')
  self.assertEqual(self.fs.fs['/root/file.txt'],b'old')
 def test_replace_success(self):
  p=self.p/'file.txt';p.write_text('new');self.fs.fs['/root/file.txt']=b'old';self.conn.upload_items([str(p)],'/root',overwrite_names={'file.txt'});self.assertEqual(self.fs.fs['/root/file.txt'],b'new')
 def test_rollback(self):
  p=self.p/'file.txt';p.write_text('new');self.fs.fs['/root/file.txt']=b'old';self.fs.fail_commit=True
  with self.assertRaises(backend.PagerError):self.conn.upload_items([str(p)],'/root',overwrite_names={'file.txt'})
  self.assertEqual(self.fs.fs['/root/file.txt'],b'old')
 def test_recursive_folder_delete(self):
  self.fs.fs['/root/a']=None;self.fs.fs['/root/a/b.txt']=b'x';self.conn.delete_path('/root/a');self.assertNotIn('/root/a',self.fs.fs)
 def test_protected_folder_delete(self):
  with self.assertRaises(backend.PagerError):self.conn.delete_path('/root/payloads')
 def test_symlink_rejected(self):
  d=self.p/'dir';d.mkdir();(d/'link').symlink_to(self.p)
  with self.assertRaises(backend.PagerError):self.conn.upload_items([str(d)],'/root')
 def test_no_code_running_on_import(self):self.assertIsNone(getattr(backend,'connection',None))
if __name__=='__main__':unittest.main(verbosity=2)
