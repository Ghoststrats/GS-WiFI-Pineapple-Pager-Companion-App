# GS WiFI Pineapple Pager Companion App — V1.3 (Windows Beta)

## Release highlights

- **Pager connection reliability:** Up to 120 seconds of automatic retries for temporary USB-network and SSH startup delays, with clearer status; authentication and host-key errors are not retried.
- **Firmware updater workflow:** Recommended on-device updater through Pager Settings → Updates; Windows-assisted update through a verified official `.bin`, free-space checks, SFTP transfer verification, and Hak5's `INSTALL_FIRMWARE` over dedicated SSH.
- **Simplified official download:** Retained the single **GRAB THE LATEST PAGER FIRMWARE HERE** browser button. Removed **DOWNLOAD INSIDE APP (ALTERNATIVE)** and **HAK5 DOWNLOAD PORTAL (IF LINK TIMES OUT)**; no automatic secondary portal appears. Users may still choose an already downloaded `.bin` file.
- **Better firmware diagnostics:** Live activity feedback, SSH updater output/errors, reboot monitoring and clear reporting of uncertain outcomes. A command being submitted is not proof of flashing success.
- **Better installation experience:** Animated purple installation indicator, elapsed timer, clearer setup statuses, native Windows shortcut handling and verification of the optional official Python runtime download.
- **Beginner connection tip:** Wait about 60 seconds after power-on, reconnect if the USB interface is not ready, and use a USB-C cable capable of data transfer. Do not disconnect during an active or uncertain flash.
- **Updated V1.3 branding:** App footer, setup title, installed-app version, README, install instructions, and distribution files.

### Credit

Special thanks to **Darren Kitchen, founder of Hak5**, for suggesting the direct latest-firmware download shortcut. This remains an independent, unofficial GhostStrats community app, not a Hak5-sponsored product.

### Device testing update

The developer reports that firmware flashing now reaches the Pager's flashing screen and the connection experience is noticeably better. The appearance of the flashing screen is encouraging, but does **not by itself** verify completion. Confirm the final firmware version after the Pager reboots before considering the flash successful.

### Download assets

- `GS_WiFI_Pineapple_Pager_Companion_App_V1.3_Easy_Install.zip` — Windows setup EXE + instructions.
- `GS_WiFI_Pineapple_Pager_Companion_App_V1.3_App_Files.zip` — application launcher and files (requires runtime/dependencies).
- `GS_WiFI_Pineapple_Pager_Companion_App_V1.3_Source_Code.zip` — full editable source with tests and build steps.
- `GS_WiFI_Pineapple_Pager_Companion_App_V1.3_Complete.zip` — contains all three downloads and release notes (optional).

### Safety and beta status

This is an **unsigned Windows beta**. Real Windows Defender behavior, Windows install/upgrade/repair/uninstall, and a fully completed physical firmware flash have not been verified in this development environment. Do not bypass an antivirus detection or interrupt an ongoing firmware update. This app is independent and not endorsed by Hak5.

Official firmware: https://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest
