GS WiFI Pineapple Pager Companion App — V1.3 (Windows Beta)

INSTALL
1. Extract this ZIP and open GS_WiFI_Pineapple_Pager_Companion_App_Setup_V1.3.exe.
2. Choose Install / Upgrade, Repair, or Uninstall.
3. The purple animation and timer stay active during slow installation stages.
4. After powering on your Pager, wait about 60 seconds. Connect using a USB-C data cable.
5. If USB / SSH initially times out, automatic retries can continue for up to 120 seconds.

FIRMWARE UPDATE
Recommended: Use Settings > Updates > Check for Updates directly on the Pager.
The app can open Hak5's direct latest firmware link in a browser: https://downloads.hak5.org/api/devices/wifipineapplepager/firmwares/latest
If that link fails, retry it later. There is no alternate in-app download or portal fallback.
The Windows-assisted updater also accepts a previously downloaded official signed .bin.
Keep the Pager powered and connected while flashing and rebooting. Never blindly retry an uncertain flash.

SECURITY
The Windows installer is unsigned. Do not bypass antivirus detections; investigate them.
The app is an independent community project, not an official Hak5 product.
